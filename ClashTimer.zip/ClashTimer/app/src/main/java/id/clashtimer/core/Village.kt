package id.clashtimer.core

class ExportException(msg: String) : Exception(msg)

/** Satu bangunan/hero/troop di desa. Instance yang sedang upgrade punya [uid] = id timer. */
class Inst(
    val uid: String,
    val item: Item,
    var level: Int,
    var upgrading: Boolean,
    /** Sisa detik saat export (0 bila tidak sedang upgrade). */
    var remaining: Long,
    val helped: Boolean,
    val geared: Boolean,
) {
    fun copy() = Inst(uid, item, level, upgrading, remaining, helped, geared)
}

class HelperState(val id: Int, val level: Int, val cooldown: Long)

/** Timer yang sedang berjalan menurut export (termasuk item yang tidak ada di data game). */
class RunningTimer(
    val uid: String,
    val dataId: Int,
    val name: String,
    val lane: Lane,
    val cat: Cat?,
    /** Level saat ini (sebelum upgrade selesai). */
    val fromLevel: Int,
    val remaining: Long,
    val helped: Boolean,
)

class Village(
    val tag: String,
    /** Waktu export (ms). */
    val exportAt: Long,
    val insts: MutableList<Inst>,
    /** level → jumlah tembok. */
    val walls: MutableMap<Int, Int>,
    val bbWalls: MutableMap<Int, Int>,
    val helpers: List<HelperState>,
    val timers: List<RunningTimer>,
    val unknown: Int,
    val homeBuilders: Int,
    val bbBuildersAuto: Int,
    val hasHome: Boolean,
    val hasBB: Boolean,
) {
    fun level(id: Int): Int = insts.filter { it.item.id == id }.maxOfOrNull { it.level } ?: 0
    fun isUpgrading(id: Int): Boolean = insts.any { it.item.id == id && it.upgrading }
    fun has(id: Int): Boolean = insts.any { it.item.id == id }
    fun count(id: Int): Int = insts.count { it.item.id == id }

    val th: Int get() = level(GameData.TOWN_HALL).coerceAtLeast(1)
    val bh: Int get() = level(GameData.BUILDER_HALL)
    val labLevel: Int get() = level(GameData.LAB)
    val heroHall: Int get() = level(GameData.HERO_HALL)
    val petHouse: Int get() = level(GameData.PET_HOUSE)
    val starLab: Int get() = level(GameData.STAR_LAB)

    fun helper(id: Int): HelperState? = helpers.firstOrNull { it.id == id }

    fun copy(): Village = Village(
        tag, exportAt, insts.map { it.copy() }.toMutableList(), walls.toMutableMap(), bbWalls.toMutableMap(),
        helpers, timers, unknown, homeBuilders, bbBuildersAuto, hasHome, hasBB,
    )

    /**
     * Terapkan perubahan sejak export: upgrade yang sudah diselesaikan lebih awal
     * (book / gem / ditandai selesai) dan level yang naik karena hammer.
     */
    fun applyOverrides(completed: Collection<String>, bumps: List<Pair<Int, Int>>) {
        for (uid in completed) {
            val i = insts.firstOrNull { it.uid == uid && it.upgrading } ?: continue
            i.level += 1
            i.upgrading = false
            i.remaining = 0
        }
        for ((id, from) in bumps) {
            val i = insts.firstOrNull { it.item.id == id && it.level == from && !it.upgrading } ?: continue
            i.level += 1
        }
    }
}

/** Membaca teks "Export village data" dari game. */
object ExportReader {

    private val sections: List<Pair<String, Cat?>> = listOf(
        "buildings" to Cat.BUILDING,
        "traps" to Cat.TRAP,
        "heroes" to Cat.HERO,
        "units" to Cat.TROOP,
        "siege_machines" to Cat.TROOP,
        "spells" to Cat.SPELL,
        "pets" to Cat.PET,
        "buildings2" to Cat.BB_BUILDING,
        "traps2" to null,
        "heroes2" to Cat.BB_HERO,
        "units2" to Cat.BB_TROOP,
    )

    private fun laneOfSection(section: String): Lane = when (section) {
        "units", "siege_machines", "spells" -> Lane.LAB
        "pets" -> Lane.PET
        "buildings2", "traps2", "heroes2" -> Lane.BB_BUILDER
        "units2" -> Lane.STAR_LAB
        else -> Lane.BUILDER
    }

    fun read(rawText: String, gd: GameData, nowMs: Long): Village {
        val text = rawText.trim()
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) {
            throw ExportException("Teks ini bukan export desa. Di game: Settings → More Settings → Export village data → Copy.")
        }
        val root = try {
            Json.parse(text.substring(start, end + 1)).obj()
        } catch (e: Exception) {
            null
        } ?: throw ExportException("JSON export tidak lengkap atau rusak. Coba Copy ulang dari game.")

        if (root["buildings"] == null && root["buildings2"] == null) {
            throw ExportException("Tidak ditemukan data bangunan. Pastikan yang di-copy adalah \"Export village data\".")
        }

        val tag = root["tag"].str().ifBlank { "#DESA" }
        val tsSec = root["timestamp"].long()
        val exportAt = if (tsSec > 1_500_000_000L && tsSec * 1000 <= nowMs + 5 * 60_000L) tsSec * 1000 else nowMs

        val insts = ArrayList<Inst>()
        val timers = ArrayList<RunningTimer>()
        val walls = HashMap<Int, Int>()
        val bbWalls = HashMap<Int, Int>()
        var unknown = 0
        var huts = 0

        for ((section, cat) in sections) {
            val arr = root[section].arr() ?: continue
            val timerCounter = HashMap<Int, Int>()
            for ((index, raw) in arr.withIndex()) {
                val e = raw.obj() ?: continue
                if (e["data"] == null || e["lvl"] == null) continue
                val dataId = e["data"].int()
                val lvl = e["lvl"].int()
                val cnt = e["cnt"].int(1).coerceIn(0, 2000)
                val timer = e["timer"].long()
                val helped = e["helper_recurrent"].bool()
                val geared = e["gear_up"].bool()
                val item = gd.item(dataId)?.takeIf { cat != null && it.cat.bb == cat.bb }

                if (section == "buildings" && dataId == GameData.HUT) huts += if (timer > 0) 1 else cnt

                if (item != null && item.isWall) {
                    val target = if (item.cat.bb) bbWalls else walls
                    target[lvl] = (target[lvl] ?: 0) + cnt
                    continue
                }

                if (timer > 0) {
                    val n = (timerCounter[dataId] ?: 0) + 1
                    timerCounter[dataId] = n
                    val uid = "$tag|$section|$dataId|$n"
                    val lane = item?.lane ?: laneOfSection(section)
                    timers += RunningTimer(uid, dataId, gd.name(dataId), lane, item?.cat, lvl, timer, helped)
                    if (item != null) insts += Inst(uid, item, lvl, true, timer, helped, geared)
                    else unknown++
                } else if (item != null) {
                    repeat(cnt) { k -> insts += Inst("$section|$dataId|$index|$k", item, lvl, false, 0, false, geared) }
                } else if (cat != null) {
                    unknown++
                }
            }
        }

        val helpers = root["helpers"].arr().orEmpty().mapNotNull { raw ->
            val e = raw.obj() ?: return@mapNotNull null
            if (e["data"] == null) null
            else HelperState(e["data"].int(), e["lvl"].int(1), e["helper_cooldown"].long())
        }

        val hasBob = insts.any { it.item.id == GameData.BOB_HUT }
        val homeBuilders = (if (huts > 0) huts else 5) + if (hasBob) 1 else 0
        val bbBusy = timers.count { it.lane == Lane.BB_BUILDER }
        val bbAuto = maxOf(
            1 + (if (insts.any { it.item.id == GameData.BOTO_SHACK }) 1 else 0) +
                (if (insts.any { it.item.id == GameData.OTTO_OUTPOST }) 1 else 0),
            bbBusy,
        )

        return Village(
            tag, exportAt, insts, walls, bbWalls, helpers, timers, unknown,
            homeBuilders.coerceAtMost(6), bbAuto,
            hasHome = root["buildings"] != null,
            hasBB = root["buildings2"].arr()?.isNotEmpty() == true,
        )
    }
}
