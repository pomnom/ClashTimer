package id.clashtimer

import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import id.clashtimer.core.DAY
import id.clashtimer.core.Fmt
import id.clashtimer.core.Lane
import id.clashtimer.core.Strategy
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Tab "Rencana": jadwal per hari — kapan memulai apa di builder mana. */
object PlanView {

    private class Item(val time: Long, val kind: Int, val lane: Lane?, val laneIndex: Int, val title: String, val sub: String, val warn: String?)

    fun render(act: MainActivity, box: LinearLayout, b: PlanBundle, bb: Boolean) {
        val zone = ZoneId.systemDefault()
        val now = System.currentTimeMillis()
        val ps = b.ps
        val s = ps.schedule

        // --- chip pengaturan
        val chips = Ui.hbox(act)
        fun chip(text: String, onClick: () -> Unit) {
            chips.addView(Ui.chip(act, text, onClick), LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT,
            ).apply { marginEnd = Ui.dp(act, 6) })
        }
        chip("${ps.strategy.label} ▾") { chooseStrategy(act) }
        if (s.sleep.enabled) chip("😴 ${Fmt.clock(s.sleep.startMin)}–${Fmt.clock(s.sleep.endMin)}") { act.openSettings() }
        else chip("😴 atur jam tidur") { act.openSettings() }
        if (s.work.enabled) chip("💼 ${Fmt.clock(s.work.startMin)}–${Fmt.clock(s.work.endMin)}") { act.openSettings() }
        chip("Gold Pass ${ps.gold.builderPct}%") { act.openSettings() }
        if (ps.cwl.enabled) {
            val w = ps.cwl.next(now)
            chip("⚔️ CWL ${Fmt.dateShort(w.first, zone)}–${Fmt.dateShort(w.last + 1, zone)}") { act.openSettings() }
        }
        val hs = HorizontalScrollView(act).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
            setPadding(0, Ui.dp(act, 4), 0, Ui.dp(act, 4))
        }
        box.addView(hs, Ui.matchWrap())

        val sim = if (bb) b.simBB else b.simHome
        if (sim == null) {
            box.addView(Ui.muted(act, "Belum ada data untuk rencana ini.", Ui.BODY_M).apply { setPadding(Ui.dp(act, 4), Ui.dp(act, 16), 0, 0) })
            return
        }

        // --- kumpulkan item agenda
        val horizon = now + 3 * DAY
        val items = ArrayList<Item>()
        val notes = HashSet<String>()
        for (st in sim.steps) {
            if (st.lane.bb != bb || st.start > horizon) continue
            val idle = if (st.idle > 30 * 60_000L) "💤 nganggur ${Fmt.dur(st.idle)} setelah selesai" else null
            val note = st.note?.takeIf { notes.add(it) }
            val warn = listOfNotNull(idle, note?.let { "⚔️ $it" }).joinToString("\n").ifBlank { null }
            items += Item(st.start, 0, st.lane, st.laneIndex, st.title,
                "${Fmt.durSec(st.durationSec)} · selesai ${short(st.finish, st.start, zone)}", warn)
        }
        if (!bb) {
            // Gabungkan sesi helper yang terjadi pada jam yang sama
            for ((t, group) in sim.helperEvents.filter { it.time <= horizon }.groupBy { it.time }) {
                val text = group.joinToString(" · ") { "${it.target} −${it.level}j" }
                items += Item(t, 1, null, 0, "Helper bekerja", text, null)
            }
        }
        val lastTime = (items.maxOfOrNull { it.time } ?: now).coerceAtMost(horizon)
        for (w in s.windowsBetween(now, lastTime)) {
            val startMin = Instant.ofEpochMilli(w.first).atZone(zone).let { it.hour * 60 + it.minute }
            val isSleep = s.sleep.enabled && startMin == s.sleep.startMin
            val label = if (isSleep) "😴 Tidur" else "💼 Kerja / sekolah"
            val t = maxOf(w.first, now)
            val sub = if (w.first < now) "sedang berlangsung, sampai ${Fmt.time(w.last + 1, zone)}" else "${Fmt.time(w.first, zone)} – ${Fmt.time(w.last + 1, zone)}"
            items += Item(t, 2, null, 0, label, sub, null)
        }
        items.sortWith(compareBy<Item>({ it.time }, { it.kind }))

        if (items.none { it.kind == 0 }) {
            box.addView(Ui.muted(act, "Tidak ada upgrade yang bisa direncanakan — semua sudah max atau menunggu syarat.", Ui.BODY_M).apply {
                setPadding(Ui.dp(act, 4), Ui.dp(act, 16), 0, 0)
            })
        }

        // --- tampilkan per hari
        val dayFmt = DateTimeFormatter.ofPattern("EEEE, d MMM", Fmt.locale)
        val byDay = LinkedHashMap<LocalDate, MutableList<Item>>()
        for (it in items.take(60)) byDay.getOrPut(Instant.ofEpochMilli(it.time).atZone(zone).toLocalDate()) { ArrayList() } += it
        for ((day, list) in byDay) {
            val steps = list.count { it.kind == 0 }
            box.addView(Ui.sectionRow(act, dayFmt.format(day).replaceFirstChar { it.uppercase() }, if (steps > 0) "$steps langkah" else null))
            val (card, col) = Ui.card(act, padH = 0, padV = 0)
            list.forEachIndexed { i, it ->
                if (i > 0) col.addView(Ui.divider(act))
                col.addView(row(act, it, zone))
            }
            box.addView(card)
        }

        if (!bb && sim.builderIdle7d > 0) {
            box.addView(Ui.muted(act, "Builder menganggur 7 hari ke depan karena Anda offline: ±${Fmt.dur(sim.builderIdle7d)}", Ui.BODY_M).apply {
                setPadding(Ui.dp(act, 4), Ui.dp(act, 12), Ui.dp(act, 4), 0)
            })
        }
        box.addView(Ui.muted(act,
            "Rencana = perkiraan jika setiap pekerja langsung diisi saran teratas saat Anda online. " +
                "Dihitung ${Fmt.time(b.computedAt, zone)}; setelah memulai upgrade di game, tekan \"Sudah dimulai\" di Beranda agar rencana ikut bergeser.").apply {
            setPadding(Ui.dp(act, 4), Ui.dp(act, 10), Ui.dp(act, 4), 0)
        })
    }

    private fun laneChip(lane: Lane, index: Int): Pair<String, Int> = when (lane) {
        Lane.BUILDER -> "B$index" to Ui.BLUE
        Lane.LAB -> "Lab" to Ui.VIOLET
        Lane.PET -> "Pet" to Ui.VIOLET
        Lane.BB_BUILDER -> "BB$index" to Ui.BLUE
        Lane.STAR_LAB -> "Star" to Ui.VIOLET
    }

    private fun row(act: MainActivity, it: Item, zone: ZoneId): View {
        val line = Ui.hbox(act).apply {
            setPadding(Ui.dp(act, 12), Ui.dp(act, 9), Ui.dp(act, 12), Ui.dp(act, 9))
            gravity = Gravity.TOP
        }
        line.addView(Ui.muted(act, Fmt.time(it.time, zone), Ui.BODY_M).apply { minWidth = Ui.dp(act, 46) })
        val (label, color) = when (it.kind) {
            0 -> laneChip(it.lane!!, it.laneIndex)
            1 -> "Helper" to Ui.GREEN
            else -> "Offline" to Ui.GREY
        }
        line.addView(Ui.pill(act, label, color), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { marginEnd = Ui.dp(act, 10); topMargin = Ui.dp(act, 1) })
        val col = Ui.vbox(act)
        if (it.kind == 2) {
            col.addView(Ui.muted(act, "${it.title} · ${it.sub}", Ui.BODY_M))
        } else {
            col.addView(Ui.text(act, it.title, Ui.TITLE_S).apply { textSize = 14f })
            col.addView(Ui.muted(act, it.sub))
            it.warn?.let { w -> col.addView(Ui.text(act, w, Ui.BODY_S).apply { setTextColor(Ui.AMBER) }) }
        }
        line.addView(col, Ui.weight1())
        return line
    }

    private fun short(t: Long, ref: Long, zone: ZoneId): String {
        val d1 = Instant.ofEpochMilli(t).atZone(zone).toLocalDate()
        val d0 = Instant.ofEpochMilli(ref).atZone(zone).toLocalDate()
        val time = Fmt.time(t, zone)
        return if (d1 == d0) time else DateTimeFormatter.ofPattern("EEE", Fmt.locale).format(d1) + " " + time
    }

    private fun chooseStrategy(act: MainActivity) {
        val all = Strategy.entries
        val cur = Store.planSettings(act).strategy
        val labels = all.map { "${it.label}\n${it.desc}" as CharSequence }.toTypedArray()
        MaterialAlertDialogBuilder(act)
            .setTitle("Strategi saran")
            .setSingleChoiceItems(labels, all.indexOf(cur)) { d, w ->
                Store.putPlan(act, "strategy", all[w].name)
                d.dismiss()
                act.dataChanged()
            }
            .show()
    }
}
