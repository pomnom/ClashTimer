package id.clashtimer.core

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.ZonedDateTime

/** Jendela harian (mis. tidur 23:00–06:00). Menit sejak tengah malam. */
data class DailyWindow(
    val enabled: Boolean,
    val startMin: Int,
    val endMin: Int,
    val days: Set<DayOfWeek> = DayOfWeek.entries.toSet(),
)

/** Kapan pengguna tidak bisa membuka game (tidur / kerja). */
class OfflineSchedule(
    val sleep: DailyWindow,
    val work: DailyWindow,
    val zone: ZoneId,
) {
    private val cache = HashMap<Long, List<LongRange>>()

    /** Jendela offline (sudah digabung) di sekitar hari [day] (epoch day lokal). */
    private fun windowsForDay(day: Long): List<LongRange> = cache.getOrPut(day) {
        val raw = ArrayList<LongRange>()
        for (d in (day - 1)..(day + 1)) {
            val date = LocalDate.ofEpochDay(d)
            for (w in listOf(sleep, work)) {
                if (!w.enabled || w.startMin == w.endMin) continue
                if (date.dayOfWeek !in w.days) continue
                val s = date.atStartOfDay(zone).plusMinutes(w.startMin.toLong()).toInstant().toEpochMilli()
                val endDate = if (w.endMin > w.startMin) date else date.plusDays(1)
                val e = endDate.atStartOfDay(zone).plusMinutes(w.endMin.toLong()).toInstant().toEpochMilli()
                raw += s until e
            }
        }
        merge(raw)
    }

    private fun merge(list: List<LongRange>): List<LongRange> {
        val sorted = list.sortedBy { it.first }
        val out = ArrayList<LongRange>()
        for (r in sorted) {
            val last = out.lastOrNull()
            if (last != null && r.first <= last.last + 1) {
                out[out.size - 1] = last.first..maxOf(last.last, r.last)
            } else out += r
        }
        return out
    }

    private fun localDay(t: Long): Long =
        Instant.ofEpochMilli(t).atZone(zone).toLocalDate().toEpochDay()

    fun windowAt(t: Long): LongRange? = windowsForDay(localDay(t)).firstOrNull { t in it }

    fun isOffline(t: Long): Boolean = windowAt(t) != null

    /** Waktu online paling awal ≥ [t]. */
    fun nextOnline(t: Long): Long {
        var cur = t
        repeat(10) {
            val w = windowAt(cur) ?: return cur
            cur = w.last + 1
        }
        return cur
    }

    /** Awal jendela offline berikutnya setelah [t] (dalam 3 hari), atau null. */
    fun nextOfflineStart(t: Long): Long? {
        val day = localDay(t)
        for (d in day..(day + 3)) {
            windowsForDay(d).firstOrNull { it.first > t }?.let { return it.first }
        }
        return null
    }

    /** Semua jendela offline yang bersinggungan dengan [a, b]. */
    fun windowsBetween(a: Long, b: Long): List<LongRange> {
        val all = ArrayList<LongRange>()
        var d = localDay(a) - 1
        val end = localDay(b) + 1
        while (d <= end) { all += windowsForDay(d); d++ }
        return merge(all).filter { it.first <= b && it.last >= a }
    }

    val anyEnabled: Boolean get() = (sleep.enabled && sleep.startMin != sleep.endMin) || (work.enabled && work.startMin != work.endMin)
}

/**
 * Clan War League. Default mengikuti asumsi umum: mulai tanggal 1 pukul 08:00 UTC
 * (16:00 WITA), berlangsung 11 hari.
 */
class CwlRule(
    val enabled: Boolean,
    val startDay: Int = 1,
    val startUtcHour: Int = 8,
    val days: Int = 11,
) {
    private fun windowForMonth(year: Int, month: Int): LongRange {
        val day = startDay.coerceIn(1, 28)
        val s = ZonedDateTime.of(year, month, day, startUtcHour.coerceIn(0, 23), 0, 0, 0, ZoneOffset.UTC)
        val e = s.plusDays(days.toLong().coerceIn(1, 27))
        return s.toInstant().toEpochMilli() until e.toInstant().toEpochMilli()
    }

    fun windowsAround(t: Long): List<LongRange> {
        val z = Instant.ofEpochMilli(t).atZone(ZoneOffset.UTC)
        val out = ArrayList<LongRange>()
        var m = z.withDayOfMonth(1).minusMonths(1)
        repeat(4) {
            out += windowForMonth(m.year, m.monthValue)
            m = m.plusMonths(1)
        }
        return out
    }

    /** Jendela CWL yang bertabrakan dengan [start, end), atau null. */
    fun overlap(start: Long, end: Long): LongRange? {
        if (!enabled) return null
        val ws = windowsAround(start) + windowsAround(end)
        return ws.firstOrNull { it.first < end && it.last + 1 > start }
    }

    /** Jendela CWL berikutnya yang belum selesai pada [t]. */
    fun next(t: Long): LongRange = windowsAround(t).first { it.last >= t }
}

/** Diskon Gold Pass (Builder Boost & Research Boost), dengan pembulatan seperti di game. */
data class GoldPass(val builderPct: Int, val researchPct: Int) {
    fun pctFor(lane: Lane): Int = when (lane) {
        Lane.BUILDER, Lane.BB_BUILDER -> builderPct
        Lane.LAB, Lane.PET -> researchPct
        Lane.STAR_LAB -> 0
    }

    /** Durasi (detik) setelah diskon. */
    fun apply(seconds: Long, lane: Lane): Long {
        val pct = pctFor(lane).coerceIn(0, 90)
        if (pct == 0 || seconds <= 0) return seconds
        val t = seconds * (100 - pct) / 100.0
        return when {
            t < 1800 -> Math.ceil(t).toLong()
            t <= 86400 -> (Math.floor(t / 600) * 600).toLong()
            else -> (Math.floor(t / 3600) * 3600).toLong()
        }
    }

    companion object {
        val NONE = GoldPass(0, 0)
    }
}
