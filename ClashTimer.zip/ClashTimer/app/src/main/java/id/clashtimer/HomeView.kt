package id.clashtimer

import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import id.clashtimer.core.DAY
import id.clashtimer.core.Fmt
import id.clashtimer.core.GameData
import id.clashtimer.core.Lane
import id.clashtimer.core.LaneSlot
import id.clashtimer.core.Planner
import id.clashtimer.core.Scored
import java.time.ZoneId

/** Tab "Beranda": timer berjalan + saran untuk pekerja yang bebas. */
object HomeView {

    fun render(act: MainActivity, box: LinearLayout, tag: String, bb: Boolean, b: PlanBundle?) {
        val now = System.currentTimeMillis()
        val zone = ZoneId.systemDefault()
        val gd = Repo.gameData(act)
        val ups = Store.upgrades(act).filter { it.tag == tag }
        val acc = Store.accounts(act).firstOrNull { it.tag == tag } ?: return
        val hasExport = Store.exportText(act, tag) != null

        act.addWarnings(box)

        if (bb && acc.bh == 0 && ups.none { it.kind.builderBase }) {
            box.addView(Ui.text(act, "Belum ada data Builder Base di export desa ini.", Ui.BODY_M).apply {
                setPadding(Ui.dp(act, 4), Ui.dp(act, 24), Ui.dp(act, 4), 0)
            })
            return
        }

        val builderKind = if (bb) Kind.BB_BUILDER else Kind.BUILDER
        val builderLane = if (bb) Lane.BB_BUILDER else Lane.BUILDER
        val running = ups.filter { it.kind == builderKind && it.finishAt > now }.sortedBy { it.finishAt }
        val finished = ups.filter { it.kind == builderKind && it.finishAt <= now }.sortedByDescending { it.finishAt }
        val total = b?.let { Planner.laneCount(it.village, builderLane, it.ps) }
            ?: (if (bb) maxOf(1, running.size) else acc.builders)
        val free = (total - running.size).coerceAtLeast(0)
        val slots = b?.slots?.filter { it.lane == builderLane }.orEmpty()
        val nowSlot = slots.firstOrNull { it.freeAt <= now }
        val nextSlot = slots.firstOrNull { it.freeAt > now }

        // --- judul besar
        val (hc, hcol) = Ui.card(act, padV = 14)
        if (free > 0) {
            hcol.addView(Ui.muted(act, if (bb) "Master Builder tersedia" else "Builder tersedia", Ui.BODY_M))
            hcol.addView(Ui.text(act, "$free bebas", Ui.TITLE_L).apply {
                textSize = 30f
                setTextColor(Ui.GREEN)
            })
            suggestionStrip(act, hcol, tag, nowSlot, nowSlot?.ranked?.firstOrNull(), canStart = true, b, hasExport)
        } else if (running.isNotEmpty()) {
            val first = running.first()
            hcol.addView(Ui.muted(act, "Builder berikutnya bebas dalam", Ui.BODY_M))
            val big = Ui.text(act, act.clock(first.finishAt - now), Ui.TITLE_L).apply {
                textSize = 32f
                setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            }
            act.registerCountdown(big, first.finishAt, clockStyle = true)
            hcol.addView(big)
            hcol.addView(Ui.muted(act, "${first.title()} · ${Fmt.at(first.finishAt, zone)}", Ui.BODY_M))
            suggestionStrip(act, hcol, tag, nextSlot, nextSlot?.ranked?.firstOrNull(), canStart = false, b, hasExport)
        } else {
            hcol.addView(Ui.text(act, "Belum ada upgrade yang tercatat.", Ui.BODY_M))
        }
        box.addView(hc)

        // --- builder
        box.addView(Ui.sectionRow(act, if (bb) "Master Builder" else "Builder", "${running.size} dari $total sibuk"))
        val (bc, bcol) = Ui.card(act, padH = 0, padV = 0)
        var rows = 0
        fun add(v: View) {
            if (rows++ > 0) bcol.addView(Ui.divider(act))
            bcol.addView(v)
        }
        for (u in finished.take(3)) add(timerRow(act, u, now, zone, gd, b, Ui.GREEN))
        for (u in running) add(timerRow(act, u, now, zone, gd, b, Ui.GREEN))
        if (free > 1 && nowSlot != null) {
            for (k in 1 until free) {
                val pick = nowSlot.ranked.getOrNull(k) ?: break
                add(freeRow(act, tag, nowSlot, pick, if (bb) "Master Builder bebas" else "Builder bebas"))
            }
        }
        if (rows == 0) bcol.addView(Ui.muted(act, "Belum ada upgrade.", Ui.BODY_M).apply { setPadding(Ui.dp(act, 14), Ui.dp(act, 12), 0, Ui.dp(act, 12)) })
        box.addView(bc)

        // --- lab, pet, star lab
        val labLanes = if (bb) listOf(Lane.STAR_LAB) else listOf(Lane.LAB, Lane.PET)
        for (lane in labLanes) {
            val kind = Kind.of(lane)
            val r = ups.filter { it.kind == kind && it.finishAt > now }.sortedBy { it.finishAt }
            val exists = b?.let { Planner.laneCount(it.village, lane, it.ps) > 0 } ?: r.isNotEmpty()
            if (!exists && r.isEmpty()) continue
            box.addView(Ui.sectionRow(act, lane.label, if (r.isEmpty()) "kosong" else "${r.size} dari 1 sibuk"))
            val (lc, lcol) = Ui.card(act, padH = 0, padV = 0)
            if (r.isNotEmpty()) {
                r.forEachIndexed { i, u ->
                    if (i > 0) lcol.addView(Ui.divider(act))
                    lcol.addView(timerRow(act, u, now, zone, gd, b, Ui.VIOLET))
                }
            } else {
                val slot = b?.slots?.firstOrNull { it.lane == lane && it.freeAt <= now }
                val pick = slot?.ranked?.firstOrNull()
                if (slot != null && pick != null) lcol.addView(freeRow(act, tag, slot, pick, "${lane.label} kosong"))
                else lcol.addView(Ui.muted(act, if (b == null) "Menghitung saran…" else "Tidak ada riset yang tersedia.", Ui.BODY_M).apply {
                    setPadding(Ui.dp(act, 14), Ui.dp(act, 12), 0, Ui.dp(act, 12))
                })
            }
            box.addView(lc)
        }

        // --- helper
        if (!bb) helpers(act, box, tag, ups, b, now, zone)

        // --- CWL
        if (!bb && b != null && b.ps.cwl.enabled) {
            val w = b.ps.cwl.next(now)
            if (w.first - now < 3 * DAY) {
                val txt = if (now >= w.first) "⚔️ CWL berlangsung sampai ${Fmt.at(w.last + 1, zone)} · hero yang bentrok tidak disarankan"
                else "⚔️ CWL mulai ${Fmt.at(w.first, zone)} · hero yang bentrok tidak disarankan"
                box.addView(Ui.banner(act, txt, Ui.GOLD).also { topMargin(it, act, 12) })
            }
            val fin = ups.associate { it.id to it.finishAt }
            for (i in b.village.insts) {
                if (!i.upgrading || i.item.cat != id.clashtimer.core.Cat.HERO) continue
                val f = fin[i.uid] ?: continue
                if (f > now && b.ps.cwl.overlap(now, f) != null) {
                    box.addView(Ui.banner(act, "⚠️ ${i.item.name} masih upgrade saat CWL (selesai ${Fmt.at(f, zone)}) — pertimbangkan Book of Heroes / potion", Ui.AMBER))
                }
            }
        }

        // --- desa lain
        val others = Store.accounts(act).filter { it.tag != tag }
        for (o in others) {
            val f = act.freeBuilders(o.tag, false)
            if (f > 0) {
                box.addView(Ui.banner(act, "🏰 ${Store.villageName(act, o.tag)}: $f builder bebas — ketuk untuk membuka", Ui.GREEN).apply {
                    setOnClickListener { act.selectVillage(o.tag) }
                }.also { topMargin(it, act, 8) })
            }
        }

        // --- tombol bawah
        val row = Ui.hbox(act).apply { setPadding(0, Ui.dp(act, 12), 0, 0) }
        row.addView(Ui.outlined(act, "⚡ Potion & item") { act.openItems(tag) }.apply { isAllCaps = false }, Ui.weight1())
        row.addView(Ui.outlined(act, "📋 Update desa") { act.importFromClipboard() }.apply { isAllCaps = false },
            Ui.weight1().apply { marginStart = Ui.dp(act, 8) })
        box.addView(row)
        box.addView(Ui.muted(act, "Ketuk sebuah upgrade untuk menandai selesai atau batal. Setelah memulai upgrade di game, tekan \"Sudah dimulai\" pada saran — atau Update desa.").apply {
            setPadding(Ui.dp(act, 4), Ui.dp(act, 12), Ui.dp(act, 4), 0)
            gravity = Gravity.CENTER
        })
    }

    private fun topMargin(v: View, act: MainActivity, dp: Int) {
        (v.layoutParams as? ViewGroup.MarginLayoutParams)?.topMargin = Ui.dp(act, dp)
    }

    // ---------------------------------------------------------------- saran

    private fun pickLine(act: MainActivity, p: Scored, zone: ZoneId): String {
        val c = p.c
        val cost = if (c.cost > 0) "${Fmt.money(c.cost)} ${Fmt.resource(c.item.resource)}" else "gratis"
        val timing = if (p.idle > 30 * 60_000L) "💤 builder nganggur ${Fmt.dur(p.idle)}" else "selesai ${Fmt.at(p.finish, zone)} ✓"
        return "${Fmt.durSec(c.duration)} · $cost · $timing"
    }

    private fun suggestionStrip(
        act: MainActivity, col: LinearLayout, tag: String, slot: LaneSlot?, pick: Scored?,
        canStart: Boolean, b: PlanBundle?, hasExport: Boolean,
    ) {
        col.addView(Ui.divider(act).also { topMargin(it, act, 12) })
        val wrap = Ui.vbox(act).apply { setPadding(0, Ui.dp(act, 10), 0, 0) }
        when {
            !hasExport -> wrap.addView(Ui.muted(act, "💡 Import ulang desa ini sekali supaya saran upgrade muncul.", Ui.BODY_M))
            b == null -> wrap.addView(Ui.muted(act, "💡 Menghitung saran…", Ui.BODY_M))
            slot == null || pick == null -> wrap.addView(Ui.muted(act, "💡 Tidak ada upgrade yang tersedia untuk saat ini.", Ui.BODY_M))
            else -> {
                val lead = if (canStart) "💡 Saran: " else "💡 Saran saat bebas: "
                wrap.addView(Ui.text(act, lead + pick.c.title, Ui.TITLE_S))
                wrap.addView(Ui.muted(act, pickLine(act, pick, ZoneId.systemDefault())))
                if (slot.cwlSkipped.isNotEmpty()) {
                    wrap.addView(Ui.muted(act, "⚔️ Ditunda karena CWL: " + slot.cwlSkipped.joinToString(", ") { it.item.name }))
                }
                val r = Ui.hbox(act).apply { setPadding(0, Ui.dp(act, 6), 0, 0) }
                if (canStart) {
                    r.addView(Ui.filled(act, "Sudah dimulai") { act.startPick(tag, pick) }.apply { isAllCaps = false }, Ui.weight1())
                    r.addView(Ui.outlined(act, "Lihat opsi") { Options.show(act, tag, slot, true) }.apply { isAllCaps = false },
                        Ui.weight1().apply { marginStart = Ui.dp(act, 8) })
                } else {
                    r.addView(Ui.outlined(act, "Lihat opsi") { Options.show(act, tag, slot, false) }.apply { isAllCaps = false }, Ui.weight1())
                }
                wrap.addView(r)
            }
        }
        col.addView(wrap)
    }

    private fun freeRow(act: MainActivity, tag: String, slot: LaneSlot, pick: Scored, head: String): View {
        val col = Ui.vbox(act).apply { setPadding(Ui.dp(act, 14), Ui.dp(act, 10), Ui.dp(act, 14), Ui.dp(act, 8)) }
        val top = Ui.hbox(act)
        top.addView(Ui.text(act, head, Ui.TITLE_S).apply { setTextColor(Ui.GREEN) }, Ui.weight1())
        top.addView(Ui.pill(act, "saran", Ui.GOLD))
        col.addView(top)
        col.addView(Ui.text(act, pick.c.title, Ui.BODY_M))
        col.addView(Ui.muted(act, pickLine(act, pick, ZoneId.systemDefault())))
        val r = Ui.hbox(act).apply { setPadding(0, Ui.dp(act, 4), 0, 0) }
        r.addView(Ui.outlined(act, "Sudah dimulai") { act.startPick(tag, pick) }.apply { isAllCaps = false }, Ui.weight1())
        r.addView(Ui.flat(act, "Lihat opsi") { Options.show(act, tag, slot, true) }.apply { isAllCaps = false },
            Ui.weight1().apply { marginStart = Ui.dp(act, 8) })
        col.addView(r)
        return col
    }

    // ---------------------------------------------------------------- baris timer

    private fun timerRow(
        act: MainActivity, u: Upgrade, now: Long, zone: ZoneId, gd: GameData, b: PlanBundle?, color: Int,
    ): View {
        val done = u.finishAt <= now
        val line = Ui.hbox(act).apply {
            setPadding(Ui.dp(act, 12), Ui.dp(act, 10), Ui.dp(act, 14), Ui.dp(act, 10))
            isClickable = true
            setOnClickListener { act.timerOptions(u) }
        }
        val ring = RingView(act, 40)
        if (done) {
            ring.pct = 100
            ring.label = "✓"
            ring.setColor(Ui.GREEN)
        } else {
            val total = Repo.itemIdOf(u.id)?.let { gd.item(it)?.lv(u.targetLevel)?.time } ?: 0L
            if (total > 0) {
                val rem = (u.finishAt - now) / 1000.0
                ring.pct = (100 * (1 - rem / total)).toInt().coerceIn(1, 99)
            } else ring.label = "–"
            ring.setColor(color)
        }
        line.addView(ring)

        val col = Ui.vbox(act).apply { setPadding(Ui.dp(act, 12), 0, Ui.dp(act, 8), 0) }
        col.addView(Ui.text(act, u.name, Ui.TITLE_S))
        val lv = when {
            u.targetLevel <= 1 -> "Bangun baru"
            else -> "Lv ${u.targetLevel - 1} → ${u.targetLevel}"
        }
        col.addView(Ui.muted(act, if (done) "$lv · selesai, ketuk untuk tandai" else lv))
        val pills = Ui.hbox(act)
        if (u.helped && !done) {
            val helperId = if (u.kind == Kind.LAB) GameData.LAB_ASSISTANT else GameData.APPRENTICE
            val level = b?.village?.helper(helperId)?.level
            val name = if (u.kind == Kind.LAB) "Lab Assistant" else "Apprentice"
            pills.addView(Ui.pill(act, if (level != null) "$name +${level}j/hari" else "dibantu $name", if (u.kind == Kind.LAB) Ui.VIOLET else Ui.GREEN))
        }
        if (u.note.contains("⚡") && !done) pills.addView(Ui.pill(act, "⚡ dipercepat", Ui.GOLD).also { marginStart(it, act) })
        if (u.id.contains("|manual|") && !done) pills.addView(Ui.pill(act, "dimulai di aplikasi", Ui.GREY).also { marginStart(it, act) })
        if (pills.childCount > 0) col.addView(pills, Ui.matchWrap().apply { topMargin = Ui.dp(act, 3) })
        line.addView(col, Ui.weight1())

        val right = Ui.vbox(act).apply { gravity = Gravity.END }
        val cd = Ui.text(act, if (done) "Selesai" else act.countdown(u.finishAt - now), Ui.TITLE_S).apply {
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(if (done) Ui.GREEN else Ui.onSurface(act))
            gravity = Gravity.END
        }
        if (!done) act.registerCountdown(cd, u.finishAt, clockStyle = false)
        right.addView(cd)
        right.addView(Ui.muted(act, short(u.finishAt, now, zone)).apply { gravity = Gravity.END })
        line.addView(right)
        return line
    }

    private fun marginStart(v: View, act: MainActivity) {
        v.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { marginStart = Ui.dp(act, 6) }
    }

    /** "Sab 11:34" (hari ini: "11:34"). */
    private fun short(t: Long, now: Long, zone: ZoneId): String {
        val d1 = java.time.Instant.ofEpochMilli(t).atZone(zone).toLocalDate()
        val d0 = java.time.Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        val time = Fmt.time(t, zone)
        return if (d1 == d0) time else java.time.format.DateTimeFormatter.ofPattern("EEE", Fmt.locale).format(d1) + " " + time
    }

    // ---------------------------------------------------------------- helper

    private fun helpers(act: MainActivity, box: LinearLayout, tag: String, ups: List<Upgrade>, b: PlanBundle?, now: Long, zone: ZoneId) {
        val ids = listOf(GameData.APPRENTICE to "Builder's Apprentice", GameData.LAB_ASSISTANT to "Lab Assistant")
        val cards = ArrayList<View>()
        for ((id, name) in ids) {
            val level = b?.village?.helper(id)?.level
            val timer = ups.firstOrNull { it.id == "$tag|helpers|$id" }
            if (level == null && timer == null) continue
            val (card, col) = Ui.card(act, padH = 12, padV = 10)
            col.addView(Ui.text(act, name, Ui.TITLE_S).apply { textSize = 13f })
            val lv = level?.let { "Lv $it · " } ?: ""
            val state = if (timer != null && timer.finishAt > now) {
                val what = timer.title().substringAfter("$name ").ifBlank { "siap lagi" }
                "$lv$what · ${short(timer.finishAt, now, zone)}"
            } else "${lv}siap dipakai"
            col.addView(Ui.muted(act, state))
            cards += card
        }
        if (cards.isEmpty()) return
        box.addView(Ui.sectionRow(act, "Helper"))
        val row = Ui.hbox(act).apply { gravity = Gravity.TOP }
        cards.forEachIndexed { i, c ->
            c.layoutParams = Ui.weight1().apply { if (i > 0) marginStart = Ui.dp(act, 8) }
            row.addView(c)
        }
        box.addView(row)
    }

    // ---------------------------------------------------------------- lihat opsi

    object Options {
        fun show(act: MainActivity, tag: String, slot: LaneSlot, canStart: Boolean) {
            val zone = ZoneId.systemDefault()
            val list = slot.ranked.take(60)
            val labels = ArrayList<CharSequence>()
            list.forEachIndexed { i, p ->
                val star = if (i == 0) "★ " else ""
                labels += "$star${p.c.title}\n   ${pickLineStatic(p, zone)}"
            }
            if (slot.cwlSkipped.isNotEmpty()) labels += "⚔️ Disembunyikan (CWL): " + slot.cwlSkipped.joinToString(", ") { it.title }
            val title = if (canStart) "Pilih yang Anda mulai di game" else "Opsi saat bebas ${Fmt.at(slot.start, zone)}"
            MaterialAlertDialogBuilder(act)
                .setTitle(title)
                .setItems(labels.toTypedArray()) { _, w ->
                    if (!canStart || w >= list.size) return@setItems
                    act.startPick(tag, list[w])
                }
                .setNegativeButton("Tutup", null)
                .show()
        }

        private fun pickLineStatic(p: Scored, zone: ZoneId): String {
            val c = p.c
            val cost = if (c.cost > 0) "${Fmt.money(c.cost)} ${Fmt.resource(c.item.resource)}" else "gratis"
            val timing = if (p.idle > 30 * 60_000L) "💤 nganggur ${Fmt.dur(p.idle)}" else "selesai ${Fmt.at(p.finish, zone)}"
            return "${Fmt.durSec(c.duration)} · $cost · $timing"
        }
    }
}
