package id.clashtimer

import android.view.View
import android.widget.LinearLayout
import id.clashtimer.core.CatProgress
import id.clashtimer.core.DAY
import id.clashtimer.core.Fmt
import id.clashtimer.core.Lane
import id.clashtimer.core.Planner
import id.clashtimer.core.SimResult
import id.clashtimer.core.VillageProgress
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Tab "Progres": seberapa jauh menuju max TH / BH. */
object ProgressView {

    fun render(act: MainActivity, box: LinearLayout, b: PlanBundle, bb: Boolean) {
        val zone = ZoneId.systemDefault()
        val p = if (bb) b.bb else b.home
        val sim = if (bb) b.simBB else b.simHome
        if (p == null) {
            box.addView(Ui.muted(act, "Belum ada data Builder Base di export desa ini.", Ui.BODY_M).apply {
                setPadding(Ui.dp(act, 4), Ui.dp(act, 24), 0, 0)
            })
            return
        }
        summary(act, box, p, sim, b, zone)

        val open = p.categories.filter { it.remainingSec > 0 }.sortedBy { it.pct }
        val doneCats = p.categories.filter { it.remainingSec <= 0 }
        box.addView(Ui.sectionRow(act, "Kategori", "sisa biaya"))
        val (card, col) = Ui.card(act, padH = 0, padV = 0)
        var n = 0
        for (c in open) {
            if (n++ > 0) col.addView(Ui.divider(act))
            col.addView(categoryRow(act, c))
        }
        p.walls?.let { w ->
            if (n++ > 0) col.addView(Ui.divider(act))
            val pct = if (w.total > 0) 100.0 * w.atMax / w.total else 100.0
            val r = Ui.vbox(act).apply { setPadding(Ui.dp(act, 14), Ui.dp(act, 10), Ui.dp(act, 14), Ui.dp(act, 10)) }
            val head = Ui.hbox(act)
            head.addView(Ui.text(act, "Tembok", Ui.TITLE_S), Ui.weight1())
            head.addView(Ui.text(act, "${w.atMax}/${w.total}", Ui.TITLE_S))
            r.addView(head)
            r.addView(Ui.bar(act, pct))
            val levels = w.levels.entries.sortedByDescending { it.key }.joinToString(" · ") { "${it.value}× Lv${it.key}" }
            r.addView(Ui.muted(act, if (w.costLeft > 0) "$levels\nsisa ±${Fmt.money(w.costLeft)} gold/elixir · max Lv${w.maxLevel}" else "Semua di Lv${w.maxLevel} (max) ✓"))
            col.addView(r)
        }
        if (doneCats.isNotEmpty()) {
            if (n > 0) col.addView(Ui.divider(act))
            val r = Ui.hbox(act).apply { setPadding(Ui.dp(act, 14), Ui.dp(act, 12), Ui.dp(act, 14), Ui.dp(act, 12)) }
            r.addView(Ui.text(act, "✓ " + doneCats.joinToString(", ") { it.title }, Ui.TITLE_S).apply { setTextColor(Ui.GREEN) }, Ui.weight1())
            r.addView(Ui.muted(act, "sudah max"))
            col.addView(r)
        }
        box.addView(card)

        box.addView(Ui.muted(act,
            "Perkiraan memperhitungkan jam istirahat, helper, Gold Pass dan CWL (hero), tanpa potion/book. " +
                "Town Hall & tembok tidak ikut dihitung. Data durasi game ${Repo.gameData(act).version}.").apply {
            setPadding(Ui.dp(act, 4), Ui.dp(act, 14), Ui.dp(act, 4), 0)
        })
    }

    private fun summary(act: MainActivity, box: LinearLayout, p: VillageProgress, sim: SimResult?, b: PlanBundle, zone: ZoneId) {
        val now = b.computedAt
        val hall = if (p.bb) "BH${p.hall}" else "TH${p.hall}"
        val (card, col) = Ui.card(act, padV = 14)
        col.addView(Ui.muted(act, "$hall menuju max", Ui.BODY_M))
        col.addView(Ui.text(act, Ui.pct(p.pct), Ui.TITLE_L).apply { textSize = 34f })
        col.addView(Ui.bar(act, p.pct))

        val builderLane = if (p.bb) Lane.BB_BUILDER else Lane.BUILDER
        val labLane = if (p.bb) Lane.STAR_LAB else Lane.LAB
        val builders = Planner.laneCount(b.village, builderLane, b.ps).coerceAtLeast(1)
        val bRem = p.remaining(builderLane) * 1000
        val lRem = p.remaining(labLane) * 1000

        val boxes = Ui.hbox(act).apply { setPadding(0, Ui.dp(act, 8), 0, 0) }
        fun metric(label: String, done: Long?, remaining: Long, first: Boolean) {
            val m = Ui.vbox(act).apply {
                background = Ui.tint(Ui.GREY, Ui.dp(act, 8).toFloat(), 0x1A)
                setPadding(Ui.dp(act, 10), Ui.dp(act, 8), Ui.dp(act, 10), Ui.dp(act, 8))
            }
            m.addView(Ui.muted(act, label))
            val value = when {
                remaining <= 0 -> "Sudah max ✓"
                done != null && done > now -> "±" + monthYear(done, zone)
                else -> Fmt.bigDur(remaining)
            }
            m.addView(Ui.text(act, value, Ui.TITLE_S))
            if (remaining > 0 && done != null && done > now) m.addView(Ui.muted(act, days(done - now)))
            boxes.addView(m, Ui.weight1().apply { if (!first) marginStart = Ui.dp(act, 8) })
        }
        metric(if (p.bb) "Builder BB selesai" else "Builder selesai", sim?.let { if (p.bb) it.bbBuilderDone else it.builderDone }, bRem, true)
        metric(if (p.bb) "Star Lab selesai" else "Lab selesai", sim?.let { if (p.bb) it.starLabDone else it.labDone }, lRem, false)
        col.addView(boxes, Ui.matchWrap())

        val parts = ArrayList<String>()
        if (bRem > 0) parts += "${days0(bRem)} hari kerja builder (÷$builders ≈ ${days0(bRem / builders)} hari)"
        if (lRem > 0) parts += "${days0(lRem)} hari ${labLane.label.lowercase()}"
        val pRem = if (!p.bb) p.remaining(Lane.PET) * 1000 else 0
        if (pRem > 0) parts += "${days0(pRem)} hari pet"
        if (parts.isNotEmpty()) col.addView(Ui.muted(act, parts.joinToString(" · ")).apply { setPadding(0, Ui.dp(act, 8), 0, 0) })
        box.addView(card)
    }

    private fun categoryRow(act: MainActivity, c: CatProgress): View {
        val r = Ui.vbox(act).apply {
            setPadding(Ui.dp(act, 14), Ui.dp(act, 10), Ui.dp(act, 14), Ui.dp(act, 10))
            isClickable = true
        }
        val head = Ui.hbox(act)
        head.addView(Ui.text(act, c.title, Ui.TITLE_S), Ui.weight1())
        head.addView(Ui.text(act, Ui.pct(c.pct), Ui.TITLE_S))
        r.addView(head)
        r.addView(Ui.bar(act, c.pct))
        val costs = Fmt.costs(c.costs)
        r.addView(Ui.muted(act, listOf(costs, "${Fmt.bigDur(c.remainingSec * 1000)} kerja").filter { it.isNotBlank() }.joinToString(" · ")))

        if (c.rows.isNotEmpty()) {
            val list = Ui.vbox(act).apply { visibility = View.GONE; setPadding(0, Ui.dp(act, 6), 0, 0) }
            fun fill(all: Boolean) {
                list.removeAllViews()
                val shown = if (all) c.rows else c.rows.take(8)
                for (row in shown) {
                    val up = if (row.upgrading) " ⏳" else ""
                    list.addView(Ui.text(act, "${row.name}$up", Ui.BODY_M))
                    list.addView(Ui.muted(act, "   ${row.detail} · ${Fmt.bigDur(row.remainingSec * 1000)}").apply {
                        setPadding(0, 0, 0, Ui.dp(act, 4))
                    })
                }
                if (!all && c.rows.size > shown.size) {
                    list.addView(Ui.flat(act, "Lihat semua ${c.rows.size}") { fill(true) }.apply { isAllCaps = false })
                }
            }
            fill(false)
            r.addView(list)
            val hint = Ui.muted(act, "Ketuk untuk melihat ${c.rows.size} item ▾")
            r.addView(hint)
            r.setOnClickListener {
                val show = list.visibility != View.VISIBLE
                list.visibility = if (show) View.VISIBLE else View.GONE
                hint.text = if (show) "Sembunyikan ▴" else "Ketuk untuk melihat ${c.rows.size} item ▾"
            }
        }
        return r
    }

    private fun monthYear(t: Long, zone: ZoneId): String =
        DateTimeFormatter.ofPattern("MMM yyyy", Fmt.locale).format(Instant.ofEpochMilli(t).atZone(zone))

    private fun days(ms: Long): String {
        val d = ms / DAY.toDouble()
        return if (d < 1) "kurang dari sehari lagi" else "±${Math.round(d)} hari lagi"
    }

    private fun days0(ms: Long): Long = Math.round(ms / DAY.toDouble())
}
