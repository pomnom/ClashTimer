package id.clashtimer

import android.view.View
import android.widget.LinearLayout
import id.clashtimer.core.DAY
import id.clashtimer.core.Fmt
import id.clashtimer.core.Lane
import id.clashtimer.core.SimResult
import id.clashtimer.core.VillageProgress
import java.time.ZoneId

/** Tab "Progres": seberapa jauh menuju max TH / BH. */
object ProgressView {

    fun render(act: MainActivity, box: LinearLayout, b: PlanBundle) {
        val zone = ZoneId.systemDefault()
        village(act, box, b.home, b.simHome, b, zone)
        b.bb?.let { bb ->
            box.addView(Ui.section(act, "🛠️ Builder Base"))
            village(act, box, bb, b.simBB, b, zone)
        }
        box.addView(Ui.muted(act,
            "Perkiraan memperhitungkan jam istirahat, helper, Gold Pass dan CWL (hero), tanpa potion/book. " +
                "Town Hall & tembok tidak termasuk. Durasi dari data game ${Repo.gameData(act).version}.").apply {
            setPadding(Ui.dp(act, 4), Ui.dp(act, 16), Ui.dp(act, 4), 0)
        })
    }

    private fun village(act: MainActivity, box: LinearLayout, p: VillageProgress, sim: SimResult?, b: PlanBundle, zone: ZoneId) {
        val now = b.computedAt
        val hallName = if (p.bb) "Builder Hall ${p.hall}" else "Town Hall ${p.hall}"
        val (card, col) = Ui.card(act, padV = 14, tinted = true)
        col.addView(Ui.text(act, "$hallName · ${Ui.pct(p.pct)} menuju max", Ui.TITLE_M))
        col.addView(Ui.bar(act, p.pct))

        val builderLane = if (p.bb) Lane.BB_BUILDER else Lane.BUILDER
        val labLane = if (p.bb) Lane.STAR_LAB else Lane.LAB
        val builders = id.clashtimer.core.Planner.laneCount(b.village, builderLane, b.ps).coerceAtLeast(1)
        val bRem = p.remaining(builderLane) * 1000
        val lRem = p.remaining(labLane) * 1000
        val pRem = p.remaining(Lane.PET) * 1000

        fun estimate(label: String, done: Long?, remaining: Long) {
            if (remaining <= 0) {
                col.addView(Ui.text(act, "✅ $label: sudah max", Ui.BODY_M))
                return
            }
            val d = done?.takeIf { it > now }
            val line = if (d != null) "$label: ±${Fmt.date(d, zone)} (${days(d - now)})" else "$label: ${Fmt.bigDur(remaining)} kerja"
            col.addView(Ui.text(act, line, Ui.BODY_M))
        }
        estimate("🔨 Builder selesai", sim?.let { if (p.bb) it.bbBuilderDone else it.builderDone }, bRem)
        col.addView(Ui.muted(act, "   sisa ${Fmt.bigDur(bRem)} kerja builder ÷ $builders builder ≈ ${Fmt.bigDur(bRem / builders)}"))
        estimate(if (p.bb) "⭐ Star Lab selesai" else "🧪 Lab selesai", sim?.let { if (p.bb) it.starLabDone else it.labDone }, lRem)
        if (!p.bb && p.categories.any { it.lane == Lane.PET }) estimate("🐾 Pet selesai", sim?.petDone, pRem)
        if (sim != null && !p.bb && sim.builderIdle7d > 0) {
            col.addView(Ui.muted(act, "Builder menganggur 7 hari ke depan (karena offline): ±${Fmt.dur(sim.builderIdle7d)}"))
        }
        if (sim?.truncated == true) col.addView(Ui.muted(act, "Perkiraan dipotong (terlalu panjang)."))
        box.addView(card)

        for (c in p.categories) {
            val (cc, ccol) = Ui.card(act)
            val head = Ui.hbox(act)
            head.addView(Ui.text(act, c.title, Ui.TITLE_S), Ui.weight1())
            head.addView(Ui.text(act, Ui.pct(c.pct), Ui.TITLE_S).apply { setTextColor(Ui.primary(act)) })
            ccol.addView(head)
            ccol.addView(Ui.bar(act, c.pct))
            val costs = Fmt.costs(c.costs)
            val sub = if (c.remainingSec <= 0) "Semua sudah max ✓"
            else "Sisa ${Fmt.bigDur(c.remainingSec * 1000)} kerja · ${c.doneLevels}/${c.totalLevels} level" +
                (if (costs.isNotBlank()) "\n$costs" else "")
            ccol.addView(Ui.muted(act, sub))
            if (c.rows.isNotEmpty()) {
                val list = Ui.vbox(act).apply { visibility = View.GONE; setPadding(0, Ui.dp(act, 6), 0, 0) }
                for (r in c.rows) {
                    val up = if (r.upgrading) " ⏳" else ""
                    list.addView(Ui.text(act, "${r.name}$up", Ui.BODY_M))
                    list.addView(Ui.muted(act, "   ${r.detail} · ${Fmt.bigDur(r.remainingSec * 1000)}").apply {
                        setPadding(0, 0, 0, Ui.dp(act, 4))
                    })
                }
                ccol.addView(list)
                val toggle = Ui.flat(act, "Lihat ${c.rows.size} item ▾") {}
                toggle.setOnClickListener {
                    val show = list.visibility != View.VISIBLE
                    list.visibility = if (show) View.VISIBLE else View.GONE
                    toggle.text = if (show) "Sembunyikan ▴" else "Lihat ${c.rows.size} item ▾"
                }
                ccol.addView(toggle)
            }
            box.addView(cc)
        }

        p.walls?.let { w ->
            val (wc, wcol) = Ui.card(act)
            val pct = if (w.total > 0) 100.0 * w.atMax / w.total else 100.0
            val head = Ui.hbox(act)
            head.addView(Ui.text(act, "🧱 Tembok", Ui.TITLE_S), Ui.weight1())
            head.addView(Ui.text(act, "${w.atMax}/${w.total}", Ui.TITLE_S).apply { setTextColor(Ui.primary(act)) })
            wcol.addView(head)
            wcol.addView(Ui.bar(act, pct))
            val levels = w.levels.entries.sortedByDescending { it.key }.joinToString(" · ") { "${it.value}× Lv${it.key}" }
            val cost = if (w.costLeft > 0) "Sisa biaya ±${Fmt.money(w.costLeft)} (gold/elixir) · max Lv${w.maxLevel}" else "Semua max (Lv${w.maxLevel}) ✓"
            wcol.addView(Ui.muted(act, "$levels\n$cost"))
            box.addView(wc)
        }
    }

    private fun days(ms: Long): String {
        val d = ms / DAY.toDouble()
        return if (d < 1) "kurang dari sehari" else "±${Math.round(d)} hari lagi"
    }
}
