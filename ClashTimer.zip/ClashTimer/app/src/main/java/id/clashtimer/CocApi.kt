package id.clashtimer

import android.content.Context
import id.clashtimer.core.DAY
import id.clashtimer.core.Fmt
import id.clashtimer.core.Json
import id.clashtimer.core.arr
import id.clashtimer.core.int
import id.clashtimer.core.obj
import id.clashtimer.core.str
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * API resmi Clash of Clans lewat proxy RoyaleAPI (cocproxy.royaleapi.dev).
 * Key dibuat pengguna sendiri di developer.clashofclans.com dengan IP [PROXY_IP].
 * API ini tidak menyediakan data event (Hammer Jam dll).
 */
object CocApi {
    const val BASE = "https://cocproxy.royaleapi.dev/v1"
    const val PROXY_IP = "45.79.218.79"
    const val DEV_SITE = "https://developer.clashofclans.com"

    class ApiError(val code: Int, message: String) : Exception(message)

    fun enc(tag: String): String = URLEncoder.encode(tag.trim().uppercase(), "UTF-8")

    /** GET [path] → objek JSON. 404 → null bila [allow404]. */
    fun get(key: String, path: String, allow404: Boolean = false): Map<String, Any?>? {
        val conn = URL(BASE + path).openConnection() as HttpURLConnection
        conn.connectTimeout = 10_000
        conn.readTimeout = 15_000
        conn.setRequestProperty("Authorization", "Bearer $key")
        conn.setRequestProperty("Accept", "application/json")
        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code == 404 && allow404) return null
            if (code !in 200..299) {
                val reason = runCatching { Json.parse(text).obj()?.get("reason").str() }.getOrDefault("")
                throw ApiError(code, explain(code, reason))
            }
            return Json.parse(text).obj() ?: throw ApiError(code, "Jawaban API tidak bisa dibaca")
        } finally {
            conn.disconnect()
        }
    }

    private fun explain(code: Int, reason: String): String = when {
        code == 403 && reason.contains("invalidIp", true) ->
            "Akses ditolak: key tidak dibuat untuk IP $PROXY_IP. Buat key baru dengan IP itu."
        code == 403 -> "Akses ditolak (403): token salah, kedaluwarsa, atau IP key bukan $PROXY_IP."
        code == 404 -> "Tidak ditemukan (404): periksa tag desa."
        code == 429 -> "Terlalu banyak permintaan (429). Coba lagi beberapa menit lagi."
        code == 503 -> "Server Clash of Clans sedang maintenance (503)."
        else -> "Gagal ($code${if (reason.isNotBlank()) " $reason" else ""})."
    }

    private val timeFmt = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss.SSSX")

    /** "20261101T080000.000Z" → ms (0 bila gagal). */
    fun time(s: String): Long =
        runCatching { ZonedDateTime.parse(s, timeFmt).toInstant().toEpochMilli() }.getOrDefault(0L)
}

/** Sinkronisasi data dari API resmi: nama & clan, jadwal CWL asli, Gold Pass, cek export ketinggalan. */
object ApiSync {
    private val exec = Executors.newSingleThreadExecutor()
    private val running = AtomicBoolean(false)

    /** Sinkron otomatis saat aplikasi dibuka, paling sering tiap 30 menit. */
    fun maybeSync(act: MainActivity) {
        val key = Store.apiKey(act)
        if (key.isBlank() || Store.accounts(act).isEmpty()) return
        if (System.currentTimeMillis() - Store.apiTried(act) < 30 * 60_000L) return
        syncAsync(act) { act.dataChanged() }
    }

    /** Jalankan di latar; [onDone] dipanggil di thread UI dengan pesan status. */
    fun syncAsync(act: android.app.Activity, onDone: (String) -> Unit) {
        if (!running.compareAndSet(false, true)) return
        val app = act.applicationContext
        exec.execute {
            val msg = try {
                sync(app)
            } catch (e: Throwable) {
                e.message ?: e.javaClass.simpleName
            } finally {
                running.set(false)
            }
            act.runOnUiThread {
                if (!act.isFinishing && !act.isDestroyed) onDone(msg)
            }
        }
    }

    /** Ambil semua data (thread latar). Kembalian: pesan status untuk ditampilkan. */
    fun sync(ctx: Context): String {
        val key = Store.apiKey(ctx).trim()
        if (key.isBlank()) return "Belum ada API key"
        val now = System.currentTimeMillis()
        val zone = ZoneId.systemDefault()
        val notes = ArrayList<String>()
        try {
            // Musim Gold Pass (sama untuk semua akun)
            CocApi.get(key, "/goldpass/seasons/current")?.let { gp ->
                val end = CocApi.time(gp["endTime"].str())
                if (end > 0) {
                    Store.setGoldPassEnd(ctx, end)
                    notes += "Gold Pass s/d ${Fmt.dateShort(end, zone)}"
                }
            }
            var ok = 0
            for (acc in Store.accounts(ctx)) {
                val p = CocApi.get(key, "/players/${CocApi.enc(acc.tag)}") ?: continue
                val clan = p["clan"].obj()
                val heroes = HashMap<String, Int>()
                for (h in p["heroes"].arr().orEmpty()) {
                    val o = h.obj() ?: continue
                    val name = o["name"].str()
                    if (name.isNotBlank()) heroes[name] = o["level"].int()
                }
                Store.setApiPlayer(ctx, acc.tag, Store.ApiPlayer(
                    p["name"].str(), clan?.get("name").str(), clan?.get("tag").str(),
                    p["townHallLevel"].int(), p["builderHallLevel"].int(), heroes, System.currentTimeMillis(),
                ))
                ok++
                // Jadwal CWL asli: hari perang ronde 1 sampai akhir ronde 7
                val clanTag = clan?.get("tag").str()
                if (clanTag.isNotBlank()) {
                    val lg = runCatching { CocApi.get(key, "/clans/${CocApi.enc(clanTag)}/currentwar/leaguegroup", allow404 = true) }.getOrNull()
                    val firstTag = lg?.get("rounds").arr()?.firstOrNull()?.obj()?.get("warTags").arr()
                        ?.map { it.str() }?.firstOrNull { it.isNotBlank() && it != "#0" }
                    if (firstTag != null) {
                        val w = runCatching { CocApi.get(key, "/clanwarleagues/wars/${CocApi.enc(firstTag)}") }.getOrNull()
                        val prep = CocApi.time(w?.get("preparationStartTime").str())
                        val battle = CocApi.time(w?.get("startTime").str()).takeIf { it > 0 } ?: (prep + DAY)
                        if (prep > 0) {
                            val end = prep + 8 * DAY
                            Store.setCwlKnown(ctx, acc.tag, battle, end)
                            notes += "CWL ${Store.villageName(ctx, acc.tag)} ${Fmt.dateShort(battle, zone)}–${Fmt.dateShort(end, zone)}"
                        }
                    }
                }
            }
            val msg = "OK · $ok desa" + if (notes.isNotEmpty()) " · " + notes.joinToString(" · ") else ""
            Store.setApiResult(ctx, msg, now)
            Repo.rebuildGlobalReminders(ctx)
            return msg
        } catch (e: CocApi.ApiError) {
            Store.setApiResult(ctx, e.message ?: "Gagal", now)
            return e.message ?: "Gagal"
        } catch (e: java.io.IOException) {
            val msg = "Tidak bisa terhubung ke proxy (${e.javaClass.simpleName}). Periksa internet."
            Store.setApiResult(ctx, msg, now)
            return msg
        }
    }
}
