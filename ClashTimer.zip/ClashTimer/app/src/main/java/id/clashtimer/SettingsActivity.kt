package id.clashtimer

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import id.clashtimer.core.BBStrategy
import id.clashtimer.core.Fmt
import id.clashtimer.core.Strategy
import java.time.DayOfWeek
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.ZoneOffset

class SettingsActivity : AppCompatActivity() {

    private lateinit var box: LinearLayout

    /** Nada yang sedang dipilih lewat pemilih nada sistem. */
    private var pendingKey: String? = null
    private var pendingMode: ToneMode? = null

    private val ringtonePicker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val key = pendingKey
        val mode = pendingMode
        pendingKey = null
        pendingMode = null
        if (key == null || mode == null || result.resultCode != Activity.RESULT_OK) return@registerForActivityResult
        val data = result.data ?: return@registerForActivityResult
        val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
            data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
        }
        Notifier.changeTone(this, key, mode, uri?.toString())
        render()
        Toast.makeText(this, "Nada disimpan · ${Notifier.toneTitle(this, key)}", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Pengaturan"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        box = Ui.vbox(this).apply { setPadding(Ui.dp(this@SettingsActivity, 16), 0, Ui.dp(this@SettingsActivity, 16), Ui.dp(this@SettingsActivity, 32)) }
        setContentView(ScrollView(this).apply { addView(box) })
        render()
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    private fun render() {
        box.removeAllViews()
        val ps = Store.planSettings(this)
        val s = ps.schedule

        box.addView(Ui.section(this, "😴 Jam istirahat", "Saran memilih upgrade yang selesai saat Anda bisa membuka game"))
        switchRow("Hitung jam tidur", s.sleep.enabled) { Store.putPlan(this, "sleep_on", it); render() }
        if (s.sleep.enabled) {
            row("Tidur", "${Fmt.clock(s.sleep.startMin)} – ${Fmt.clock(s.sleep.endMin)}") {
                pickRange("Jam tidur", "sleep_start", "sleep_end", s.sleep.startMin, s.sleep.endMin)
            }
        }
        switchRow("Hitung jam kerja / sekolah", s.work.enabled) { Store.putPlan(this, "work_on", it); render() }
        if (s.work.enabled) {
            row("Jam kerja", "${Fmt.clock(s.work.startMin)} – ${Fmt.clock(s.work.endMin)}") {
                pickRange("Jam kerja", "work_start", "work_end", s.work.startMin, s.work.endMin)
            }
            val days = DayOfWeek.entries.filter { it in s.work.days }.joinToString(", ") { dayName(it) }
            row("Hari kerja", days.ifBlank { "tidak ada" }) { pickDays() }
        }

        box.addView(Ui.section(this, "🎫 Gold Pass", "Diskon waktu upgrade dari Gold Pass musim ini (lihat di game)"))
        row("Builder Boost", "${ps.gold.builderPct}%") { pickPct("Builder Boost", "gp_builder", ps.gold.builderPct) }
        row("Research Boost", "${ps.gold.researchPct}%") { pickPct("Research Boost", "gp_research", ps.gold.researchPct) }

        box.addView(Ui.section(this, "⚔️ Clan War League"))
        switchRow("Lewati upgrade hero yang bentrok CWL", ps.cwl.enabled) { Store.putPlan(this, "cwl_on", it); render() }
        if (ps.cwl.enabled) {
            row("Lama CWL", "${ps.cwl.days} hari") { pickCwlDays(ps.cwl.days) }
            val start = ZonedDateTime.of(2026, 1, 1, ps.cwl.startUtcHour, 0, 0, 0, ZoneOffset.UTC)
                .withZoneSameInstant(ZoneId.systemDefault())
            box.addView(Ui.muted(this, "CWL dianggap mulai tanggal 1 setiap bulan pukul ${Fmt.clock(start.hour * 60 + start.minute)} waktu HP Anda. " +
                "Upgrade hero yang masih berjalan pada rentang itu tidak disarankan, supaya hero siap untuk war.").apply {
                setPadding(Ui.dp(this@SettingsActivity, 4), 0, Ui.dp(this@SettingsActivity, 4), Ui.dp(this@SettingsActivity, 4))
            })
        }

        box.addView(Ui.section(this, "💡 Saran"))
        row("Strategi Home Village", ps.strategy.label) { pickStrategy(ps.strategy) }
        row("Strategi Builder Base", ps.bbStrategy.label) { pickBbStrategy(ps.bbStrategy) }
        val bbAuto = if (ps.bbBuilders > 0) "${ps.bbBuilders}" else "Otomatis"
        row("Builder di Builder Base", bbAuto) { pickBbBuilders(ps.bbBuilders) }
        switchRow("Jangan upgrade collector", ps.skipCollectors) { Store.putPlan(this, "skip_collectors", it); render() }
        box.addView(Ui.muted(this, "Gold Mine, Elixir Collector & Dark Elixir Drill (juga di Builder Base) tidak disarankan dan tidak ikut dihitung di progres. Membangun collector baru tetap disarankan.").apply {
            setPadding(Ui.dp(this@SettingsActivity, 4), 0, Ui.dp(this@SettingsActivity, 4), Ui.dp(this@SettingsActivity, 4))
        })

        box.addView(Ui.section(this, "🎉 Event", "Hammer Jam, Builder Base Bonanza, dll."))
        box.addView(Ui.muted(this, "Supercell tidak menyediakan jadwal event yang bisa dibaca aplikasi (ClashClock pun mengisinya manual). " +
            "Saat event muncul di game, aktifkan di sini dan cocokkan tanggalnya — saran, rencana dan timer langsung memakai potongannya.").apply {
            setPadding(Ui.dp(this@SettingsActivity, 4), 0, Ui.dp(this@SettingsActivity, 4), Ui.dp(this@SettingsActivity, 6))
        })
        EventsUi.renderList(this, box) { render() }
        box.addView(Ui.outlined(this, "+ Tambah event") { EventsUi.addPreset(this) { render() } }.apply { isAllCaps = false }, Ui.matchWrap())

        box.addView(Ui.section(this, "🖼️ Ikon"))
        switchRow("Tampilkan ikon bangunan & hero", Store.iconsOn(this)) { Store.setIconsOn(this, it) }
        val mb = Icons.cacheSize(this) / 1024.0 / 1024.0
        box.addView(Ui.outlined(this, String.format(java.util.Locale.ROOT, "Hapus cache ikon (%.1f MB)", mb)) {
            Icons.clearCache(this)
            render()
        }.apply { isAllCaps = false }, Ui.matchWrap())
        box.addView(Ui.muted(this, "Ikon diunduh sekali dari ClashKing Assets (assets.clashk.ing — terima kasih!) lalu disimpan di HP. " +
            "Gambar © Supercell. Clash Timer adalah fan content tidak resmi, tidak berafiliasi dengan dan tidak didukung oleh Supercell.").apply {
            setPadding(Ui.dp(this@SettingsActivity, 4), Ui.dp(this@SettingsActivity, 4), Ui.dp(this@SettingsActivity, 4), Ui.dp(this@SettingsActivity, 4))
        })

        box.addView(Ui.section(this, "🎵 Nada notifikasi", "Alarm keras berbunyi berulang dengan volume alarm sampai notifikasi dibuka, diusap, atau ditekan Matikan"))
        row("Upgrade selesai & helper", Notifier.toneTitle(this, Notifier.KEY_DONE)) { pickTone(Notifier.KEY_DONE) }
        row("Pengingat sebelum selesai", Notifier.toneTitle(this, Notifier.KEY_EARLY)) { pickTone(Notifier.KEY_EARLY) }
        val tests = Ui.hbox(this)
        tests.addView(Ui.outlined(this, "Tes nada selesai") { testTone(Notifier.KEY_DONE) }.apply { isAllCaps = false }, Ui.weight1())
        tests.addView(Ui.outlined(this, "Tes pengingat") { testTone(Notifier.KEY_EARLY) }.apply { isAllCaps = false },
            Ui.weight1().apply { marginStart = Ui.dp(this@SettingsActivity, 8) })
        box.addView(tests)
        box.addView(Ui.outlined(this, "Pengaturan notifikasi Android") {
            runCatching {
                startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
            }
        }.apply { isAllCaps = false }, Ui.matchWrap())

        box.addView(Ui.section(this, "🔔 Notifikasi"))
        val early = Store.earlyMinutes(this)
        row("Pengingat sebelum selesai", if (early == 0) "Tidak ada" else "$early menit sebelumnya") { pickEarly() }
        switchRow("Notifikasi helper", Store.notifyHelpers(this)) {
            Store.setNotifyHelpers(this, it)
            AlarmScheduler.schedule(this)
        }
        switchRow("Mode alarm kuat (paling tepat waktu)", Store.strongAlarm(this)) {
            Store.setStrongAlarm(this, it)
            AlarmScheduler.schedule(this)
        }
        box.addView(Ui.muted(this, "Mode alarm kuat memakai alarm sistem sehingga tidak ditunda saat HP tidur; efeknya ada ikon jam kecil di status bar.").apply {
            setPadding(Ui.dp(this@SettingsActivity, 4), 0, Ui.dp(this@SettingsActivity, 4), Ui.dp(this@SettingsActivity, 8))
        })
    }

    private fun testTone(key: String) {
        if (!Notifier.canNotify(this)) Toast.makeText(this, "Izinkan notifikasi dulu", Toast.LENGTH_SHORT).show()
        else Notifier.test(this, key)
    }

    private fun pickTone(key: String) {
        val all = ToneMode.entries
        val cur = Store.toneMode(this, key)
        val labels = all.map { "${it.label}\n${it.desc}" as CharSequence }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle(if (key == Notifier.KEY_DONE) "Nada upgrade selesai" else "Nada pengingat")
            .setSingleChoiceItems(labels, all.indexOf(cur)) { d, w ->
                d.dismiss()
                val mode = all[w]
                when (mode) {
                    ToneMode.CUSTOM -> openPicker(key, mode, RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_RINGTONE or RingtoneManager.TYPE_ALARM)
                    ToneMode.ALARM -> {
                        MaterialAlertDialogBuilder(this)
                            .setTitle("Alarm keras")
                            .setMessage("Berbunyi berulang dengan volume alarm (biasanya tetap bunyi saat HP senyap/getar) sampai notifikasi dibuka, diusap, atau ditekan Matikan.\n\nPakai nada alarm bawaan HP, atau pilih nada lain?")
                            .setPositiveButton("Nada alarm bawaan") { _, _ ->
                                Notifier.changeTone(this, key, mode, null)
                                render()
                            }
                            .setNeutralButton("Pilih nada") { _, _ -> openPicker(key, mode, RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_RINGTONE) }
                            .setNegativeButton("Batal", null)
                            .show()
                    }
                    else -> {
                        Notifier.changeTone(this, key, mode, null)
                        render()
                    }
                }
            }
            .show()
    }

    private fun openPicker(key: String, mode: ToneMode, type: Int) {
        pendingKey = key
        pendingMode = mode
        val existing = Store.toneUri(this, key)?.let { runCatching { Uri.parse(it) }.getOrNull() }
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, type)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, if (mode == ToneMode.ALARM) "Nada alarm keras" else "Nada notifikasi")
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
            .putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
        if (existing != null) i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, existing)
        try {
            ringtonePicker.launch(i)
        } catch (_: Exception) {
            pendingKey = null
            pendingMode = null
            Toast.makeText(this, "Pemilih nada tidak tersedia di HP ini", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- baris

    private fun row(title: String, value: String, onClick: () -> Unit) {
        val (card, col) = Ui.card(this)
        card.setOnClickListener { onClick() }
        col.addView(Ui.text(this, title, Ui.TITLE_S))
        col.addView(Ui.text(this, value, Ui.BODY_M).apply { setTextColor(Ui.primary(this@SettingsActivity)) })
        box.addView(card)
    }

    private fun switchRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
        val (card, col) = Ui.card(this)
        val line = Ui.hbox(this)
        val label: TextView = Ui.text(this, title, Ui.TITLE_S)
        line.addView(label, Ui.weight1())
        val sw = SwitchCompat(this)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, isChecked -> onChange(isChecked) }
        line.addView(sw)
        card.setOnClickListener { sw.isChecked = !sw.isChecked }
        col.addView(line)
        box.addView(card)
    }

    // ---------------------------------------------------------------- pemilih

    private fun pickRange(title: String, startKey: String, endKey: String, start: Int, end: Int) {
        TimePickerDialog(this, { _, h1, m1 ->
            val newStart = h1 * 60 + m1
            TimePickerDialog(this, { _, h2, m2 ->
                Store.putPlan(this, startKey, newStart)
                Store.putPlan(this, endKey, h2 * 60 + m2)
                render()
            }, end / 60, end % 60, true).apply { setTitle("$title: selesai") }.show()
        }, start / 60, start % 60, true).apply { setTitle("$title: mulai") }.show()
    }

    private fun dayName(d: DayOfWeek): String = when (d) {
        DayOfWeek.MONDAY -> "Sen"
        DayOfWeek.TUESDAY -> "Sel"
        DayOfWeek.WEDNESDAY -> "Rab"
        DayOfWeek.THURSDAY -> "Kam"
        DayOfWeek.FRIDAY -> "Jum"
        DayOfWeek.SATURDAY -> "Sab"
        DayOfWeek.SUNDAY -> "Min"
    }

    private fun pickDays() {
        val all = DayOfWeek.entries
        val mask = Store.getInt(this, "work_days", Store.DEFAULT_WORK_DAYS)
        val checked = BooleanArray(7) { mask and (1 shl it) != 0 }
        val labels = arrayOf<CharSequence>("Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu")
        MaterialAlertDialogBuilder(this)
            .setTitle("Hari kerja / sekolah")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Simpan") { _, _ ->
                var m = 0
                for (i in all.indices) if (checked[i]) m = m or (1 shl i)
                Store.putPlan(this, "work_days", m)
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun pickPct(title: String, key: String, cur: Int) {
        val options = intArrayOf(0, 10, 15, 20)
        val labels = options.map { (if (it == 0) "0% (tidak ada)" else "$it%") as CharSequence }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels, options.indexOf(cur).coerceAtLeast(0)) { d, w ->
                Store.putPlan(this, key, options[w])
                d.dismiss()
                render()
            }
            .show()
    }

    private fun pickCwlDays(cur: Int) {
        val options = (7..12).toList()
        val labels = options.map { "$it hari" as CharSequence }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Lama CWL")
            .setSingleChoiceItems(labels, options.indexOf(cur).coerceAtLeast(0)) { d, w ->
                Store.putPlan(this, "cwl_days", options[w])
                d.dismiss()
                render()
            }
            .show()
    }

    private fun pickStrategy(cur: Strategy) {
        val all = Strategy.entries
        val labels = all.map { "${it.label}\n${it.desc}" as CharSequence }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Strategi saran")
            .setSingleChoiceItems(labels, all.indexOf(cur)) { d, w ->
                Store.putPlan(this, "strategy", all[w].name)
                d.dismiss()
                render()
            }
            .show()
    }

    private fun pickBbStrategy(cur: BBStrategy) {
        val all = BBStrategy.entries
        val labels = all.map { "${it.label}\n${it.desc}" as CharSequence }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Strategi Builder Base")
            .setSingleChoiceItems(labels, all.indexOf(cur)) { d, w ->
                Store.putPlan(this, "bb_strategy", all[w].name)
                d.dismiss()
                render()
            }
            .show()
    }

    private fun pickBbBuilders(cur: Int) {
        val options = intArrayOf(0, 1, 2, 3)
        val labels = options.map { (if (it == 0) "Otomatis dari export" else "$it builder") as CharSequence }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Builder di Builder Base")
            .setSingleChoiceItems(labels, options.indexOf(cur).coerceAtLeast(0)) { d, w ->
                Store.putPlan(this, "bb_builders", options[w])
                d.dismiss()
                render()
            }
            .show()
    }

    private fun pickEarly() {
        val options = intArrayOf(0, 5, 10, 15, 30, 60)
        val labels = options.map { (if (it == 0) "Tidak ada (hanya saat selesai)" else "$it menit sebelumnya") as CharSequence }.toTypedArray()
        val current = options.indexOf(Store.earlyMinutes(this)).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Pengingat tambahan")
            .setSingleChoiceItems(labels, current) { d, which ->
                val min = options[which]
                Store.setEarlyMinutes(this, min)
                // Yang sudah masuk jendela pengingat tidak perlu diberi pengingat mendadak.
                val now = System.currentTimeMillis()
                val list = Store.upgrades(this)
                list.forEach { u -> u.earlyNotified = u.doneNotified || (min > 0 && u.finishAt - min * 60_000L <= now) }
                Store.saveUpgrades(this, list)
                AlarmScheduler.schedule(this)
                d.dismiss()
                render()
            }
            .show()
    }
}
