package id.clashtimer

import android.content.DialogInterface
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import id.clashtimer.core.Boosts
import id.clashtimer.core.Fmt
import id.clashtimer.core.Lane
import id.clashtimer.core.MagicItem
import id.clashtimer.core.Planner
import java.time.ZoneId

/** Dialog untuk mencatat pemakaian potion, book dan hammer. */
object ItemsUi {

    fun open(act: MainActivity, tag: String) {
        val owned = Store.items(act, tag)
        val items = MagicItem.entries
        val labels = ArrayList<CharSequence>()
        for (mi in items) {
            val n = owned[mi] ?: 0
            val extra = when {
                mi.boost != null -> " · ${mi.boost.speedLabel} selama 1 jam"
                mi.isBook -> " · selesaikan upgrade berjalan"
                else -> " · naik 1 level instan"
            }
            labels += "${mi.emoji} ${mi.label}" + (if (n > 0) " (punya $n)" else "") + extra
        }
        labels += "📝 Atur jumlah item yang dimiliki"
        labels += "↩️ Batalkan catatan item"
        MaterialAlertDialogBuilder(act)
            .setTitle("Pakai item · $tag")
            .setItems(labels.toTypedArray()) { _, w ->
                when {
                    w < items.size -> use(act, tag, items[w])
                    w == items.size -> editCounts(act, tag)
                    else -> undo(act, tag)
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun consume(act: MainActivity, tag: String, mi: MagicItem) {
        val n = Store.items(act, tag)[mi] ?: 0
        if (n > 0) Store.setItem(act, tag, mi, n - 1)
    }

    private fun use(act: MainActivity, tag: String, mi: MagicItem) {
        when {
            mi.boost != null -> usePotion(act, tag, mi)
            mi.isBook -> useBook(act, tag, mi)
            else -> useHammer(act, tag, mi)
        }
    }

    private fun usePotion(act: MainActivity, tag: String, mi: MagicItem) {
        val kind = mi.boost ?: return
        val offsets = intArrayOf(0, 10, 20, 30, 45)
        val labels = offsets.map { (if (it == 0) "Baru saja" else "$it menit lalu") as CharSequence }.toTypedArray()
        MaterialAlertDialogBuilder(act)
            .setTitle("${mi.label} mulai kapan?")
            .setItems(labels) { _, w ->
                val now = System.currentTimeMillis()
                val at = now - offsets[w] * 60_000L
                val before = Repo.finishes(act, tag)
                Store.setBoosts(act, tag, Boosts.add(Store.boosts(act, tag), kind, at))
                consume(act, tag, mi)
                Repo.reproject(act, tag)
                val after = Store.upgrades(act).filter { it.tag == tag }
                val zone = ZoneId.systemDefault()
                val changes = after.mapNotNull { u ->
                    val b = before[u.id] ?: return@mapNotNull null
                    if (b - u.finishAt > 60_000) "• ${u.title()}: ${Fmt.time(b, zone)} → ${Fmt.at(u.finishAt, zone)} (−${Fmt.dur(b - u.finishAt)})" else null
                }
                act.dataChanged()
                val lanes = kind.lanes.joinToString(" & ") { it.label }
                val msg = if (changes.isEmpty()) "Tidak ada $lanes yang sedang berjalan, jadi tidak ada timer yang berubah."
                else "Waktu selesai diperbarui dan notifikasi dijadwalkan ulang:\n\n" + changes.joinToString("\n")
                MaterialAlertDialogBuilder(act).setTitle("⚡ ${mi.label} dicatat").setMessage(msg)
                    .setPositiveButton("OK", null).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun useBook(act: MainActivity, tag: String, mi: MagicItem) {
        val v = Repo.village(act, tag) ?: return
        val fin = Repo.finishes(act, tag)
        val now = System.currentTimeMillis()
        val running = v.insts.filter { it.upgrading && mi.fits(it.item.cat) }
            .map { it to (fin[it.uid] ?: (v.exportAt + it.remaining * 1000)) }
            .filter { it.second > now }
            .sortedByDescending { it.second }
        if (running.isEmpty()) {
            MaterialAlertDialogBuilder(act).setTitle(mi.label)
                .setMessage("Tidak ada upgrade yang cocok untuk ${mi.label} yang sedang berjalan.")
                .setPositiveButton("OK", null).show()
            return
        }
        val labels = running.mapIndexed { i, (inst, f) ->
            val best = if (i == 0) "★ " else ""
            "$best${inst.item.name} → Lv ${inst.level + 1}\n   hemat ${Fmt.dur(f - now)}" as CharSequence
        }.toTypedArray()
        MaterialAlertDialogBuilder(act)
            .setTitle("${mi.label} untuk…")
            .setItems(labels) { _, w ->
                val inst = running[w].first
                Store.setDone(act, tag, Store.done(act, tag) + (inst.uid to System.currentTimeMillis()))
                consume(act, tag, mi)
                Repo.reproject(act, tag)
                act.dataChanged()
                MaterialAlertDialogBuilder(act).setTitle("📘 Dicatat")
                    .setMessage("${inst.item.name} → Lv ${inst.level + 1} ditandai selesai. Builder/lab-nya sekarang dihitung bebas di tab Saran.")
                    .setPositiveButton("OK", null).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun useHammer(act: MainActivity, tag: String, mi: MagicItem) {
        val v = Repo.village(act, tag) ?: return
        val gd = Repo.gameData(act)
        val ps = Store.planSettings(act)
        val cands = listOf(Lane.BUILDER, Lane.LAB)
            .flatMap { Planner.dedupe(Planner.candidates(v, gd, it, ps.gold, includeHall = true)) }
            .filter { !it.isNew && mi.fits(it.item.cat) }
            .sortedByDescending { it.duration }
        if (cands.isEmpty()) {
            MaterialAlertDialogBuilder(act).setTitle(mi.label)
                .setMessage("Tidak ada target yang tersedia (sudah max atau sedang di-upgrade).")
                .setPositiveButton("OK", null).show()
            return
        }
        val labels = cands.take(40).mapIndexed { i, c ->
            val best = if (i == 0) "★ " else ""
            "$best${c.item.name} → Lv ${c.toLevel}\n   hemat ${Fmt.durSec(c.duration)}" as CharSequence
        }.toTypedArray()
        MaterialAlertDialogBuilder(act)
            .setTitle("${mi.label} untuk…")
            .setItems(labels) { _, w ->
                val c = cands[w]
                Store.setBumps(act, tag, Store.bumps(act, tag) + Triple(c.item.id, c.fromLevel, System.currentTimeMillis()))
                consume(act, tag, mi)
                act.dataChanged()
                MaterialAlertDialogBuilder(act).setTitle("🔨 Dicatat")
                    .setMessage("${c.item.name} sekarang dihitung Lv ${c.toLevel}. Saat import berikutnya, data level diambil lagi dari game.")
                    .setPositiveButton("OK", null).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Atur jumlah item yang dimiliki dengan tombol − / +. */
    fun editCounts(act: MainActivity, tag: String) {
        val col = Ui.vbox(act).apply { setPadding(Ui.dp(act, 20), Ui.dp(act, 8), Ui.dp(act, 12), Ui.dp(act, 8)) }
        for (mi in MagicItem.entries) {
            val row = Ui.hbox(act)
            row.addView(Ui.text(act, "${mi.emoji} ${mi.label}", Ui.BODY_M), Ui.weight1())
            val count = TextView(act).apply {
                text = (Store.items(act, tag)[mi] ?: 0).toString()
                minWidth = Ui.dp(act, 32)
                gravity = android.view.Gravity.CENTER
            }
            fun change(d: Int) {
                val n = ((Store.items(act, tag)[mi] ?: 0) + d).coerceIn(0, 999)
                Store.setItem(act, tag, mi, n)
                count.text = n.toString()
            }
            row.addView(Ui.flat(act, "−") { change(-1) })
            row.addView(count)
            row.addView(Ui.flat(act, "+") { change(1) })
            col.addView(row)
        }
        val scroll = ScrollView(act).apply { addView(col) }
        MaterialAlertDialogBuilder(act)
            .setTitle("Item yang dimiliki · $tag")
            .setView(scroll)
            .setPositiveButton("Selesai", null)
            .setOnDismissListener { act.dataChanged() }
            .show()
    }

    /** Hapus catatan item (kalau salah catat). */
    private fun undo(act: MainActivity, tag: String) {
        val zone = ZoneId.systemDefault()
        val gd = Repo.gameData(act)
        val names = Store.upgrades(act).filter { it.tag == tag }.associate { it.id to it.title() }
        class Entry(val label: String, val remove: () -> Unit)
        val entries = ArrayList<Entry>()
        for (b in Store.boosts(act, tag)) {
            entries += Entry("⚡ ${b.kind.label} · ${Fmt.at(b.start, zone)}") {
                Store.setBoosts(act, tag, Store.boosts(act, tag).filter { it != b })
            }
        }
        for ((uid, at) in Store.done(act, tag)) {
            entries += Entry("✅ ${names[uid] ?: uid.substringAfterLast('|')} selesai · ${Fmt.at(at, zone)}") {
                Store.setDone(act, tag, Store.done(act, tag) - uid)
            }
        }
        for ((uid, at) in Store.cancelled(act, tag)) {
            entries += Entry("✖️ ${uid.split('|').getOrNull(2)?.toIntOrNull()?.let { gd.name(it) } ?: uid} dibatalkan · ${Fmt.at(at, zone)}") {
                Store.setCancelled(act, tag, Store.cancelled(act, tag) - uid)
            }
        }
        for (bm in Store.bumps(act, tag)) {
            entries += Entry("🔨 ${gd.name(bm.first)} Lv${bm.second}→${bm.second + 1} · ${Fmt.at(bm.third, zone)}") {
                Store.setBumps(act, tag, Store.bumps(act, tag).filter { it != bm })
            }
        }
        if (entries.isEmpty()) {
            MaterialAlertDialogBuilder(act).setTitle("Belum ada catatan")
                .setMessage("Belum ada potion, book, hammer, atau tanda selesai yang dicatat sejak import terakhir.")
                .setPositiveButton("OK", null).show()
            return
        }
        MaterialAlertDialogBuilder(act)
            .setTitle("Hapus catatan mana?")
            .setItems(entries.map { it.label as CharSequence }.toTypedArray()) { _: DialogInterface, w: Int ->
                entries[w].remove()
                Repo.reproject(act, tag)
                act.dataChanged()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }
}
