package id.clashtimer

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Notifier {
    const val CH_DONE = "upgrade_done"
    const val CH_EARLY = "upgrade_soon"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "Upgrade selesai", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Builder, lab, pet, atau helper sudah bebas"
                enableVibration(true)
                setSound(sound, attrs)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_EARLY, "Pengingat sebelum selesai", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Pengingat beberapa menit sebelum upgrade selesai"
            }
        )
    }

    fun canNotify(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun done(ctx: Context, u: Upgrade) {
        val body = when (u.kind) {
            Kind.HELPER -> "Helper sudah bisa ditugaskan lagi · ${u.tag}"
            Kind.LAB, Kind.STAR_LAB -> "${u.kind.label} sekarang kosong · ${u.tag}"
            Kind.PET -> "Pet House sekarang kosong · ${u.tag}"
            else -> "${u.kind.label}: 1 builder sekarang bebas · ${u.tag}"
        }
        post(ctx, u.id.hashCode(), CH_DONE, "${u.kind.emoji} ${u.title()}", body)
    }

    fun early(ctx: Context, u: Upgrade, minutes: Int) {
        post(
            ctx, u.id.hashCode() xor 0x5A5A, CH_EARLY,
            "⏳ ${u.title()}",
            "Selesai dalam $minutes menit · ${u.tag}",
        )
    }

    fun test(ctx: Context) {
        post(ctx, 4242, CH_DONE, "🔔 Tes notifikasi", "Kalau ini muncul, notifikasi sudah berfungsi.")
    }

    private fun post(ctx: Context, id: Int, channel: String, title: String, body: String) {
        if (!canNotify(ctx)) return
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(
                if (channel == CH_DONE) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT
            )
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx))
            .setWhen(System.currentTimeMillis())
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }
}
