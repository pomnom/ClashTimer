package id.clashtimer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        processDue(context)
    }

    companion object {
        /** Kirim semua notifikasi yang sudah waktunya, lalu pasang alarm berikutnya. */
        fun processDue(ctx: Context) {
            Notifier.createChannels(ctx)
            val now = System.currentTimeMillis()
            val slack = 2_000L // toleransi kalau alarm berbunyi sepersekian detik lebih awal
            val earlyMin = Store.earlyMinutes(ctx)
            val earlyMs = earlyMin * 60_000L
            val helpers = Store.notifyHelpers(ctx)

            val list = Store.upgrades(ctx)
            var changed = false
            for (u in list) {
                val muted = u.kind == Kind.HELPER && !helpers
                if (!u.doneNotified && now + slack >= u.finishAt) {
                    if (!muted) Notifier.done(ctx, u)
                    u.doneNotified = true
                    u.earlyNotified = true
                    changed = true
                } else if (earlyMs > 0 && !u.earlyNotified && u.kind != Kind.HELPER &&
                    now + slack >= u.finishAt - earlyMs
                ) {
                    val left = ((u.finishAt - now + 59_999) / 60_000).toInt().coerceAtLeast(1)
                    Notifier.early(ctx, u, left)
                    u.earlyNotified = true
                    changed = true
                }
            }
            if (changed) Store.saveUpgrades(ctx, list)
            Store.pruneOld(ctx)
            AlarmScheduler.schedule(ctx)
        }
    }
}

/** Pasang ulang alarm setelah HP restart, aplikasi di-update, atau jam diubah. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmReceiver.processDue(context)
    }
}
