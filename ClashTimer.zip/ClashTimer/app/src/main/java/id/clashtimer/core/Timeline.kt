package id.clashtimer.core

const val MIN = 60_000L
const val HOUR = 3_600_000L
const val DAY = 86_400_000L

/** Lama siklus helper: bekerja 1 jam, cooldown 23 jam sejak ditugaskan. */
const val HELPER_CYCLE = 23 * HOUR
const val HELPER_WORK = HOUR

/** Potion & snack yang mempercepat pekerja. [extra] = tambahan kecepatan (10× → 9). */
enum class BoostKind(val label: String, val lanes: Set<Lane>, val extra: Double, val duration: Long) {
    BUILDER_POTION("Builder Potion", setOf(Lane.BUILDER), 9.0, HOUR),
    RESEARCH_POTION("Research Potion", setOf(Lane.LAB), 23.0, HOUR),
    PET_POTION("Pet Potion", setOf(Lane.PET), 23.0, HOUR),
    BUILDER_BITE("Builder Bite", setOf(Lane.BUILDER), 1.0, HOUR),
    STUDY_SOUP("Study Soup", setOf(Lane.LAB, Lane.PET), 3.0, HOUR);

    val speedLabel: String get() = "${(extra + 1).toInt()}×"
}

/** Boost yang dicatat pengguna. Waktu dalam ms. */
data class Boost(val kind: BoostKind, val start: Long, val end: Long)

object Boosts {
    /**
     * Catat pemakaian boost pada [at]. Boost sejenis tidak menumpuk: bila masih aktif,
     * durasinya diperpanjang (seperti di game).
     */
    fun add(list: List<Boost>, kind: BoostKind, at: Long): List<Boost> {
        val active = list.filter { it.kind == kind && it.end > at }.maxByOrNull { it.end }
        return if (active != null) {
            list.map { if (it === active) it.copy(end = it.end + kind.duration) else it }
        } else list + Boost(kind, at, at + kind.duration)
    }

    /** Setelah import ulang: buang boost yang sudah habis sebelum export, potong sisanya. */
    fun afterImport(list: List<Boost>, exportAt: Long): List<Boost> =
        list.filter { it.end > exportAt }.map { if (it.start < exportAt) it.copy(start = exportAt) else it }

    /** Gabungkan interval boost sejenis (tidak menumpuk). */
    fun merged(list: List<Boost>): List<Boost> {
        val out = ArrayList<Boost>()
        for ((_, group) in list.groupBy { it.kind }) {
            val sorted = group.sortedBy { it.start }
            var cur: Boost? = null
            for (b in sorted) {
                cur = when {
                    cur == null -> b
                    b.start <= cur.end -> cur.copy(end = maxOf(cur.end, b.end))
                    else -> { out += cur; b }
                }
            }
            if (cur != null) out += cur
        }
        return out
    }
}

/** Info helper (Builder's Apprentice / Lab Assistant) yang membantu satu upgrade. */
data class HelperPlan(val level: Int, val firstSession: Long)

data class Projection(
    val finishAt: Long,
    /** Waktu selesai tanpa helper & boost (langsung dari export). */
    val baseFinishAt: Long,
    /** Awal sesi helper yang benar-benar terpakai sebelum selesai. */
    val helperSessions: List<Long>,
)

object Projector {

    private class Seg(val start: Long, val end: Long, val extra: Double)

    /**
     * Hitung kapan upgrade selesai. [remainingSec] = sisa waktu saat [from] (biasanya waktu export).
     * Kecepatan = 1 + jumlah tambahan dari boost aktif & sesi helper (dijumlah, karena
     * potion tidak mempengaruhi helper dan sebaliknya).
     */
    fun project(
        from: Long,
        remainingSec: Long,
        lane: Lane,
        boosts: List<Boost>,
        helper: HelperPlan?,
    ): Projection {
        val base = from + remainingSec * 1000
        val segs = ArrayList<Seg>()
        for (b in Boosts.merged(boosts)) {
            if (lane !in b.kind.lanes) continue
            val s = maxOf(b.start, from)
            if (b.end > s) segs += Seg(s, b.end, b.kind.extra)
        }
        val sessionStarts = ArrayList<Long>()
        if (helper != null && helper.level > 0) {
            var s = maxOf(helper.firstSession, from)
            while (s < base) {
                sessionStarts += s
                segs += Seg(s, s + HELPER_WORK, helper.level.toDouble())
                s += HELPER_CYCLE
            }
        }
        if (segs.isEmpty()) return Projection(base, base, emptyList())

        val points = java.util.TreeSet<Long>()
        points += from
        for (sg in segs) { points += sg.start; points += sg.end }

        var work = (remainingSec * 1000).toDouble() // ms kerja normal yang tersisa
        var t = from
        var finish = -1L
        val iter = points.iterator()
        var prev = iter.next()
        while (iter.hasNext() && finish < 0) {
            val next = iter.next()
            if (next <= t) { prev = next; continue }
            val a = maxOf(prev, t)
            var speed = 1.0
            for (sg in segs) if (sg.start <= a && sg.end > a) speed += sg.extra
            val span = (next - a).toDouble()
            val capacity = span * speed
            if (work <= capacity) {
                finish = a + Math.ceil(work / speed).toLong()
            } else {
                work -= capacity
                t = next
            }
            prev = next
        }
        if (finish < 0) finish = t + Math.ceil(work).toLong()
        val used = sessionStarts.filter { it < finish }
        return Projection(finish, base, used)
    }

    /** Rencana helper untuk satu upgrade menurut export (hanya yang ditandai berulang). */
    fun helperFor(v: Village, lane: Lane, helped: Boolean): HelperPlan? {
        if (!helped) return null
        val id = when (lane) {
            Lane.BUILDER -> GameData.APPRENTICE
            Lane.LAB -> GameData.LAB_ASSISTANT
            else -> return null
        }
        val h = v.helper(id) ?: return null
        return HelperPlan(h.level, v.exportAt + h.cooldown * 1000)
    }
}
