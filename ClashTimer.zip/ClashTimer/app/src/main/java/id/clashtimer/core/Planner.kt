package id.clashtimer.core

import kotlin.math.sqrt

enum class Strategy(val label: String, val desc: String) {
    MAX("Seimbang (max TH)", "Maksimalkan TH sekarang: army, hero & pertahanan penting dulu, Town Hall terakhir"),
    RUSH("Rush TH", "Town Hall secepatnya, lalu offense (hero, army, lab); pertahanan belakangan"),
    HERO("Hero dulu", "Utamakan upgrade hero, lalu army dan pertahanan");
}

class PlanSettings(
    val schedule: OfflineSchedule,
    val cwl: CwlRule,
    val gold: GoldPass,
    val strategy: Strategy,
    /** 0 = otomatis dari export. */
    val bbBuilders: Int = 0,
)

class Candidate(
    val lane: Lane,
    val item: Item,
    /** null = bangunan/hero/pet baru. */
    val inst: Inst?,
    val fromLevel: Int,
    val toLevel: Int,
    /** Detik, sudah termasuk diskon Gold Pass. */
    val duration: Long,
    val cost: Long,
    val isNew: Boolean,
    val count: Int = 1,
) {
    val title: String
        get() = when {
            isNew && item.cat == Cat.HERO -> "Buka ${item.name}"
            isNew && item.cat == Cat.PET -> "Buka ${item.name}"
            isNew -> "Bangun ${item.name}" + if (count > 1) " (sisa $count)" else ""
            else -> "${item.name} → Lv $toLevel" + if (count > 1) "  ×$count" else ""
        }
}

class Scored(
    val c: Candidate,
    val start: Long,
    val finish: Long,
    /** Lama pekerja menganggur setelah selesai karena Anda sedang offline. */
    val idle: Long,
    val score: Double,
)

class LaneSlot(
    val lane: Lane,
    /** Kapan pekerja bebas (≤ now = sudah bebas). */
    val freeAt: Long,
    /** Kapan Anda bisa memulai (online). */
    val start: Long,
    /** Nama upgrade yang selesai dan membebaskan pekerja ini. */
    val freedBy: String?,
    /** Jumlah pekerja yang bebas di slot ini. */
    val count: Int,
    val ranked: List<Scored>,
    val cwlSkipped: List<Candidate>,
)

class PlannedStep(
    val lane: Lane,
    /** Nomor pekerja di jenisnya (B1, B2, …). */
    val laneIndex: Int,
    val title: String,
    val start: Long,
    val finish: Long,
    val idle: Long,
    /** Catatan, mis. hero yang ditunda karena CWL. */
    val note: String? = null,
    val durationSec: Long = 0,
)

/** Sesi helper yang diperkirakan terjadi dalam simulasi. */
class HelperEvent(val time: Long, val lane: Lane, val level: Int, val target: String)

class SimResult(
    val builderDone: Long?,
    val labDone: Long?,
    val petDone: Long?,
    val bbBuilderDone: Long?,
    val starLabDone: Long?,
    val steps: List<PlannedStep>,
    val builderIdle7d: Long,
    val truncated: Boolean,
    val helperEvents: List<HelperEvent> = emptyList(),
)

object Planner {

    private class W(
        val hero: Double, val army: Double, val defense: Double, val trap: Double,
        val storage: Double, val collector: Double, val worker: Double, val townHall: Double,
    )

    private fun weights(s: Strategy) = when (s) {
        Strategy.MAX -> W(2.2, 1.6, 1.0, 0.5, 0.6, 0.3, 0.6, 0.05)
        Strategy.RUSH -> W(3.0, 2.5, 0.2, 0.1, 0.6, 0.02, 0.2, 8.0)
        Strategy.HERO -> W(5.0, 1.6, 0.7, 0.3, 0.4, 0.2, 0.4, 0.05)
    }

    private val keyBuildings = setOf(
        "Army Camp", "Clan Castle", "Laboratory", "Pet House", "Hero Hall",
        "Star Laboratory", "Builder Barracks", "Reinforcement Camp",
    )
    private val keyDefenses = setOf("Inferno Tower", "Eagle Artillery", "Scattershot", "Monolith")

    fun importance(c: Candidate, strategy: Strategy): Double {
        val w = weights(strategy)
        val it = c.item
        val base = when (it.cat) {
            Cat.HERO, Cat.BB_HERO -> w.hero
            Cat.TROOP -> if (it.isSiege) 0.8 else 1.0
            Cat.SPELL, Cat.PET, Cat.BB_TROOP -> 1.0
            Cat.TRAP -> w.trap
            Cat.BUILDING, Cat.BB_BUILDING -> when {
                it.isTownHall -> w.townHall
                it.type == "Army" -> w.army
                it.type == "Defense" -> w.defense
                it.type == "Resource" -> if (it.name.contains("Storage")) w.storage else w.collector
                it.type.startsWith("Worker") -> w.worker
                else -> 1.0
            }
        }
        var mult = 1.0
        if (it.name in keyBuildings) mult *= 3.0
        if (it.name in keyDefenses) mult *= if (strategy == Strategy.RUSH) 4.5 else 2.0
        if (c.isNew) mult *= 2.0
        if (strategy == Strategy.RUSH && it.isTownHall) mult *= 100.0
        return base * mult
    }

    fun score(c: Candidate, start: Long, ps: PlanSettings): Scored {
        val d = c.duration * 1000
        val finish = start + d
        val idle = ps.schedule.nextOnline(finish) - finish
        val hours = c.duration / 3600.0
        val costM = c.cost / 1_000_000.0
        val prio = importance(c, ps.strategy) / sqrt((hours + 0.25) * (costM + 0.05))
        // Efisiensi = bagian waktu pekerja yang benar-benar dipakai. Dikuadratkan supaya
        // sebelum tidur upgrade panjang (yang selesai saat Anda bangun) lebih diutamakan
        // daripada upgrade singkat yang membuat builder menganggur semalaman.
        val eff = if (d + idle <= 0) 1.0 else d.toDouble() / (d + idle).toDouble()
        val choice = prio * eff * eff
        return Scored(c, start, finish, idle, choice)
    }

    // ------------------------------------------------------------------ kandidat

    private fun mergeReady(v: Village, srcs: List<MergeSrc>, self: Inst?): Boolean {
        for ((key, group) in srcs.groupBy { Triple(it.id, it.level, it.geared) }) {
            val avail = v.insts.count {
                it !== self && it.item.id == key.first && !it.upgrading && it.level >= key.second &&
                    (!key.third || it.geared)
            }
            if (avail < group.size) return false
        }
        return true
    }

    /** Jumlah bangunan yang boleh dimiliki, dikurangi yang sudah dilebur ke bangunan gabungan. */
    fun allowed(v: Village, gd: GameData, id: Int, hall: Int, bb: Boolean): Int {
        var n = gd.allowedCount(id, hall, bb)
        for (i in v.insts) {
            for ((lvl, srcs) in i.item.merges) {
                if (lvl <= i.level) n -= srcs.count { it.id == id }
            }
        }
        return n.coerceAtLeast(0)
    }

    private val skipNew = setOf(GameData.HUT, GameData.BOB_HUT, GameData.HELPER_HUT, GameData.WALL, GameData.BB_WALL)

    fun candidates(
        v: Village, gd: GameData, lane: Lane, gold: GoldPass, includeHall: Boolean,
    ): List<Candidate> {
        val out = ArrayList<Candidate>()
        val bb = lane.bb
        val hall = if (bb) v.bh else v.th
        if (bb && hall == 0) return out
        val cats: Set<Cat> = when (lane) {
            Lane.BUILDER -> setOf(Cat.BUILDING, Cat.TRAP, Cat.HERO)
            Lane.LAB -> setOf(Cat.TROOP, Cat.SPELL)
            Lane.PET -> setOf(Cat.PET)
            Lane.BB_BUILDER -> setOf(Cat.BB_BUILDING, Cat.BB_HERO)
            Lane.STAR_LAB -> setOf(Cat.BB_TROOP)
        }
        val reqLevel = when (lane) {
            Lane.LAB -> v.labLevel
            Lane.PET -> v.petHouse
            Lane.STAR_LAB -> v.starLab
            else -> 0
        }
        if ((lane == Lane.LAB || lane == Lane.PET || lane == Lane.STAR_LAB) && reqLevel == 0) return out

        // Upgrade level berikutnya untuk yang sudah ada
        for (inst in v.insts) {
            if (inst.upgrading || inst.item.cat !in cats || inst.item.isWall) continue
            val item = inst.item
            val next = item.lv(inst.level + 1) ?: continue
            if (next.time <= 0) continue
            if (next.hall > hall) continue
            if (item.isTownHall && !includeHall) continue
            when (item.cat) {
                Cat.HERO -> if (next.req > v.heroHall) continue
                Cat.TROOP, Cat.SPELL, Cat.PET, Cat.BB_TROOP -> if (next.req > reqLevel) continue
                else -> {}
            }
            val m = item.merges[inst.level + 1]
            if (m != null && !mergeReady(v, m, inst)) continue
            out += Candidate(lane, item, inst, inst.level, inst.level + 1, gold.apply(next.time, lane), next.cost, false)
        }

        // Bangunan baru yang sudah boleh dibangun
        if (lane == Lane.BUILDER || lane == Lane.BB_BUILDER) {
            for (id in gd.unlockIds(bb)) {
                if (id in skipNew) continue
                val item = gd.item(id) ?: continue
                if (item.cat != Cat.BUILDING && item.cat != Cat.TRAP && item.cat != Cat.BB_BUILDING) continue
                if (item.isWall || item.levels.isEmpty() || item.merges[1] != null) continue
                val lv1 = item.lv(1) ?: continue
                if (lv1.hall > hall) continue
                val missing = allowed(v, gd, id, hall, bb) - v.count(id)
                if (missing <= 0) continue
                out += Candidate(lane, item, null, 0, 1, gold.apply(lv1.time, lane), lv1.cost, true, missing)
            }
        }
        // Hero baru
        if (lane == Lane.BUILDER && v.heroHall > 0) {
            for (item in gd.items.values) {
                if (item.cat != Cat.HERO || v.has(item.id)) continue
                if (item.prodLevel > v.heroHall) continue
                val lv1 = item.lv(1) ?: continue
                if (lv1.hall > hall || lv1.time <= 0) continue
                out += Candidate(lane, item, null, 0, 1, gold.apply(lv1.time, lane), lv1.cost, true)
            }
        }
        // Pet baru
        if (lane == Lane.PET && v.petHouse > 0) {
            for (item in gd.items.values) {
                if (item.cat != Cat.PET || v.has(item.id)) continue
                if (item.prodLevel > v.petHouse) continue
                val lv1 = item.lv(1) ?: continue
                if (lv1.hall > hall || lv1.time <= 0) continue
                out += Candidate(lane, item, null, 0, 1, gold.apply(lv1.time, lane), lv1.cost, true)
            }
        }
        return out
    }

    /** Gabungkan kandidat identik (mis. 3 Cannon di level yang sama). */
    fun dedupe(list: List<Candidate>): List<Candidate> {
        val map = LinkedHashMap<String, Candidate>()
        for (c in list) {
            val key = "${c.item.id}|${c.fromLevel}|${c.isNew}"
            val prev = map[key]
            map[key] = if (prev == null) c
            else Candidate(c.lane, c.item, prev.inst, c.fromLevel, c.toLevel, c.duration, c.cost, c.isNew,
                if (c.isNew) c.count else prev.count + 1)
        }
        return map.values.toList()
    }

    // ------------------------------------------------------------------ saran

    /** Selesaikan (di salinan desa) semua upgrade yang sudah selesai pada waktu [t]. */
    private fun completeUntil(v: Village, finishes: Map<String, Long>, t: Long) {
        for (i in v.insts) {
            if (!i.upgrading) continue
            val f = finishes[i.uid] ?: (v.exportAt + i.remaining * 1000)
            if (f <= t) { i.level += 1; i.upgrading = false; i.remaining = 0 }
        }
    }

    fun laneCount(v: Village, lane: Lane, ps: PlanSettings): Int = when (lane) {
        Lane.BUILDER -> v.homeBuilders
        Lane.BB_BUILDER -> if (ps.bbBuilders > 0) ps.bbBuilders else v.bbBuildersAuto
        Lane.LAB -> if (v.labLevel > 0) 1 else 0
        Lane.PET -> if (v.petHouse > 0) 1 else 0
        Lane.STAR_LAB -> if (v.starLab > 0) 1 else 0
    }

    private fun rank(
        state: Village, gd: GameData, lane: Lane, start: Long, ps: PlanSettings,
    ): Pair<List<Scored>, List<Candidate>> {
        val skipped = ArrayList<Candidate>()
        val scored = ArrayList<Scored>()
        for (c in dedupe(candidates(state, gd, lane, ps.gold, includeHall = true))) {
            val s = score(c, start, ps)
            if (c.item.cat == Cat.HERO && ps.cwl.overlap(s.start, s.finish) != null) {
                skipped += c
                continue
            }
            scored += s
        }
        scored.sortByDescending { it.score }
        return scored to skipped
    }

    /**
     * Saran per pekerja: yang bebas sekarang, lalu beberapa yang akan bebas berikutnya.
     * [finishes] = waktu selesai terproyeksi (helper & boost) per uid timer.
     */
    fun suggest(
        v: Village, gd: GameData, ps: PlanSettings, now: Long, finishes: Map<String, Long>,
        upcoming: Int = 3,
    ): List<LaneSlot> {
        val slots = ArrayList<LaneSlot>()
        for (lane in Lane.entries) {
            val total = laneCount(v, lane, ps)
            if (total <= 0) continue
            val running = v.insts.filter { it.upgrading && it.item.lane == lane }
                .map { it to (finishes[it.uid] ?: (v.exportAt + it.remaining * 1000)) }
            val unknownBusy = v.timers.count { t -> t.lane == lane && t.cat == null && (v.exportAt + t.remaining * 1000) > now }
            val stillRunning = running.filter { it.second > now }.sortedBy { it.second }
            val freeNow = (total - stillRunning.size - unknownBusy).coerceAtLeast(0)

            if (freeNow > 0) {
                val st = v.copy()
                completeUntil(st, finishes, now)
                val (ranked, skipped) = rank(st, gd, lane, now, ps)
                slots += LaneSlot(lane, now, now, null, freeNow, ranked, skipped)
            }
            for ((inst, fin) in stillRunning.take(upcoming)) {
                val st = v.copy()
                completeUntil(st, finishes, fin)
                val start = ps.schedule.nextOnline(fin)
                val (ranked, skipped) = rank(st, gd, lane, start, ps)
                slots += LaneSlot(lane, fin, start, "${inst.item.name} → Lv ${inst.level + 1}", 1, ranked, skipped)
            }
        }
        return slots
    }

    // ------------------------------------------------------------------ simulasi

    private class SimLane(val lane: Lane, val index: Int, var freeAt: Long, var retired: Boolean = false, var lastFinish: Long? = null)
    private class SimRun(val inst: Inst, var finish: Long, val laneRef: SimLane)

    /**
     * Simulasi maju: pekerja mengambil saran terbaik setiap kali bebas (hanya saat Anda online),
     * sampai semua upgrade pada level hall sekarang selesai. Town Hall / Builder Hall tidak ikut.
     */
    fun simulate(
        v0: Village, gd: GameData, ps: PlanSettings, now: Long, finishes: Map<String, Long>,
        lanesWanted: Set<Lane> = Lane.entries.toSet(),
        maxSteps: Int = 4000,
        keepSteps: Int = 40,
    ): SimResult {
        val v = v0.copy()
        val lanes = ArrayList<SimLane>()
        val runs = ArrayList<SimRun>()
        for (lane in Lane.entries) {
            if (lane !in lanesWanted) continue
            val n = laneCount(v, lane, ps)
            val busy = v.insts.filter { it.upgrading && it.item.lane == lane }
            val count = maxOf(n, busy.size)
            if (count == 0) continue
            val laneObjs = (0 until count).map { SimLane(lane, it + 1, now) }
            lanes += laneObjs
            // B1 = pekerja yang paling cepat bebas
            busy.sortedBy { finishes[it.uid] ?: (v.exportAt + it.remaining * 1000) }.forEachIndexed { idx, inst ->
                val f = maxOf(finishes[inst.uid] ?: (v.exportAt + inst.remaining * 1000), now)
                val l = laneObjs[idx]
                l.freeAt = f
                l.lastFinish = f
                runs += SimRun(inst, f, l)
            }
        }
        // Helper harian
        class HelperSim(val lane: Lane, val level: Int, var next: Long)
        val helpers = ArrayList<HelperSim>()
        for ((id, lane) in listOf(GameData.APPRENTICE to Lane.BUILDER, GameData.LAB_ASSISTANT to Lane.LAB)) {
            if (lane !in lanesWanted) continue
            val h = v.helper(id) ?: continue
            if (h.level <= 0) continue
            var nx = v.exportAt + h.cooldown * 1000
            while (nx < now) nx += HELPER_CYCLE
            helpers += HelperSim(lane, h.level, nx)
        }

        val steps = ArrayList<PlannedStep>()
        val helperEvents = ArrayList<HelperEvent>()
        val horizon = now + 4L * 365 * DAY
        var count = 0
        var truncated = false
        var newSeq = 0
        var builderIdle = 0L
        val idleWindowEnd = now + 7 * DAY

        fun applyCompletions(t: Long) {
            val it = runs.iterator()
            while (it.hasNext()) {
                val r = it.next()
                if (r.finish <= t) {
                    r.inst.level += 1
                    r.inst.upgrading = false
                    r.inst.remaining = 0
                    it.remove()
                }
            }
        }

        while (true) {
            val active = lanes.filter { !it.retired }
            if (active.isEmpty()) break
            if (count++ > maxSteps) { truncated = true; break }

            val nextLane = active.minByOrNull { if (it.freeAt <= now) now else ps.schedule.nextOnline(it.freeAt) }!!
            val tStart = if (nextLane.freeAt <= now) now else ps.schedule.nextOnline(nextLane.freeAt)
            if (tStart > horizon) { truncated = true; break }

            val h = helpers.minByOrNull { it.next }
            if (h != null && h.next < tStart) {
                val target = runs.filter { it.laneRef.lane == h.lane && it.finish > h.next }.maxByOrNull { it.finish }
                if (target != null) {
                    if (helperEvents.size < keepSteps) helperEvents += HelperEvent(h.next, h.lane, h.level, target.inst.item.name)
                    val rem = target.finish - h.next
                    val boost = h.level * HOUR
                    target.finish = if (rem <= boost + HOUR) h.next + rem / (h.level + 1) else target.finish - boost
                    target.laneRef.freeAt = target.finish
                    target.laneRef.lastFinish = target.finish
                }
                h.next += HELPER_CYCLE
                continue
            }

            applyCompletions(tStart)

            var best: Scored? = null
            var bestBlocked: Scored? = null
            var cwlBlocked: Long? = null
            for (c in candidates(v, gd, nextLane.lane, ps.gold, includeHall = false)) {
                val s = score(c, tStart, ps)
                if (c.item.cat == Cat.HERO) {
                    val w = ps.cwl.overlap(s.start, s.finish)
                    if (w != null) {
                        cwlBlocked = minOf(cwlBlocked ?: Long.MAX_VALUE, w.last + 1)
                        if (bestBlocked == null || s.score > bestBlocked.score) bestBlocked = s
                        continue
                    }
                }
                if (best == null || s.score > best.score) best = s
            }

            if (best != null) {
                if (nextLane.lane == Lane.BUILDER && nextLane.freeAt < idleWindowEnd) {
                    builderIdle += (minOf(tStart, idleWindowEnd) - maxOf(nextLane.freeAt, now)).coerceAtLeast(0)
                }
                val c = best.c
                val inst = c.inst ?: Inst("sim|new|${c.item.id}|${newSeq++}", c.item, 0, false, 0, false, false)
                    .also { v.insts += it }
                inst.upgrading = true
                runs += SimRun(inst, best.finish, nextLane)
                nextLane.freeAt = best.finish
                nextLane.lastFinish = best.finish
                if (steps.size < keepSteps) {
                    val note = bestBlocked?.takeIf { it.score > best.score }?.let { "${it.c.item.name} ditunda (CWL)" }
                    steps += PlannedStep(
                        nextLane.lane, nextLane.index, c.title.substringBefore("  ×").substringBefore(" (sisa"),
                        best.start, best.finish, best.idle, note, c.duration,
                    )
                }
            } else {
                val waitFor = (runs.filter { it.finish > tStart }.map { it.finish } + listOfNotNull(cwlBlocked)).minOrNull()
                if (waitFor == null) nextLane.retired = true else nextLane.freeAt = waitFor
            }
        }

        fun doneFor(lane: Lane): Long? {
            val ls = lanes.filter { it.lane == lane }
            if (ls.isEmpty()) return null
            return ls.mapNotNull { it.lastFinish }.maxOrNull() ?: now
        }
        return SimResult(
            doneFor(Lane.BUILDER), doneFor(Lane.LAB), doneFor(Lane.PET),
            doneFor(Lane.BB_BUILDER), doneFor(Lane.STAR_LAB), steps, builderIdle, truncated, helperEvents,
        )
    }
}
