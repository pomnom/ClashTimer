package id.clashtimer

import android.widget.LinearLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import id.clashtimer.core.Cat
import id.clashtimer.core.Fmt
import id.clashtimer.core.Lane
import id.clashtimer.core.LaneSlot
import id.clashtimer.core.Scored
import id.clashtimer.core.Strategy
import java.time.ZoneId

/** Tab "Saran": upgrade apa yang sebaiknya dimulai berikutnya. */
object SuggestView {

    fun render(act: MainActivity, box: LinearLayout, b: PlanBundle) {
        val zone = ZoneId.systemDefault()
        val now = System.currentTimeMillis()
        val ps = b.ps

        // --- ringkasan pengaturan
        val (infoCard, info) = Ui.card(act, tinted = true)
        val s = ps.schedule
        val online = buildList {
            if (s.sleep.enabled) add("😴 tidur ${Fmt.clock(s.sleep.startMin)}–${Fmt.clock(s.sleep.endMin)}")
            if (s.work.enabled) add("💼 kerja ${Fmt.clock(s.work.startMin)}–${Fmt.clock(s.work.endMin)}")
        }.ifEmpty { listOf("Jam istirahat belum diatur") }.joinToString(" · ")
        info.addView(Ui.text(act, online, Ui.BODY_M))
        val gp = if (ps.gold.builderPct + ps.gold.researchPct > 0)
            "Gold Pass: builder ${ps.gold.builderPct}% · riset ${ps.gold.researchPct}%" else "Tanpa Gold Pass"
        info.addView(Ui.muted(act, "Strategi: ${ps.strategy.label} · $gp"))
        if (ps.cwl.enabled) {
            val w = ps.cwl.next(now)
            val running = now >= w.first
            val txt = if (running) "⚔️ CWL berlangsung sampai ${Fmt.at(w.last + 1, zone)} — upgrade hero yang bentrok disembunyikan"
            else "⚔️ CWL berikutnya ${Fmt.at(w.first, zone)} – ${Fmt.dateShort(w.last + 1, zone)} — hero yang bentrok disembunyikan"
            info.addView(Ui.muted(act, txt))
            // Hero yang masih upgrade ketika CWL berjalan
            val fin = Store.upgrades(act).filter { it.tag == b.tag }.associate { it.id to it.finishAt }
            for (i in b.village.insts) {
                if (!i.upgrading || i.item.cat != Cat.HERO) continue
                val f = fin[i.uid] ?: continue
                if (f > now && ps.cwl.overlap(now, f) != null) {
                    info.addView(Ui.text(act,
                        "⚠️ ${i.item.name} masih upgrade saat CWL (selesai ${Fmt.at(f, zone)}) — pertimbangkan Book of Heroes / potion",
                        Ui.BODY_S,
                    ).apply { setTextColor(Ui.AMBER) })
                }
            }
        }
        val row = Ui.hbox(act)
        row.addView(Ui.flat(act, "Ubah strategi") { chooseStrategy(act) })
        row.addView(Ui.flat(act, "Pengaturan") { act.openSettings() })
        info.addView(row)
        box.addView(infoCard)

        // --- per pekerja
        val order = listOf(Lane.BUILDER, Lane.LAB, Lane.PET, Lane.BB_BUILDER, Lane.STAR_LAB)
        for (lane in order) {
            val slots = b.slots.filter { it.lane == lane }
            if (slots.isEmpty()) continue
            val title = when (lane) {
                Lane.BUILDER -> "🔨 Builder"
                Lane.LAB -> "🧪 Laboratory"
                Lane.PET -> "🐾 Pet House"
                Lane.BB_BUILDER -> "🛠️ Builder Base"
                Lane.STAR_LAB -> "⭐ Star Laboratory"
            }
            box.addView(Ui.section(act, title))
            for (slot in slots) renderSlot(act, box, slot, now, zone)
        }

        // --- item
        run {
            box.addView(Ui.section(act, "⚡ Item", "Potion, book & hammer terbaik saat ini"))
            for (t in b.tips) {
                val (card, col) = Ui.card(act)
                val owned = if (t.owned > 0) "  (punya ${t.owned})" else ""
                col.addView(Ui.text(act, "${t.item.emoji} ${t.item.label}$owned", Ui.TITLE_S))
                col.addView(Ui.text(act, t.headline, Ui.BODY_M))
                col.addView(Ui.muted(act, t.detail))
                box.addView(card)
            }
            if (b.tips.none { it.item.isBook || it.item.isHammer }) {
                box.addView(Ui.muted(act, "Masukkan jumlah book & hammer yang Anda punya supaya saran targetnya muncul.").apply {
                    setPadding(Ui.dp(act, 4), 0, Ui.dp(act, 4), Ui.dp(act, 4))
                })
            }
            val r = Ui.hbox(act)
            r.addView(Ui.outlined(act, "Atur jumlah item") { ItemsUi.editCounts(act, b.tag) }, Ui.weight1())
            r.addView(Ui.outlined(act, "Pakai item") { act.openItems(b.tag) }, Ui.weight1().apply { marginStart = Ui.dp(act, 8) })
            box.addView(r)
        }

        // --- rencana ke depan
        val steps = b.simHome.steps.filter { it.lane == Lane.BUILDER }.take(8)
        if (steps.isNotEmpty()) {
            box.addView(Ui.section(act, "🗓️ Rencana builder (perkiraan)", "Urutan jika setiap builder langsung diisi saran teratas saat Anda online"))
            val (card, col) = Ui.card(act)
            for (st in steps) {
                val idle = if (st.idle > 30 * 60_000L) "  💤 ${Fmt.dur(st.idle)}" else ""
                col.addView(Ui.text(act, "${Fmt.at(st.start, zone)}  ${st.title}", Ui.BODY_M))
                col.addView(Ui.muted(act, "   selesai ${Fmt.at(st.finish, zone)}$idle").apply { setPadding(0, 0, 0, Ui.dp(act, 4)) })
            }
            box.addView(card)
        }
        box.addView(Ui.muted(act, "Saran dihitung ${Fmt.time(b.computedAt, zone)}. Import ulang setelah memulai upgrade agar saran mengikuti kondisi terbaru.").apply {
            setPadding(Ui.dp(act, 4), Ui.dp(act, 16), Ui.dp(act, 4), 0)
        })
    }

    private fun renderSlot(act: MainActivity, box: LinearLayout, slot: LaneSlot, now: Long, zone: ZoneId) {
        val who = slot.lane.label.lowercase()
        val head = when {
            slot.freeAt <= now && slot.count > 1 -> "${slot.count} $who bebas sekarang"
            slot.freeAt <= now -> "${slot.lane.label} bebas sekarang"
            else -> "Bebas ${Fmt.at(slot.freeAt, zone)}" + (slot.freedBy?.let { " · setelah $it" } ?: "")
        }
        val startNote = if (slot.start - slot.freeAt > 10 * 60_000L && slot.freeAt > now)
            "Anda sedang offline saat itu → mulai ${Fmt.at(slot.start, zone)}" else null
        box.addView(Ui.text(act, head, Ui.TITLE_S).apply { setPadding(Ui.dp(act, 4), Ui.dp(act, 8), 0, 0) })
        if (startNote != null) box.addView(Ui.muted(act, startNote).apply { setPadding(Ui.dp(act, 4), 0, 0, Ui.dp(act, 2)) })

        val picks = slot.ranked.take(if (slot.freeAt <= now) 5 else 3)
        if (picks.isEmpty()) {
            box.addView(Ui.muted(act, "Tidak ada upgrade yang tersedia (semua sudah max atau menunggu syarat).", Ui.BODY_M).apply {
                setPadding(Ui.dp(act, 4), Ui.dp(act, 2), 0, Ui.dp(act, 6))
            })
        }
        for ((i, p) in picks.withIndex()) box.addView(pickCard(act, p, i == 0, zone))

        if (slot.cwlSkipped.isNotEmpty()) {
            box.addView(Ui.muted(act, "⚔️ Disembunyikan karena bentrok CWL: " +
                slot.cwlSkipped.joinToString(", ") { it.title }).apply {
                setPadding(Ui.dp(act, 4), 0, Ui.dp(act, 4), Ui.dp(act, 4))
            })
        }
        if (slot.ranked.size > picks.size) {
            box.addView(Ui.flat(act, "Lihat semua (${slot.ranked.size})") { showAll(act, slot, zone) })
        }
    }

    private fun timing(p: Scored, zone: ZoneId): String = when {
        p.idle <= 0 -> "selesai ${Fmt.at(p.finish, zone)} ✓"
        else -> "selesai ${Fmt.at(p.finish, zone)} 💤 nganggur ${Fmt.dur(p.idle)}"
    }

    private fun tag(p: Scored): String {
        val c = p.c
        val parts = ArrayList<String>()
        if (c.isNew) parts += "baru"
        when (c.item.cat) {
            Cat.HERO, Cat.BB_HERO -> parts += "hero"
            Cat.BUILDING, Cat.BB_BUILDING -> if (c.item.type == "Army") parts += "army" else if (c.item.type == "Defense") parts += "pertahanan"
            else -> {}
        }
        val cost = if (c.cost > 0) "${Fmt.money(c.cost)} ${Fmt.resource(c.item.resource)}" else "gratis"
        return (listOf(cost) + parts).joinToString(" · ")
    }

    private fun pickCard(act: MainActivity, p: Scored, best: Boolean, zone: ZoneId): android.view.View {
        val (card, col) = Ui.card(act)
        val star = if (best) "★ " else ""
        col.addView(Ui.text(act, star + p.c.title, Ui.TITLE_S))
        col.addView(Ui.text(act, "⏱ ${Fmt.durSec(p.c.duration)} · ${timing(p, zone)}", Ui.BODY_M).apply {
            if (p.idle > 0) setTextColor(Ui.AMBER)
        })
        col.addView(Ui.muted(act, tag(p)))
        return card
    }

    private fun showAll(act: MainActivity, slot: LaneSlot, zone: ZoneId) {
        val lines = slot.ranked.take(60).map { p ->
            "${p.c.title}\n   ${Fmt.durSec(p.c.duration)} · ${timing(p, zone)}" as CharSequence
        }.toTypedArray()
        MaterialAlertDialogBuilder(act)
            .setTitle("Semua opsi (urut saran)")
            .setItems(lines, null)
            .setPositiveButton("Tutup", null)
            .show()
    }

    private fun chooseStrategy(act: MainActivity) {
        val all = Strategy.entries
        val cur = Store.planSettings(act).strategy
        val labels = all.map { "${it.label}\n${it.desc}" as CharSequence }.toTypedArray()
        MaterialAlertDialogBuilder(act)
            .setTitle("Strategi saran")
            .setSingleChoiceItems(labels, all.indexOf(cur)) { d, w ->
                Store.putPlan(act, "strategy", all[w].name)
                d.dismiss()
                act.renderPlan()
            }
            .show()
    }
}
