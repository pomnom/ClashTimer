package id.clashtimer

import android.content.Context
import id.clashtimer.core.BBStrategy
import id.clashtimer.core.Boost
import id.clashtimer.core.BoostKind
import id.clashtimer.core.CwlRule
import id.clashtimer.core.DailyWindow
import id.clashtimer.core.GameEvent
import id.clashtimer.core.GoldPass
import id.clashtimer.core.Lane
import id.clashtimer.core.MagicItem
import id.clashtimer.core.OfflineSchedule
import id.clashtimer.core.PlanSettings
import id.clashtimer.core.Started
import id.clashtimer.core.Strategy
import org.json.JSONArray
import org.json.JSONObject
import java.time.DayOfWeek
import java.time.ZoneId

/** Jenis antrean untuk timer & notifikasi. */
enum class Kind(val label: String, val emoji: String, val builderBase: Boolean) {
    BUILDER("Builder", "🔨", false),
    LAB("Laboratory", "🧪", false),
    PET("Pet House", "🐾", false),
    HELPER("Helper", "🧑‍🔧", false),
    BB_BUILDER("Builder Base", "🛠️", true),
    STAR_LAB("Star Lab", "⭐", true);

    companion object {
        fun of(lane: Lane): Kind = when (lane) {
            Lane.BUILDER -> BUILDER
            Lane.LAB -> LAB
            Lane.PET -> PET
            Lane.BB_BUILDER -> BB_BUILDER
            Lane.STAR_LAB -> STAR_LAB
        }
    }
}

data class Upgrade(
    val id: String,
    val tag: String,
    val kind: Kind,
    val name: String,
    /** Level tujuan (level sekarang + 1). 0 untuk helper. */
    val targetLevel: Int,
    val finishAt: Long,
    /** Upgrade ini dibantu helper berulang. */
    val helped: Boolean,
    var earlyNotified: Boolean = false,
    var doneNotified: Boolean = false,
    /** Waktu selesai menurut export saja (tanpa helper & potion). */
    val baseFinishAt: Long = finishAt,
    /** Keterangan tambahan (helper, potion, dll). */
    val note: String = "",
    val customTitle: String = "",
) {
    fun title(): String = when {
        customTitle.isNotBlank() -> customTitle
        kind == Kind.HELPER -> "$name siap dipakai"
        targetLevel > 0 -> "$name → Lv $targetLevel"
        else -> name
    }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("tag", tag).put("kind", kind.name).put("name", name)
        .put("lvl", targetLevel).put("finishAt", finishAt).put("helped", helped)
        .put("early", earlyNotified).put("done", doneNotified)
        .put("base", baseFinishAt).put("note", note).put("title", customTitle)

    companion object {
        fun fromJson(o: JSONObject): Upgrade {
            val finish = o.getLong("finishAt")
            return Upgrade(
                id = o.getString("id"),
                tag = o.getString("tag"),
                kind = runCatching { Kind.valueOf(o.getString("kind")) }.getOrDefault(Kind.BUILDER),
                name = o.getString("name"),
                targetLevel = o.optInt("lvl"),
                finishAt = finish,
                helped = o.optBoolean("helped"),
                earlyNotified = o.optBoolean("early"),
                doneNotified = o.optBoolean("done"),
                baseFinishAt = o.optLong("base", finish),
                note = o.optString("note", ""),
                customTitle = o.optString("title", ""),
            )
        }
    }
}

data class Account(
    val tag: String,
    val builders: Int,
    val exportedAt: Long,
    val th: Int = 0,
    val bh: Int = 0,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("tag", tag).put("builders", builders).put("exportedAt", exportedAt)
        .put("th", th).put("bh", bh)

    companion object {
        fun fromJson(o: JSONObject) = Account(
            o.getString("tag"), o.optInt("builders", 5), o.optLong("exportedAt"),
            o.optInt("th"), o.optInt("bh"),
        )
    }
}

/** Penyimpanan sederhana di SharedPreferences (data hanya ada di HP ini). */
object Store {
    private const val PREFS = "clash_timer"
    private val lock = Any()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- timer

    fun upgrades(ctx: Context): MutableList<Upgrade> = synchronized(lock) {
        val raw = prefs(ctx).getString("upgrades", "[]") ?: "[]"
        val arr = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        val list = mutableListOf<Upgrade>()
        for (i in 0 until arr.length()) {
            runCatching { list += Upgrade.fromJson(arr.getJSONObject(i)) }
        }
        list
    }

    fun saveUpgrades(ctx: Context, list: List<Upgrade>) = synchronized(lock) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString("upgrades", arr.toString()).commit()
    }

    fun accounts(ctx: Context): MutableList<Account> = synchronized(lock) {
        val raw = prefs(ctx).getString("accounts", "[]") ?: "[]"
        val arr = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        val list = mutableListOf<Account>()
        for (i in 0 until arr.length()) {
            runCatching { list += Account.fromJson(arr.getJSONObject(i)) }
        }
        list
    }

    fun saveAccounts(ctx: Context, list: List<Account>) = synchronized(lock) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString("accounts", arr.toString()).commit()
    }

    /** Ganti semua timer milik akun ini dengan hasil import terbaru. */
    fun replaceAccount(ctx: Context, account: Account, fresh: List<Upgrade>, earlyMinutes: Int) = synchronized(lock) {
        val now = System.currentTimeMillis()
        val earlyMs = earlyMinutes * 60_000L
        fresh.forEach {
            // Jangan kirim notifikasi untuk hal yang sudah lewat saat di-import.
            if (it.finishAt <= now) { it.doneNotified = true; it.earlyNotified = true }
            else if (earlyMs > 0 && it.finishAt - earlyMs <= now) it.earlyNotified = true
        }
        val others = upgrades(ctx).filter { it.tag != account.tag }
        saveUpgrades(ctx, others + fresh)
        saveAccounts(ctx, accounts(ctx).filter { it.tag != account.tag } + account)
    }

    /**
     * Perbarui waktu selesai (setelah potion / book / tandai selesai) dengan tetap
     * menghormati notifikasi yang sudah terkirim.
     */
    fun mergeProjections(ctx: Context, tag: String, fresh: List<Upgrade>, doneIds: Set<String>) = synchronized(lock) {
        val all = upgrades(ctx)
        val old = all.filter { it.tag == tag }.associateBy { it.id }
        val merged = fresh.map { u ->
            val o = old[u.id]
            when {
                u.id in doneIds -> u.also { it.doneNotified = true; it.earlyNotified = true }
                o != null && o.finishAt == u.finishAt -> u.also { it.doneNotified = o.doneNotified; it.earlyNotified = o.earlyNotified }
                o != null -> u.also { it.doneNotified = false; it.earlyNotified = o.earlyNotified && u.finishAt >= o.finishAt }
                else -> u
            }
        }
        saveUpgrades(ctx, all.filter { it.tag != tag } + merged)
    }

    fun removeAccount(ctx: Context, tag: String) = synchronized(lock) {
        saveUpgrades(ctx, upgrades(ctx).filter { it.tag != tag })
        saveAccounts(ctx, accounts(ctx).filter { it.tag != tag })
        prefs(ctx).edit()
            .remove("export_$tag").remove("boosts_$tag").remove("done_$tag")
            .remove("cancel_$tag").remove("bumps_$tag").remove("items_$tag")
            .remove("name_$tag").remove("started_$tag").remove("pct_$tag")
            .commit()
        if (selectedTag(ctx) == tag) prefs(ctx).edit().remove("selected_tag").apply()
    }

    /** Buang upgrade yang sudah selesai lebih dari 24 jam lalu. */
    fun pruneOld(ctx: Context) = synchronized(lock) {
        val cutoff = System.currentTimeMillis() - 24 * 3600_000L
        val list = upgrades(ctx)
        val kept = list.filter { it.finishAt > cutoff }
        if (kept.size != list.size) saveUpgrades(ctx, kept)
    }

    // ---------------------------------------------------------------- data per akun

    /** Nama desa pilihan pengguna (default: tag). */
    fun villageName(ctx: Context, tag: String): String =
        prefs(ctx).getString("name_$tag", null)?.takeIf { it.isNotBlank() } ?: tag

    fun setVillageName(ctx: Context, tag: String, name: String) {
        prefs(ctx).edit().putString("name_$tag", name.trim()).apply()
    }

    /** Persentase menuju max terakhir yang dihitung (untuk daftar desa). */
    fun lastPct(ctx: Context, tag: String): Float = prefs(ctx).getFloat("pct_$tag", -1f)
    fun setLastPct(ctx: Context, tag: String, pct: Float) = prefs(ctx).edit().putFloat("pct_$tag", pct).apply()

    /** Upgrade yang ditandai "sudah dimulai" di aplikasi sejak export terakhir. */
    fun started(ctx: Context, tag: String): List<Started> {
        val arr = runCatching { JSONArray(prefs(ctx).getString("started_$tag", "[]")) }.getOrDefault(JSONArray())
        val out = ArrayList<Started>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val lane = runCatching { Lane.valueOf(o.getString("l")) }.getOrNull() ?: continue
            out += Started(o.getString("u"), o.getInt("i"), o.getInt("f"), lane, o.optString("n"), o.getLong("s"), o.getLong("d"),
                o.optBoolean("g"))
        }
        return out
    }

    fun setStarted(ctx: Context, tag: String, list: List<Started>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("u", it.uid).put("i", it.itemId).put("f", it.fromLevel).put("l", it.lane.name)
                .put("n", it.name).put("s", it.start).put("d", it.durationSec).put("g", it.gear))
        }
        prefs(ctx).edit().putString("started_$tag", arr.toString()).commit()
    }

    fun exportText(ctx: Context, tag: String): String? = prefs(ctx).getString("export_$tag", null)
    fun saveExport(ctx: Context, tag: String, text: String) {
        prefs(ctx).edit().putString("export_$tag", text).commit()
    }

    fun boosts(ctx: Context, tag: String): List<Boost> {
        val arr = runCatching { JSONArray(prefs(ctx).getString("boosts_$tag", "[]")) }.getOrDefault(JSONArray())
        val out = ArrayList<Boost>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val k = runCatching { BoostKind.valueOf(o.getString("k")) }.getOrNull() ?: continue
            out += Boost(k, o.getLong("s"), o.getLong("e"))
        }
        return out
    }

    fun setBoosts(ctx: Context, tag: String, list: List<Boost>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("k", it.kind.name).put("s", it.start).put("e", it.end)) }
        prefs(ctx).edit().putString("boosts_$tag", arr.toString()).commit()
    }

    /** uid timer → kapan ditandai selesai (book, gem, dsb). */
    fun done(ctx: Context, tag: String): Map<String, Long> = readLongMap(ctx, "done_$tag")
    fun setDone(ctx: Context, tag: String, m: Map<String, Long>) = writeLongMap(ctx, "done_$tag", m)

    /** uid timer → kapan dibatalkan. */
    fun cancelled(ctx: Context, tag: String): Map<String, Long> = readLongMap(ctx, "cancel_$tag")
    fun setCancelled(ctx: Context, tag: String, m: Map<String, Long>) = writeLongMap(ctx, "cancel_$tag", m)

    /** Level yang naik karena hammer: (id item, level awal, waktu). */
    fun bumps(ctx: Context, tag: String): List<Triple<Int, Int, Long>> {
        val arr = runCatching { JSONArray(prefs(ctx).getString("bumps_$tag", "[]")) }.getOrDefault(JSONArray())
        val out = ArrayList<Triple<Int, Int, Long>>()
        for (i in 0 until arr.length()) {
            val a = arr.optJSONArray(i) ?: continue
            out += Triple(a.optInt(0), a.optInt(1), a.optLong(2))
        }
        return out
    }

    fun setBumps(ctx: Context, tag: String, list: List<Triple<Int, Int, Long>>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONArray().put(it.first).put(it.second).put(it.third)) }
        prefs(ctx).edit().putString("bumps_$tag", arr.toString()).commit()
    }

    fun items(ctx: Context, tag: String): Map<MagicItem, Int> {
        val o = runCatching { JSONObject(prefs(ctx).getString("items_$tag", "{}") ?: "{}") }.getOrDefault(JSONObject())
        val m = HashMap<MagicItem, Int>()
        for (mi in MagicItem.entries) {
            val n = o.optInt(mi.name, 0)
            if (n > 0) m[mi] = n
        }
        return m
    }

    fun setItem(ctx: Context, tag: String, item: MagicItem, count: Int) {
        val o = runCatching { JSONObject(prefs(ctx).getString("items_$tag", "{}") ?: "{}") }.getOrDefault(JSONObject())
        o.put(item.name, count.coerceIn(0, 999))
        prefs(ctx).edit().putString("items_$tag", o.toString()).commit()
    }

    private fun readLongMap(ctx: Context, key: String): Map<String, Long> {
        val o = runCatching { JSONObject(prefs(ctx).getString(key, "{}") ?: "{}") }.getOrDefault(JSONObject())
        val m = HashMap<String, Long>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            m[k] = o.optLong(k)
        }
        return m
    }

    private fun writeLongMap(ctx: Context, key: String, m: Map<String, Long>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, v) }
        prefs(ctx).edit().putString(key, o.toString()).commit()
    }

    // ---------------------------------------------------------------- pengaturan notifikasi

    fun earlyMinutes(ctx: Context) = prefs(ctx).getInt("early_min", 0)
    fun setEarlyMinutes(ctx: Context, v: Int) = prefs(ctx).edit().putInt("early_min", v).apply()

    /** true = setAlarmClock (paling tepat waktu, ada ikon jam di status bar). */
    fun strongAlarm(ctx: Context) = prefs(ctx).getBoolean("strong_alarm", true)
    fun setStrongAlarm(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("strong_alarm", v).apply()

    fun notifyHelpers(ctx: Context) = prefs(ctx).getBoolean("notify_helpers", true)
    fun setNotifyHelpers(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("notify_helpers", v).apply()

    // ---------------------------------------------------------------- tampilan

    /** Ikon bangunan dari internet (assets.clashk.ing). */
    fun iconsOn(ctx: Context) = prefs(ctx).getBoolean("icons_on", true)
    fun setIconsOn(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("icons_on", v).apply()

    // ---------------------------------------------------------------- event

    /** Daftar event (Hammer Jam, dll). Default: Hammer Jam perkiraan, belum aktif. */
    fun events(ctx: Context): List<GameEvent> {
        val raw = prefs(ctx).getString("events", null) ?: return listOf(GameEvent.hammerJam(System.currentTimeMillis()))
        val arr = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        val out = ArrayList<GameEvent>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            runCatching {
                out += GameEvent(
                    o.getString("id"), o.optString("n", "Event"), o.getLong("s"), o.getLong("e"),
                    o.optInt("tp", 50), o.optInt("cp", 50), o.optBoolean("b", true), o.optBoolean("l", true),
                    o.optBoolean("bb", false), o.optBoolean("cut", false), o.optBoolean("on", true),
                )
            }
        }
        return out
    }

    fun setEvents(ctx: Context, list: List<GameEvent>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("n", it.name).put("s", it.start).put("e", it.end)
                .put("tp", it.timePct).put("cp", it.costPct).put("b", it.builder).put("l", it.lab).put("bb", it.bb)
                .put("cut", it.cutRunning).put("on", it.enabled))
        }
        prefs(ctx).edit().putString("events", arr.toString())
            .putInt("plan_version", prefs(ctx).getInt("plan_version", 0) + 1).commit()
    }

    // ---------------------------------------------------------------- nada notifikasi

    /** key: "done" (upgrade selesai & helper) atau "early" (pengingat sebelum selesai). */
    fun toneMode(ctx: Context, key: String): ToneMode =
        runCatching { ToneMode.valueOf(prefs(ctx).getString("tone_$key", "DEFAULT") ?: "DEFAULT") }.getOrDefault(ToneMode.DEFAULT)

    fun toneUri(ctx: Context, key: String): String? = prefs(ctx).getString("toneuri_$key", null)

    fun setTone(ctx: Context, key: String, mode: ToneMode, uri: String?) {
        prefs(ctx).edit()
            .putString("tone_$key", mode.name)
            .putString("toneuri_$key", uri)
            .putInt("chver_$key", channelVersion(ctx, key) + 1)
            .commit()
    }

    /** Versi channel notifikasi; dinaikkan setiap nada diganti (channel Android tidak bisa diubah). */
    fun channelVersion(ctx: Context, key: String): Int = prefs(ctx).getInt("chver_$key", 1)

    // ---------------------------------------------------------------- pengaturan perencana

    fun getInt(ctx: Context, key: String, def: Int) = prefs(ctx).getInt(key, def)
    fun getBool(ctx: Context, key: String, def: Boolean) = prefs(ctx).getBoolean(key, def)
    fun getStr(ctx: Context, key: String, def: String) = prefs(ctx).getString(key, def) ?: def

    /** Simpan pengaturan perencana dan naikkan nomor versinya (supaya saran dihitung ulang). */
    fun putPlan(ctx: Context, key: String, value: Any) {
        val e = prefs(ctx).edit()
        when (value) {
            is Int -> e.putInt(key, value)
            is Boolean -> e.putBoolean(key, value)
            is String -> e.putString(key, value)
        }
        e.putInt("plan_version", prefs(ctx).getInt("plan_version", 0) + 1).apply()
    }

    fun planVersion(ctx: Context) = prefs(ctx).getInt("plan_version", 0)

    fun selectedTag(ctx: Context): String? = prefs(ctx).getString("selected_tag", null)
    fun setSelectedTag(ctx: Context, tag: String) = prefs(ctx).edit().putString("selected_tag", tag).apply()

    /** Bit 0 = Senin … bit 6 = Minggu. */
    fun daysFromMask(mask: Int): Set<DayOfWeek> = DayOfWeek.entries.filter { mask and (1 shl (it.value - 1)) != 0 }.toSet()

    const val DEFAULT_WORK_DAYS = 0b0011111

    fun planSettings(ctx: Context): PlanSettings {
        val p = prefs(ctx)
        val sleep = DailyWindow(p.getBoolean("sleep_on", true), p.getInt("sleep_start", 23 * 60), p.getInt("sleep_end", 6 * 60))
        val work = DailyWindow(
            p.getBoolean("work_on", false), p.getInt("work_start", 8 * 60), p.getInt("work_end", 16 * 60),
            daysFromMask(p.getInt("work_days", DEFAULT_WORK_DAYS)),
        )
        val cwl = CwlRule(p.getBoolean("cwl_on", true), 1, 8, p.getInt("cwl_days", 11))
        val gold = GoldPass(p.getInt("gp_builder", 0), p.getInt("gp_research", 0))
        val strategy = runCatching { Strategy.valueOf(p.getString("strategy", "MAX") ?: "MAX") }.getOrDefault(Strategy.MAX)
        val bbStrategy = runCatching { BBStrategy.valueOf(p.getString("bb_strategy", "SIXTH") ?: "SIXTH") }.getOrDefault(BBStrategy.SIXTH)
        return PlanSettings(
            OfflineSchedule(sleep, work, ZoneId.systemDefault()), cwl, gold, strategy, p.getInt("bb_builders", 0),
            bbStrategy, p.getBoolean("skip_collectors", false), events(ctx),
        )
    }
}
