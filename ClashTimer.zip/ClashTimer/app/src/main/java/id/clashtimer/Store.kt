package id.clashtimer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Jenis antrean upgrade. Satu jenis = satu "slot" pekerja di game. */
enum class Kind(val label: String, val emoji: String, val builderBase: Boolean) {
    BUILDER("Builder", "🔨", false),
    LAB("Laboratory", "🧪", false),
    PET("Pet House", "🐾", false),
    HELPER("Helper", "🧑‍🔧", false),
    BB_BUILDER("Builder Base", "🛠️", true),
    STAR_LAB("Star Lab", "⭐", true),
}

data class Upgrade(
    val id: String,
    val tag: String,
    val kind: Kind,
    val name: String,
    /** Level tujuan (level sekarang + 1). 0 untuk helper. */
    val targetLevel: Int,
    val finishAt: Long,
    /** Upgrade ini sedang dibantu helper, jadi bisa selesai lebih cepat. */
    val helped: Boolean,
    var earlyNotified: Boolean = false,
    var doneNotified: Boolean = false,
) {
    fun title(): String = when {
        kind == Kind.HELPER -> "$name siap dipakai"
        targetLevel > 0 -> "$name → Lv $targetLevel"
        else -> name
    }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("tag", tag).put("kind", kind.name).put("name", name)
        .put("lvl", targetLevel).put("finishAt", finishAt).put("helped", helped)
        .put("early", earlyNotified).put("done", doneNotified)

    companion object {
        fun fromJson(o: JSONObject) = Upgrade(
            id = o.getString("id"),
            tag = o.getString("tag"),
            kind = runCatching { Kind.valueOf(o.getString("kind")) }.getOrDefault(Kind.BUILDER),
            name = o.getString("name"),
            targetLevel = o.optInt("lvl"),
            finishAt = o.getLong("finishAt"),
            helped = o.optBoolean("helped"),
            earlyNotified = o.optBoolean("early"),
            doneNotified = o.optBoolean("done"),
        )
    }
}

data class Account(
    val tag: String,
    val builders: Int,
    val exportedAt: Long,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("tag", tag).put("builders", builders).put("exportedAt", exportedAt)

    companion object {
        fun fromJson(o: JSONObject) = Account(
            o.getString("tag"), o.optInt("builders", 5), o.optLong("exportedAt"),
        )
    }
}

/** Penyimpanan sederhana di SharedPreferences (data hanya ada di HP ini). */
object Store {
    private const val PREFS = "clash_timer"
    private val lock = Any()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun upgrades(ctx: Context): MutableList<Upgrade> = synchronized(lock) {
        val raw = prefs(ctx).getString("upgrades", "[]") ?: "[]"
        val arr = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        val list = mutableListOf<Upgrade>()
        for (i in 0 until arr.length()) {
            runCatching { list += Upgrade.fromJson(arr.getJSONObject(i)) }
        }
        list
    }

    fun saveUpgrades(ctx: Context, list: List<Upgrade>) = synchronized(lock) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString("upgrades", arr.toString()).commit()
    }

    fun accounts(ctx: Context): MutableList<Account> = synchronized(lock) {
        val raw = prefs(ctx).getString("accounts", "[]") ?: "[]"
        val arr = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        val list = mutableListOf<Account>()
        for (i in 0 until arr.length()) {
            runCatching { list += Account.fromJson(arr.getJSONObject(i)) }
        }
        list
    }

    fun saveAccounts(ctx: Context, list: List<Account>) = synchronized(lock) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString("accounts", arr.toString()).commit()
    }

    /** Ganti semua timer milik akun ini dengan hasil import terbaru. */
    fun replaceAccount(ctx: Context, result: ImportResult, earlyMinutes: Int) = synchronized(lock) {
        val now = System.currentTimeMillis()
        val earlyMs = earlyMinutes * 60_000L
        result.upgrades.forEach {
            // Jangan kirim notifikasi untuk hal yang sudah lewat saat di-import.
            if (it.finishAt <= now) { it.doneNotified = true; it.earlyNotified = true }
            else if (earlyMs > 0 && it.finishAt - earlyMs <= now) it.earlyNotified = true
        }
        val others = upgrades(ctx).filter { it.tag != result.account.tag }
        saveUpgrades(ctx, others + result.upgrades)
        val accs = accounts(ctx).filter { it.tag != result.account.tag } + result.account
        saveAccounts(ctx, accs)
    }

    fun removeAccount(ctx: Context, tag: String) = synchronized(lock) {
        saveUpgrades(ctx, upgrades(ctx).filter { it.tag != tag })
        saveAccounts(ctx, accounts(ctx).filter { it.tag != tag })
    }

    fun removeUpgrade(ctx: Context, id: String) = synchronized(lock) {
        saveUpgrades(ctx, upgrades(ctx).filter { it.id != id })
    }

    /** Buang upgrade yang sudah selesai lebih dari 24 jam lalu. */
    fun pruneOld(ctx: Context) = synchronized(lock) {
        val cutoff = System.currentTimeMillis() - 24 * 3600_000L
        val list = upgrades(ctx)
        val kept = list.filter { it.finishAt > cutoff }
        if (kept.size != list.size) saveUpgrades(ctx, kept)
    }

    // ---- Pengaturan ----
    fun earlyMinutes(ctx: Context) = prefs(ctx).getInt("early_min", 0)
    fun setEarlyMinutes(ctx: Context, v: Int) = prefs(ctx).edit().putInt("early_min", v).apply()

    /** true = setAlarmClock (paling tepat waktu, ada ikon jam di status bar). */
    fun strongAlarm(ctx: Context) = prefs(ctx).getBoolean("strong_alarm", true)
    fun setStrongAlarm(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("strong_alarm", v).apply()

    fun notifyHelpers(ctx: Context) = prefs(ctx).getBoolean("notify_helpers", true)
    fun setNotifyHelpers(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("notify_helpers", v).apply()
}
