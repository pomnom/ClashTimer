package id.clashtimer

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import id.clashtimer.core.ExportException
import id.clashtimer.core.Fmt
import id.clashtimer.core.Scored
import java.time.ZoneId
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    enum class Tab(val icon: String, val label: String) {
        HOME("🏠", "Beranda"),
        PLAN("📅", "Rencana"),
        PROGRESS("📊", "Progres"),
    }

    private var tab = Tab.HOME
    /** false = Home Village, true = Builder Base. */
    var showBB = false
        private set

    private lateinit var header: LinearLayout
    private lateinit var seg: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var body: LinearLayout
    private lateinit var nav: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private class Countdown(val view: TextView, val target: Long, val clock: Boolean)
    private val countdowns = ArrayList<Countdown>()
    private val zone: ZoneId get() = ZoneId.systemDefault()

    private val exec = Executors.newSingleThreadExecutor()
    private val planCache = HashMap<String, PlanBundle>()
    private var computing: String? = null
    private var planError: String? = null
    private var failedTag: String? = null
    private var failedVersion = -1

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        renderBody()
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (countdowns.any { it.target <= now }) renderBody()
            else for (c in countdowns) c.view.text = if (c.clock) clock(c.target - now) else countdown(c.target - now)
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000))
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.createChannels(this)
        savedInstanceState?.let { st ->
            st.getString("tab")?.let { t -> runCatching { tab = Tab.valueOf(t) } }
            showBB = st.getBoolean("bb", false)
        }

        val root = Ui.vbox(this)
        header = Ui.hbox(this).apply { setPadding(dp(12), dp(10), dp(8), dp(4)) }
        root.addView(header, Ui.matchWrap())
        seg = Ui.hbox(this).apply { setPadding(dp(12), dp(2), dp(12), dp(4)) }
        root.addView(seg, Ui.matchWrap())

        val content = FrameLayout(this)
        body = Ui.vbox(this).apply { setPadding(dp(12), dp(4), dp(12), dp(24)) }
        scroll = ScrollView(this).apply { isFillViewport = true; addView(body) }
        content.addView(scroll)
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(Ui.divider(this))
        nav = Ui.hbox(this).apply { setPadding(0, dp(4), 0, dp(4)) }
        root.addView(nav, Ui.matchWrap())
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        handleShare(intent)
        // Dibuka dari widget: langsung ke Rencana desa itu (bukan saat layar dibuat ulang).
        if (savedInstanceState == null) handleWidget(intent)
    }

    /** Ketukan widget membawa tag desa + sisi (Home/BB) → buka tab Rencana. */
    private fun handleWidget(intent: Intent?): Boolean {
        val tag = intent?.getStringExtra(Widgets.EXTRA_TAG) ?: return false
        if (Store.accounts(this).none { it.tag == tag }) return false
        Store.setSelectedTag(this, tag)
        showBB = intent.getBooleanExtra(Widgets.EXTRA_BB, false)
        tab = Tab.PLAN
        intent.removeExtra(Widgets.EXTRA_TAG)
        return true
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tab", tab.name)
        outState.putBoolean("bb", showBB)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
        if (handleWidget(intent)) {
            renderAll()
            scroll.scrollTo(0, 0)
        }
    }

    override fun onResume() {
        super.onResume()
        AlarmReceiver.processDue(this) // jaga-jaga kalau ada alarm yang terlewat
        renderAll()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        exec.shutdownNow()
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { doImport(it) }
            intent.action = null
        }
    }

    // ---------------------------------------------------------------- kerangka

    fun currentTag(): String? {
        val accounts = Store.accounts(this)
        if (accounts.isEmpty()) return null
        val sel = Store.selectedTag(this)
        return accounts.firstOrNull { it.tag == sel }?.tag ?: accounts.minByOrNull { it.tag }!!.tag
    }

    private fun renderAll() {
        renderHeader()
        renderSeg()
        renderNav()
        renderBody()
    }

    private fun renderHeader() {
        header.removeAllViews()
        val tag = currentTag()
        val acc = Store.accounts(this).firstOrNull { it.tag == tag }
        val label = if (acc == null) "🏰 Belum ada desa" else {
            val hall = if (showBB) (if (acc.bh > 0) " · BH${acc.bh}" else "") else (if (acc.th > 0) " · TH${acc.th}" else "")
            "🏰 ${Store.villageName(this, acc.tag)}$hall  ▾"
        }
        val vb = Ui.outlined(this, label) { VillagesUi.show(this) }
        vb.isAllCaps = false
        vb.maxLines = 1
        vb.ellipsize = android.text.TextUtils.TruncateAt.END
        header.addView(vb, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        if (acc != null) {
            val free = freeBuilders(acc.tag, showBB)
            val badge = Ui.pill(this, "🔨 $free bebas", if (free > 0) Ui.GREEN else Ui.GREY).apply { textSize = 12f }
            header.addView(badge, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT,
            ).apply { marginStart = dp(8) })
        }
        header.addView(Ui.flat(this, "⚙️") { openSettings() })
    }

    /** Builder bebas sekarang untuk satu desa (dari timer tersimpan). */
    fun freeBuilders(tag: String, bb: Boolean): Int {
        val now = System.currentTimeMillis()
        val kind = if (bb) Kind.BB_BUILDER else Kind.BUILDER
        val busy = Store.upgrades(this).count { it.tag == tag && it.kind == kind && it.finishAt > now }
        val total = if (bb) {
            planCache[tag]?.let { id.clashtimer.core.Planner.laneCount(it.village, id.clashtimer.core.Lane.BB_BUILDER, it.ps) }
                ?: maxOf(busy, 1)
        } else Store.accounts(this).firstOrNull { it.tag == tag }?.builders ?: 5
        return (total - busy).coerceAtLeast(0)
    }

    private fun renderSeg() {
        seg.removeAllViews()
        for (bb in listOf(false, true)) {
            val label = if (bb) "Builder Base" else "Home Village"
            val b: MaterialButton = if (bb == showBB) Ui.filled(this, label) { selectSide(bb) } else Ui.outlined(this, label) { selectSide(bb) }
            b.isAllCaps = false
            seg.addView(b, Ui.weight1().apply { if (bb) marginStart = dp(6) })
        }
    }

    private fun selectSide(bb: Boolean) {
        if (bb == showBB) return
        showBB = bb
        renderHeader()
        renderSeg()
        renderBody()
        scroll.scrollTo(0, 0)
    }

    private fun renderNav() {
        nav.removeAllViews()
        for (t in Tab.entries) {
            val selected = t == tab
            val item = TextView(this).apply {
                text = "${t.icon}\n${t.label}"
                gravity = Gravity.CENTER
                textSize = 12f
                setPadding(0, dp(6), 0, dp(6))
                setTextColor(if (selected) Ui.primary(this@MainActivity) else Ui.secondary(this@MainActivity))
                if (selected) setTypeface(typeface, Typeface.BOLD)
                setOnClickListener { selectTab(t) }
            }
            nav.addView(item, Ui.weight1())
        }
    }

    fun openTab(t: Tab) = selectTab(t)

    fun zoneId(): ZoneId = ZoneId.systemDefault()

    private fun selectTab(t: Tab) {
        if (t == tab) return
        tab = t
        renderNav()
        renderBody()
        scroll.scrollTo(0, 0)
    }

    fun selectVillage(tag: String) {
        Store.setSelectedTag(this, tag)
        renderAll()
        scroll.scrollTo(0, 0)
    }

    fun renderBody() {
        body.removeAllViews()
        countdowns.clear()
        val tag = currentTag()
        if (tag == null) {
            addWarnings(body)
            body.addView(Ui.text(this,
                "Belum ada desa.\n\nDi Clash of Clans: Settings → More Settings → paling bawah \"Export village data\" → Copy.\n\n" +
                    "Lalu tekan tombol di bawah. Untuk desa lain, ulangi dengan akun lain — semua desa tersimpan dan bisa dipilih dari tombol 🏰 di atas.",
                Ui.BODY_M,
            ).apply { setPadding(dp(4), dp(24), dp(4), dp(16)) })
            body.addView(Ui.filled(this, "📋 Import dari Clipboard") { importFromClipboard() }, Ui.matchWrap(6, this))
            body.addView(Ui.outlined(this, "Tempel teks export") { showPasteDialog() }, Ui.matchWrap())
            return
        }
        val b = planFor(tag)
        try {
            when (tab) {
                Tab.HOME -> HomeView.render(this, body, tag, showBB, b)
                Tab.PLAN -> if (b == null) waiting(tag) else PlanView.render(this, body, b, showBB)
                Tab.PROGRESS -> if (b == null) waiting(tag) else ProgressView.render(this, body, b, showBB)
            }
        } catch (e: Exception) {
            body.addView(Ui.text(this, "Gagal menampilkan: ${e.message}", Ui.BODY_M))
        }
    }

    private fun waiting(tag: String) {
        val msg = when {
            Store.exportText(this, tag) == null ->
                "Import ulang desa ini sekali (Export village data → Copy → 📋 Update desa) supaya rencana dan progres bisa dihitung."
            planError != null -> "Gagal menghitung: $planError"
            else -> "⏳ Menghitung rencana & progres…"
        }
        body.addView(Ui.text(this, msg, Ui.BODY_M).apply { setPadding(dp(4), dp(24), dp(4), 0) })
    }

    /** Ambil hasil hitung (cache); minta hitung ulang di background bila perlu. */
    fun planFor(tag: String): PlanBundle? {
        if (Store.exportText(this, tag) == null) return null
        val b = planCache[tag]
        val now = System.currentTimeMillis()
        val version = Store.planVersion(this)
        val stale = b == null || b.version != version || now - b.computedAt > 5 * 60_000L
        val failedHere = failedTag == tag && failedVersion == version
        if (stale && !failedHere) requestPlan(tag)
        return b
    }

    private fun requestPlan(tag: String) {
        if (computing == tag) return
        computing = tag
        val app = applicationContext
        val version = Store.planVersion(this)
        exec.execute {
            val r = runCatching { Repo.computePlan(app, tag) }
            runOnUiThread {
                computing = null
                if (isFinishing || isDestroyed) return@runOnUiThread
                val bundle = r.getOrNull()
                if (bundle != null) {
                    planCache[tag] = bundle
                    planError = null
                    failedTag = null
                } else {
                    planError = r.exceptionOrNull()?.let { it.message ?: it.javaClass.simpleName }
                        ?: "data export tidak bisa dibaca, coba import ulang"
                    failedTag = tag
                    failedVersion = version
                }
                if (tag == currentTag()) {
                    renderHeader()
                    renderBody()
                }
            }
        }
    }

    /** Data berubah (import, item, mulai, tandai selesai) → hitung ulang. */
    fun dataChanged() {
        planCache.clear()
        planError = null
        failedTag = null
        renderAll()
        Widgets.updateAll(this)
    }

    fun registerCountdown(tv: TextView, target: Long, clockStyle: Boolean) {
        countdowns += Countdown(tv, target, clockStyle)
    }

    // ---------------------------------------------------------------- import

    fun importFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (text.isNullOrBlank() || !text.contains("{")) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Clipboard kosong")
                .setMessage("Di Clash of Clans buka Settings → More Settings → paling bawah \"Export village data\" → Copy. Lalu kembali ke sini dan tekan Update desa lagi.")
                .setPositiveButton("OK", null)
                .setNeutralButton("Tempel manual") { _, _ -> showPasteDialog() }
                .show()
            return
        }
        doImport(text)
    }

    fun showPasteDialog() {
        val input = EditText(this).apply {
            hint = "Tempel teks export di sini"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4
            maxLines = 8
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, Ui.matchWrap())
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Tempel export desa")
            .setView(box)
            .setPositiveButton("Import") { _, _ -> doImport(input.text.toString()) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun doImport(text: String) {
        val before = Store.accounts(this).map { it.tag }.toSet()
        val s = try {
            Repo.importText(this, text)
        } catch (e: ExportException) {
            MaterialAlertDialogBuilder(this).setTitle("Gagal import").setMessage(e.message)
                .setPositiveButton("OK", null).show()
            return
        } catch (e: Exception) {
            MaterialAlertDialogBuilder(this).setTitle("Gagal import")
                .setMessage("Terjadi kesalahan: ${e.message}").setPositiveButton("OK", null).show()
            return
        }
        Store.setSelectedTag(this, s.tag)
        dataChanged()

        val now = System.currentTimeMillis()
        val name = Store.villageName(this, s.tag)
        val isNew = s.tag !in before
        val sb = StringBuilder(if (isNew) "Desa baru ditambahkan: $name.\n\n" else "")
        sb.append("${s.running} timer berjalan, notifikasi sudah dijadwalkan.")
        s.next?.let { sb.append("\n\nBerikutnya: ${it.title()} dalam ${Fmt.dur(it.finishAt - now)}.") }
        if (s.helped > 0) sb.append("\n\n🧑‍🔧 ${s.helped} upgrade dibantu helper berulang — waktu selesainya sudah diperkirakan.")
        val age = now - s.exportAt
        if (age > 6 * 3600_000L) sb.append("\n\n⚠️ Data export ini sudah ${Fmt.dur(age)} lalu. Export ulang dari game agar akurat.")
        if (s.unknown > 0) sb.append("\n\n${s.unknown} item belum dikenal (data game baru), tapi timernya tetap dihitung.")
        val dlg = MaterialAlertDialogBuilder(this).setTitle("✅ $name").setMessage(sb.toString())
            .setPositiveButton("OK", null)
        if (isNew) dlg.setNeutralButton("Beri nama") { _, _ -> VillagesUi.rename(this, s.tag) }
        dlg.show()
    }

    // ---------------------------------------------------------------- aksi

    /** Pengaturan untuk semua desa (opsi per desa ada di Beranda). */
    fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    fun openItems(tag: String) {
        if (Store.exportText(this, tag) == null) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Import ulang dulu")
                .setMessage("Desa ini di-import dengan versi lama. Import ulang sekali (Export village data → Copy → Update desa) supaya item bisa dicatat.")
                .setPositiveButton("OK", null).show()
            return
        }
        ItemsUi.open(this, tag)
    }

    /** Saran ditandai "sudah dimulai di game". */
    fun startPick(tag: String, pick: Scored) {
        val u = Repo.startUpgrade(this, tag, pick)
        dataChanged()
        val msg = if (u != null) "Timer dipasang: ${u.title()} selesai ${Fmt.at(u.finishAt, zone)}" else "Timer dipasang"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    fun timerOptions(u: Upgrade) {
        val hasExport = Store.exportText(this, u.tag) != null
        if (u.kind == Kind.HELPER) {
            MaterialAlertDialogBuilder(this)
                .setTitle(u.title())
                .setMessage("Timer helper berasal dari export. Hapus bila helper sudah Anda pakai.")
                .setPositiveButton("Hapus") { _, _ ->
                    if (hasExport) {
                        Store.setCancelled(this, u.tag, Store.cancelled(this, u.tag) + (u.id to System.currentTimeMillis()))
                        Repo.reproject(this, u.tag)
                    } else {
                        Store.saveUpgrades(this, Store.upgrades(this).filter { it.id != u.id })
                        AlarmScheduler.schedule(this)
                    }
                    dataChanged()
                }
                .setNegativeButton("Batal", null).show()
            return
        }
        val options = arrayOf<CharSequence>(
            "✅ Sudah selesai (dipercepat gem/book/potion)",
            "✖️ Upgrade dibatalkan / salah catat",
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(u.title())
            .setItems(options) { _, which ->
                val now = System.currentTimeMillis()
                if (hasExport) {
                    if (which == 0) Store.setDone(this, u.tag, Store.done(this, u.tag) + (u.id to now))
                    else Store.setCancelled(this, u.tag, Store.cancelled(this, u.tag) + (u.id to now))
                    Repo.reproject(this, u.tag)
                } else {
                    // Data versi lama (tanpa teks export): ubah timer langsung.
                    val list = Store.upgrades(this)
                    val updated = if (which == 0) list.map {
                        if (it.id == u.id) it.copy(finishAt = now).also { c -> c.doneNotified = true; c.earlyNotified = true } else it
                    } else list.filter { it.id != u.id }
                    Store.saveUpgrades(this, updated)
                    AlarmScheduler.schedule(this)
                }
                dataChanged()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    // ---------------------------------------------------------------- peringatan

    /** Banner izin (notifikasi, alarm tepat, baterai) di bagian atas Beranda. */
    fun addWarnings(box: LinearLayout) {
        if (!Notifier.canNotify(this)) {
            box.addView(warningCard(
                "🔕 Notifikasi belum diizinkan",
                "Tanpa izin ini, aplikasi tidak bisa memberi tahu saat upgrade selesai.",
                "Izinkan",
            ) {
                val prefs = getPreferences(MODE_PRIVATE)
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
                    !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) &&
                    prefs.getBoolean("asked_notif", false)
                ) openAppNotificationSettings()
                else if (Build.VERSION.SDK_INT >= 33) {
                    prefs.edit().putBoolean("asked_notif", true).apply()
                    notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else openAppNotificationSettings()
            })
        }
        if (!AlarmScheduler.canExact(this)) {
            box.addView(warningCard(
                "⏰ Izin alarm tepat waktu mati",
                "Notifikasi bisa telat beberapa menit. Aktifkan \"Alarm & pengingat\" untuk aplikasi ini.",
                "Buka pengaturan",
            ) {
                if (Build.VERSION.SDK_INT >= 31) {
                    startActivitySafe(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                }
            })
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) &&
            !getPreferences(MODE_PRIVATE).getBoolean("hide_battery_tip", false)
        ) {
            box.addView(warningCard(
                "🔋 Tips: matikan optimasi baterai",
                "Beberapa HP (Xiaomi, Oppo, Vivo, Realme, Samsung) suka mematikan aplikasi. " +
                    "Izinkan aplikasi ini berjalan tanpa batasan baterai, dan aktifkan Autostart bila ada.",
                "Atur",
                dismissible = true,
            ) { requestIgnoreBattery() })
        }
    }

    @SuppressLint("BatteryLife")
    fun requestIgnoreBattery() {
        val ok = startActivitySafe(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
        if (!ok) startActivitySafe(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    fun openAppNotificationSettings() {
        startActivitySafe(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
    }

    private fun startActivitySafe(i: Intent): Boolean = try {
        startActivity(i); true
    } catch (_: Exception) {
        false
    }

    private fun warningCard(
        title: String, body: String, action: String,
        dismissible: Boolean = false, onAction: () -> Unit,
    ): View {
        val (card, col) = Ui.card(this, padV = 12, tinted = true)
        col.setPadding(dp(14), dp(12), dp(14), dp(4))
        col.addView(Ui.text(this, title, Ui.TITLE_S))
        col.addView(Ui.text(this, body, Ui.BODY_S).apply { setPadding(0, dp(2), 0, 0) })
        val row = LinearLayout(this).apply { gravity = Gravity.END }
        if (dismissible) {
            row.addView(Ui.flat(this, "Sembunyikan") {
                getPreferences(MODE_PRIVATE).edit().putBoolean("hide_battery_tip", true).apply()
                renderBody()
            })
        }
        row.addView(Ui.flat(this, action) { onAction() })
        col.addView(row)
        return card
    }

    // ---------------------------------------------------------------- pembantu

    /** "12j 01m" / "1h 8j" / "45m 10d". */
    fun countdown(ms: Long): String {
        val s = (ms.coerceAtLeast(0) + 999) / 1000
        val d = s / 86400
        val h = (s % 86400) / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return when {
            d > 0 -> "${d}h ${h}j"
            h > 0 -> String.format(java.util.Locale.ROOT, "%dj %02dm", h, m)
            else -> String.format(java.util.Locale.ROOT, "%dm %02dd", m, sec)
        }
    }

    /** "12:01:27" (jam bisa lebih dari 24). */
    fun clock(ms: Long): String {
        val s = (ms.coerceAtLeast(0) + 999) / 1000
        return String.format(java.util.Locale.ROOT, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
    }

    fun dp(v: Int) = Ui.dp(this, v)
}
