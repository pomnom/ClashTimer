package id.clashtimer

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import id.clashtimer.core.ExportException
import id.clashtimer.core.Fmt
import java.time.ZoneId
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    enum class Tab(val label: String) { TIMER("⏱ Timer"), SARAN("💡 Saran"), PROGRES("📈 Progres") }

    private var tab = Tab.TIMER
    private lateinit var tabBar: LinearLayout
    private lateinit var timerScroll: ScrollView
    private lateinit var planScroll: ScrollView
    private lateinit var warnings: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var planBox: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private val countdowns = mutableListOf<Pair<TextView, Upgrade>>()
    private val zone: ZoneId get() = ZoneId.systemDefault()

    private val exec = Executors.newSingleThreadExecutor()
    private val planCache = HashMap<String, PlanBundle>()
    private var computing: String? = null
    private var planError: String? = null
    private var failedTag: String? = null
    private var failedVersion = -1

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        renderWarnings()
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (tab == Tab.TIMER) {
                // Ada timer yang baru saja habis → gambar ulang (status "Selesai", hitungan builder).
                if (countdowns.any { it.second.finishAt <= now }) render() else updateCountdowns(now)
            }
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000))
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.createChannels(this)
        savedInstanceState?.getString("tab")?.let { t -> runCatching { tab = Tab.valueOf(t) } }

        val root = Ui.vbox(this)
        tabBar = Ui.hbox(this).apply { setPadding(dp(12), dp(8), dp(12), 0) }
        root.addView(tabBar, Ui.matchWrap())

        val content = FrameLayout(this)
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        // --- tab Timer
        val timerCol = Ui.vbox(this).apply { setPadding(dp(16), dp(8), dp(16), dp(32)) }
        warnings = Ui.vbox(this)
        timerCol.addView(warnings)
        val buttons = Ui.hbox(this).apply { setPadding(0, dp(4), 0, 0) }
        buttons.addView(Ui.filled(this, "📋  Import dari Clipboard") { importFromClipboard() }, Ui.weight1())
        buttons.addView(Ui.outlined(this, "Tempel") { showPasteDialog() }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { marginStart = dp(8) })
        timerCol.addView(buttons)
        timerCol.addView(Ui.outlined(this, "⚡  Pakai potion / book / hammer") { openItems(null) }, Ui.matchWrap(4, this))
        listBox = Ui.vbox(this)
        timerCol.addView(listBox)
        timerScroll = ScrollView(this).apply { isFillViewport = true; addView(timerCol) }

        // --- tab Saran & Progres
        planBox = Ui.vbox(this).apply { setPadding(dp(16), dp(8), dp(16), dp(32)) }
        planScroll = ScrollView(this).apply { isFillViewport = true; addView(planBox) }

        content.addView(timerScroll)
        content.addView(planScroll)
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        renderTabs()
        handleShare(intent)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tab", tab.name)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    override fun onResume() {
        super.onResume()
        AlarmReceiver.processDue(this) // jaga-jaga kalau ada alarm yang terlewat
        renderWarnings()
        render()
        if (tab != Tab.TIMER) renderPlan()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        exec.shutdownNow()
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { doImport(it) }
            intent.action = null
        }
    }

    // ---------------------------------------------------------------- tab

    private fun renderTabs() {
        tabBar.removeAllViews()
        for (t in Tab.entries) {
            val b = if (t == tab) Ui.filled(this, t.label) { selectTab(t) } else Ui.flat(this, t.label) { selectTab(t) }
            b.setPadding(dp(4), b.paddingTop, dp(4), b.paddingBottom)
            tabBar.addView(b, Ui.weight1())
        }
        timerScroll.visibility = if (tab == Tab.TIMER) View.VISIBLE else View.GONE
        planScroll.visibility = if (tab == Tab.TIMER) View.GONE else View.VISIBLE
    }

    private fun selectTab(t: Tab) {
        if (t == tab) return
        tab = t
        renderTabs()
        if (t == Tab.TIMER) render() else { planScroll.scrollTo(0, 0); renderPlan() }
    }

    /** Data berubah (import, item, tandai selesai) → hitung ulang saran. */
    fun dataChanged() {
        planCache.clear()
        planError = null
        failedTag = null
        render()
        if (tab != Tab.TIMER) renderPlan()
    }

    // ---------------------------------------------------------------- import

    private fun importFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (text.isNullOrBlank() || !text.contains("{")) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Clipboard kosong")
                .setMessage("Di Clash of Clans buka Settings → More Settings → paling bawah \"Export village data\" → Copy. Lalu kembali ke sini dan tekan Import lagi.")
                .setPositiveButton("OK", null)
                .setNeutralButton("Tempel manual") { _, _ -> showPasteDialog() }
                .show()
            return
        }
        doImport(text)
    }

    private fun showPasteDialog() {
        val input = EditText(this).apply {
            hint = "Tempel teks export di sini"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4
            maxLines = 8
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, Ui.matchWrap())
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Tempel export desa")
            .setView(box)
            .setPositiveButton("Import") { _, _ -> doImport(input.text.toString()) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun doImport(text: String) {
        val s = try {
            Repo.importText(this, text)
        } catch (e: ExportException) {
            MaterialAlertDialogBuilder(this).setTitle("Gagal import").setMessage(e.message)
                .setPositiveButton("OK", null).show()
            return
        } catch (e: Exception) {
            MaterialAlertDialogBuilder(this).setTitle("Gagal import")
                .setMessage("Terjadi kesalahan: ${e.message}").setPositiveButton("OK", null).show()
            return
        }
        Store.setSelectedTag(this, s.tag)
        dataChanged()

        val now = System.currentTimeMillis()
        val sb = StringBuilder("${s.tag}: ${s.running} timer berjalan, notifikasi sudah dijadwalkan.")
        s.next?.let { sb.append("\n\nBerikutnya: ${it.title()} dalam ${Fmt.dur(it.finishAt - now)}.") }
        if (s.helped > 0) sb.append("\n\n🧑‍🔧 ${s.helped} upgrade dibantu helper berulang — waktu selesainya sudah diperkirakan dengan bantuan helper.")
        val age = now - s.exportAt
        if (age > 6 * 3600_000L) sb.append("\n\n⚠️ Data export ini sudah ${Fmt.dur(age)} lalu. Export ulang dari game agar akurat.")
        if (s.unknown > 0) sb.append("\n\n${s.unknown} item belum dikenal (data game baru), tapi timernya tetap dihitung.")
        MaterialAlertDialogBuilder(this).setTitle("✅ Import berhasil").setMessage(sb.toString())
            .setPositiveButton("OK", null).show()
    }

    // ---------------------------------------------------------------- peringatan

    private fun renderWarnings() {
        warnings.removeAllViews()
        if (!Notifier.canNotify(this)) {
            warnings.addView(warningCard(
                "🔕 Notifikasi belum diizinkan",
                "Tanpa izin ini, aplikasi tidak bisa memberi tahu saat upgrade selesai.",
                "Izinkan",
            ) {
                val prefs = getPreferences(MODE_PRIVATE)
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
                    !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) &&
                    prefs.getBoolean("asked_notif", false)
                ) openAppNotificationSettings()
                else if (Build.VERSION.SDK_INT >= 33) {
                    prefs.edit().putBoolean("asked_notif", true).apply()
                    notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else openAppNotificationSettings()
            })
        }
        if (!AlarmScheduler.canExact(this)) {
            warnings.addView(warningCard(
                "⏰ Izin alarm tepat waktu mati",
                "Notifikasi bisa telat beberapa menit. Aktifkan \"Alarm & pengingat\" untuk aplikasi ini.",
                "Buka pengaturan",
            ) {
                if (Build.VERSION.SDK_INT >= 31) {
                    startActivitySafe(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                }
            })
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) &&
            !getPreferences(MODE_PRIVATE).getBoolean("hide_battery_tip", false)
        ) {
            warnings.addView(warningCard(
                "🔋 Tips: matikan optimasi baterai",
                "Alarm sudah tepat waktu, tapi beberapa HP (Xiaomi, Oppo, Vivo, Realme, Samsung) suka mematikan aplikasi. " +
                    "Izinkan aplikasi ini berjalan tanpa batasan baterai, dan aktifkan Autostart bila ada.",
                "Atur",
                dismissible = true,
            ) { requestIgnoreBattery() })
        }
    }

    @SuppressLint("BatteryLife")
    fun requestIgnoreBattery() {
        val ok = startActivitySafe(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
        if (!ok) startActivitySafe(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    private fun openAppNotificationSettings() {
        startActivitySafe(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
    }

    private fun startActivitySafe(i: Intent): Boolean = try {
        startActivity(i); true
    } catch (_: Exception) {
        false
    }

    private fun warningCard(
        title: String, body: String, action: String,
        dismissible: Boolean = false, onAction: () -> Unit,
    ): View {
        val (card, col) = Ui.card(this, padV = 12, tinted = true)
        col.setPadding(dp(14), dp(12), dp(14), dp(4))
        col.addView(Ui.text(this, title, Ui.TITLE_S))
        col.addView(Ui.text(this, body, Ui.BODY_S).apply { setPadding(0, dp(2), 0, 0) })
        val row = LinearLayout(this).apply { gravity = Gravity.END }
        if (dismissible) {
            row.addView(Ui.flat(this, "Sembunyikan") {
                getPreferences(MODE_PRIVATE).edit().putBoolean("hide_battery_tip", true).apply()
                renderWarnings()
            })
        }
        row.addView(Ui.flat(this, action) { onAction() })
        col.addView(row)
        return card
    }

    // ---------------------------------------------------------------- daftar timer

    private fun render() {
        listBox.removeAllViews()
        countdowns.clear()
        val now = System.currentTimeMillis()
        val all = Store.upgrades(this)
        val accounts = Store.accounts(this)

        if (accounts.isEmpty()) {
            listBox.addView(Ui.text(this,
                "Belum ada desa.\n\nDi Clash of Clans: Settings → More Settings → paling bawah \"Export village data\" → Copy.\n\n" +
                    "Lalu buka aplikasi ini dan tekan \"Import dari Clipboard\". Ulangi import setiap kali Anda memulai upgrade baru.",
                Ui.BODY_M,
            ).apply { setPadding(dp(4), dp(24), dp(4), 0) })
            return
        }

        for (acc in accounts.sortedBy { it.tag }) {
            val ups = all.filter { it.tag == acc.tag }.sortedBy { it.finishAt }
            val header = Ui.vbox(this).apply {
                setPadding(dp(4), dp(16), dp(4), dp(6))
                isLongClickable = true
                setOnLongClickListener { confirmRemoveAccount(acc.tag); true }
            }
            val hall = if (acc.th > 0) "TH${acc.th} · " else ""
            header.addView(Ui.text(this, "🏰 ${acc.tag}", Ui.TITLE_L).apply { setTextColor(Ui.primary(this@MainActivity)) })
            val busy = ups.count { it.kind == Kind.BUILDER && it.finishAt > now }
            val labBusy = ups.any { it.kind == Kind.LAB && it.finishAt > now }
            header.addView(Ui.muted(this,
                "${hall}Builder sibuk $busy/${acc.builders} · Lab ${if (labBusy) "sibuk" else "kosong"} · export ${Fmt.at(acc.exportedAt, zone)}"))
            listBox.addView(header)

            if (ups.isEmpty()) {
                listBox.addView(Ui.text(this, "Tidak ada upgrade yang berjalan.", Ui.BODY_M).apply { setPadding(dp(4), 0, 0, dp(8)) })
                continue
            }
            for (village in listOf(false, true)) {
                val group = ups.filter { it.kind.builderBase == village }
                if (group.isEmpty()) continue
                listBox.addView(Ui.muted(this, if (village) "Builder Base" else "Home Village", Ui.LABEL_L).apply {
                    setPadding(dp(4), dp(8), 0, dp(4))
                })
                group.forEach { listBox.addView(row(it, now)) }
            }
        }
        listBox.addView(Ui.muted(this, "Tekan lama sebuah timer untuk menandai selesai/batal, atau nama akun untuk menghapus akun.").apply {
            setPadding(dp(4), dp(20), dp(4), 0)
            gravity = Gravity.CENTER
        })
    }

    private fun row(u: Upgrade, now: Long): View {
        val done = u.finishAt <= now
        val (card, col0) = Ui.card(this, padV = 0)
        card.isLongClickable = true
        card.setOnLongClickListener { timerOptions(u); true }
        if (done) card.alpha = 0.7f
        col0.setPadding(0, 0, 0, 0)
        val line = Ui.hbox(this).apply { setPadding(dp(14), dp(10), dp(14), dp(10)) }
        line.addView(Ui.text(this, u.kind.emoji, Ui.TITLE_L).apply { setPadding(0, 0, dp(12), 0) })
        val col = Ui.vbox(this)
        col.addView(Ui.text(this, u.title(), Ui.TITLE_S))
        var sub = "${u.kind.label} · ${Fmt.at(u.finishAt, zone)}"
        if (u.note.isNotBlank() && !done) sub += "\n" + u.note
        col.addView(Ui.muted(this, sub))
        line.addView(col, Ui.weight1())
        val cd = Ui.text(this, if (done) "✓ Selesai" else countdown(u.finishAt - now), Ui.TITLE_M).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setPadding(dp(8), 0, 0, 0)
            setTextColor(if (done) Ui.GREEN else Ui.primary(this@MainActivity))
        }
        line.addView(cd)
        if (!done) countdowns += cd to u
        col0.addView(line)
        return card
    }

    private fun updateCountdowns(now: Long) {
        for ((tv, u) in countdowns) tv.text = countdown(u.finishAt - now)
    }

    private fun timerOptions(u: Upgrade) {
        val hasExport = Store.exportText(this, u.tag) != null
        if (u.kind == Kind.HELPER) {
            MaterialAlertDialogBuilder(this)
                .setTitle(u.title())
                .setMessage("Timer helper berasal dari export. Hapus bila helper sudah Anda pakai.")
                .setPositiveButton("Hapus") { _, _ ->
                    if (hasExport) {
                        Store.setCancelled(this, u.tag, Store.cancelled(this, u.tag) + (u.id to System.currentTimeMillis()))
                        Repo.reproject(this, u.tag)
                    } else {
                        Store.saveUpgrades(this, Store.upgrades(this).filter { it.id != u.id })
                        AlarmScheduler.schedule(this)
                    }
                    dataChanged()
                }
                .setNegativeButton("Batal", null).show()
            return
        }
        val options = arrayOf<CharSequence>(
            "✅ Sudah selesai (dipercepat gem/book/potion)",
            "✖️ Upgrade dibatalkan",
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(u.title())
            .setItems(options) { _, which ->
                val now = System.currentTimeMillis()
                if (hasExport) {
                    if (which == 0) Store.setDone(this, u.tag, Store.done(this, u.tag) + (u.id to now))
                    else Store.setCancelled(this, u.tag, Store.cancelled(this, u.tag) + (u.id to now))
                    Repo.reproject(this, u.tag)
                } else {
                    // Data versi lama (tanpa teks export): ubah timer langsung.
                    val list = Store.upgrades(this)
                    val updated = if (which == 0) list.map {
                        if (it.id == u.id) it.copy(finishAt = now).also { c -> c.doneNotified = true; c.earlyNotified = true } else it
                    } else list.filter { it.id != u.id }
                    Store.saveUpgrades(this, updated)
                    AlarmScheduler.schedule(this)
                }
                dataChanged()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun confirmRemoveAccount(tag: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Hapus akun $tag?")
            .setMessage("Semua timer, catatan item, dan notifikasi akun ini akan dihapus.")
            .setPositiveButton("Hapus") { _, _ ->
                Store.removeAccount(this, tag)
                AlarmScheduler.schedule(this)
                dataChanged()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------------------------------------------------------------- saran & progres

    fun currentTag(): String? {
        val accounts = Store.accounts(this)
        if (accounts.isEmpty()) return null
        val sel = Store.selectedTag(this)
        return accounts.firstOrNull { it.tag == sel }?.tag ?: accounts.minByOrNull { it.tag }!!.tag
    }

    fun renderPlan() {
        planBox.removeAllViews()
        val accounts = Store.accounts(this)
        val tag = currentTag()
        if (tag == null) {
            planBox.addView(Ui.text(this, "Import desa dulu di tab Timer.", Ui.BODY_M).apply { setPadding(dp(4), dp(24), dp(4), 0) })
            return
        }
        if (accounts.size > 1) {
            planBox.addView(Ui.outlined(this, "🏰 $tag  ▾") {
                val tags = accounts.map { it.tag }.sorted()
                MaterialAlertDialogBuilder(this)
                    .setTitle("Pilih akun")
                    .setSingleChoiceItems(tags.toTypedArray<CharSequence>(), tags.indexOf(tag)) { d, w ->
                        Store.setSelectedTag(this, tags[w])
                        d.dismiss()
                        renderPlan()
                    }.show()
            }, Ui.matchWrap(4, this))
        }
        if (Store.exportText(this, tag) == null) {
            // Data dari versi lama: timer ada, tapi teks export lengkap belum tersimpan.
            planBox.addView(Ui.text(this,
                "Import ulang desa $tag sekali (Export village data → Copy → Import) supaya saran dan progres bisa dihitung.",
                Ui.BODY_M,
            ).apply { setPadding(dp(4), dp(24), dp(4), 0) })
            return
        }
        val b = planCache[tag]
        val now = System.currentTimeMillis()
        val version = Store.planVersion(this)
        val stale = b == null || b.version != version || now - b.computedAt > 5 * 60_000L
        val failedHere = failedTag == tag && failedVersion == version
        if (stale && !failedHere) requestPlan(tag)
        if (b == null) {
            val msg = planError?.let { "Gagal menghitung: $it" } ?: "⏳ Menghitung saran & progres…"
            planBox.addView(Ui.text(this, msg, Ui.BODY_M).apply { setPadding(dp(4), dp(24), dp(4), 0) })
            return
        }
        try {
            if (tab == Tab.SARAN) SuggestView.render(this, planBox, b) else ProgressView.render(this, planBox, b)
        } catch (e: Exception) {
            planBox.addView(Ui.text(this, "Gagal menampilkan: ${e.message}", Ui.BODY_M))
        }
    }

    private fun requestPlan(tag: String) {
        if (computing == tag) return
        computing = tag
        val app = applicationContext
        val version = Store.planVersion(this)
        exec.execute {
            val r = runCatching { Repo.computePlan(app, tag) }
            runOnUiThread {
                computing = null
                if (isFinishing || isDestroyed) return@runOnUiThread
                val bundle = r.getOrNull()
                if (bundle != null) {
                    planCache[tag] = bundle
                    planError = null
                    failedTag = null
                } else {
                    // Jangan coba lagi terus-menerus untuk data & pengaturan yang sama.
                    planError = r.exceptionOrNull()?.let { it.message ?: it.javaClass.simpleName }
                        ?: "data export tidak bisa dibaca, coba import ulang"
                    failedTag = tag
                    failedVersion = version
                }
                if (tab != Tab.TIMER) renderPlan()
            }
        }
    }

    fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    fun openItems(tag: String?) {
        val accounts = Store.accounts(this)
        if (accounts.isEmpty()) {
            Toast.makeText(this, "Import desa dulu", Toast.LENGTH_SHORT).show()
            return
        }
        val go = { t: String ->
            if (Store.exportText(this, t) == null) {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Import ulang dulu")
                    .setMessage("Akun $t di-import dengan versi lama. Import ulang sekali (Export village data → Copy → Import) supaya item bisa dicatat.")
                    .setPositiveButton("OK", null).show()
            } else ItemsUi.open(this, t)
        }
        if (tag != null || accounts.size == 1) {
            go(tag ?: accounts.first().tag)
            return
        }
        val tags = accounts.map { it.tag }.sorted()
        MaterialAlertDialogBuilder(this)
            .setTitle("Untuk akun mana?")
            .setItems(tags.toTypedArray<CharSequence>()) { _, w -> go(tags[w]) }
            .show()
    }

    // ---------------------------------------------------------------- menu

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Pengaturan")
        menu.add(0, 4, 0, "Tes notifikasi")
        menu.add(0, 5, 0, "Pengaturan baterai")
        menu.add(0, 6, 0, "Pengaturan notifikasi Android")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> openSettings()
            4 -> {
                if (!Notifier.canNotify(this)) Toast.makeText(this, "Izinkan notifikasi dulu", Toast.LENGTH_SHORT).show()
                else Notifier.test(this)
            }
            5 -> requestIgnoreBattery()
            6 -> openAppNotificationSettings()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // ---------------------------------------------------------------- pembantu

    private fun countdown(ms: Long): String {
        val s = (ms.coerceAtLeast(0) + 999) / 1000
        val d = s / 86400
        val h = (s % 86400) / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return when {
            d > 0 -> "${d}h ${h}j ${m}m"
            h > 0 -> "${h}j ${m}m ${sec}d"
            else -> "${m}m ${sec}d"
        }
    }

    fun dp(v: Int) = Ui.dp(this, v)
}
