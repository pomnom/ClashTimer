package id.clashtimer

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.TextViewCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var warnings: LinearLayout
    private lateinit var listBox: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val countdowns = mutableListOf<Pair<TextView, Upgrade>>()

    private val idLocale = Locale("id", "ID")
    private val fmtFinish = SimpleDateFormat("EEE d MMM, HH:mm", idLocale)
    private val fmtClock = SimpleDateFormat("d MMM HH:mm", idLocale)

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        renderWarnings()
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            // Ada timer yang baru saja habis → gambar ulang (status "Selesai", hitungan builder).
            if (countdowns.any { it.second.finishAt <= now }) render() else updateCountdowns(now)
            handler.postDelayed(this, 1000 - (System.currentTimeMillis() % 1000))
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Notifier.createChannels(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(32))
        }
        warnings = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(warnings)

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(4), 0, dp(8))
        }
        val importBtn = MaterialButton(this).apply {
            text = "📋  Import dari Clipboard"
            setOnClickListener { importFromClipboard() }
        }
        val pasteBtn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Tempel"
            setOnClickListener { showPasteDialog("") }
        }
        buttons.addView(importBtn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(pasteBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = dp(8) })
        root.addView(buttons)

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)

        setContentView(ScrollView(this).apply {
            isFillViewport = true
            addView(root)
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    override fun onResume() {
        super.onResume()
        AlarmReceiver.processDue(this) // jaga-jaga kalau ada alarm yang terlewat
        renderWarnings()
        render()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    private fun handleShare(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            intent.getStringExtra(Intent.EXTRA_TEXT)?.let { doImport(it) }
            intent.action = null
        }
    }

    // ---------------------------------------------------------------- import

    private fun importFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (text.isNullOrBlank() || !text.contains("{")) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Clipboard kosong")
                .setMessage("Di Clash of Clans buka Settings → More Settings → paling bawah \"Export village data\" → Copy. Lalu kembali ke sini dan tekan Import lagi.")
                .setPositiveButton("OK", null)
                .setNeutralButton("Tempel manual") { _, _ -> showPasteDialog("") }
                .show()
            return
        }
        doImport(text)
    }

    private fun showPasteDialog(prefill: String) {
        val input = EditText(this).apply {
            hint = "Tempel teks export di sini"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4
            maxLines = 8
            setText(prefill)
        }
        val box = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Tempel export desa")
            .setView(box)
            .setPositiveButton("Import") { _, _ -> doImport(input.text.toString()) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun doImport(text: String) {
        val result = try {
            ExportParser.parse(this, text)
        } catch (e: ExportException) {
            MaterialAlertDialogBuilder(this).setTitle("Gagal import").setMessage(e.message)
                .setPositiveButton("OK", null).show()
            return
        } catch (e: Exception) {
            MaterialAlertDialogBuilder(this).setTitle("Gagal import")
                .setMessage("Terjadi kesalahan: ${e.message}").setPositiveButton("OK", null).show()
            return
        }
        Store.replaceAccount(this, result, Store.earlyMinutes(this))
        AlarmReceiver.processDue(this)
        render()

        val now = System.currentTimeMillis()
        val running = result.upgrades.count { it.finishAt > now }
        val sb = StringBuilder("${result.account.tag}: $running timer berjalan, notifikasi sudah dijadwalkan.")
        result.upgrades.firstOrNull { it.finishAt > now }?.let {
            sb.append("\n\nBerikutnya: ${it.title()} dalam ${countdown(it.finishAt - now)}.")
        }
        val age = now - result.account.exportedAt
        if (age > 6 * 3600_000L) {
            sb.append("\n\n⚠️ Data export ini sudah ${countdown(age)} lalu. Export ulang dari game agar akurat.")
        }
        if (result.unknownCount > 0) {
            sb.append("\n\n${result.unknownCount} item belum dikenal namanya (data game baru), tapi timernya tetap dihitung.")
        }
        MaterialAlertDialogBuilder(this).setTitle("✅ Import berhasil").setMessage(sb.toString())
            .setPositiveButton("OK", null).show()
    }

    // ---------------------------------------------------------------- warnings

    private fun renderWarnings() {
        warnings.removeAllViews()
        if (!Notifier.canNotify(this)) {
            warnings.addView(warningCard(
                "🔕 Notifikasi belum diizinkan",
                "Tanpa izin ini, aplikasi tidak bisa memberi tahu saat upgrade selesai.",
                "Izinkan",
            ) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
                    shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS).not() &&
                    getPreferences(MODE_PRIVATE).getBoolean("asked_notif", false)
                ) openAppNotificationSettings()
                else if (Build.VERSION.SDK_INT >= 33) {
                    getPreferences(MODE_PRIVATE).edit().putBoolean("asked_notif", true).apply()
                    notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else openAppNotificationSettings()
            })
        }
        if (!AlarmScheduler.canExact(this)) {
            warnings.addView(warningCard(
                "⏰ Izin alarm tepat waktu mati",
                "Notifikasi bisa telat beberapa menit. Aktifkan \"Alarm & pengingat\" untuk aplikasi ini.",
                "Buka pengaturan",
            ) {
                if (Build.VERSION.SDK_INT >= 31) {
                    startActivitySafe(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                }
            })
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) &&
            !getPreferences(MODE_PRIVATE).getBoolean("hide_battery_tip", false)
        ) {
            warnings.addView(warningCard(
                "🔋 Tips: matikan optimasi baterai",
                "Alarm sudah tepat waktu, tapi beberapa HP (Xiaomi, Oppo, Vivo, Realme, Samsung) suka mematikan aplikasi. " +
                    "Izinkan aplikasi ini berjalan tanpa batasan baterai, dan aktifkan Autostart bila ada.",
                "Atur",
                dismissible = true,
            ) { requestIgnoreBattery() })
        }
    }

    @SuppressLint("BatteryLife")
    private fun requestIgnoreBattery() {
        val ok = startActivitySafe(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
        if (!ok) startActivitySafe(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    private fun openAppNotificationSettings() {
        startActivitySafe(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
    }

    private fun startActivitySafe(i: Intent): Boolean = try {
        startActivity(i); true
    } catch (_: Exception) {
        false
    }

    private fun warningCard(
        title: String, body: String, action: String,
        dismissible: Boolean = false, onAction: () -> Unit,
    ): View {
        val card = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = dp(8) }
            setCardBackgroundColor(MaterialColors.getColor(this, com.google.android.material.R.attr.colorSecondaryContainer))
            strokeWidth = 0
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(4))
        }
        col.addView(label(title, com.google.android.material.R.style.TextAppearance_Material3_TitleSmall))
        col.addView(label(body, com.google.android.material.R.style.TextAppearance_Material3_BodySmall).apply {
            setPadding(0, dp(2), 0, 0)
        })
        val row = LinearLayout(this).apply { gravity = Gravity.END }
        if (dismissible) {
            row.addView(MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
                text = "Sembunyikan"
                setOnClickListener {
                    getPreferences(MODE_PRIVATE).edit().putBoolean("hide_battery_tip", true).apply()
                    renderWarnings()
                }
            })
        }
        row.addView(MaterialButton(this, null, com.google.android.material.R.attr.borderlessButtonStyle).apply {
            text = action
            setOnClickListener { onAction() }
        })
        col.addView(row)
        card.addView(col)
        return card
    }

    // ---------------------------------------------------------------- list

    private fun render() {
        listBox.removeAllViews()
        countdowns.clear()
        val now = System.currentTimeMillis()
        val all = Store.upgrades(this)
        val accounts = Store.accounts(this)

        if (accounts.isEmpty()) {
            listBox.addView(label(
                "Belum ada desa.\n\nDi Clash of Clans: Settings → More Settings → paling bawah \"Export village data\" → Copy.\n\n" +
                    "Lalu buka aplikasi ini dan tekan \"Import dari Clipboard\". Ulangi import setiap kali Anda memulai upgrade baru.",
                com.google.android.material.R.style.TextAppearance_Material3_BodyMedium,
            ).apply { setPadding(dp(4), dp(24), dp(4), 0) })
            return
        }

        for (acc in accounts.sortedBy { it.tag }) {
            val ups = all.filter { it.tag == acc.tag }.sortedBy { it.finishAt }
            val header = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(4), dp(16), dp(4), dp(6))
                isLongClickable = true
                setOnLongClickListener { confirmRemoveAccount(acc.tag); true }
            }
            header.addView(label("🏰 ${acc.tag}", com.google.android.material.R.style.TextAppearance_Material3_TitleLarge).apply {
                setTextColor(MaterialColors.getColor(this, com.google.android.material.R.attr.colorPrimary))
            })
            val busy = ups.count { it.kind == Kind.BUILDER && it.finishAt > now }
            val labBusy = ups.any { it.kind == Kind.LAB && it.finishAt > now }
            val info = "Builder sibuk $busy/${acc.builders} · Lab ${if (labBusy) "sibuk" else "kosong"} · export ${fmtClock.format(Date(acc.exportedAt))}"
            header.addView(label(info, com.google.android.material.R.style.TextAppearance_Material3_BodySmall).apply {
                setTextColor(secondaryColor())
            })
            listBox.addView(header)

            if (ups.isEmpty()) {
                listBox.addView(label("Tidak ada upgrade yang berjalan.", com.google.android.material.R.style.TextAppearance_Material3_BodyMedium)
                    .apply { setPadding(dp(4), 0, 0, dp(8)) })
                continue
            }

            for (village in listOf(false, true)) {
                val group = ups.filter { it.kind.builderBase == village }
                if (group.isEmpty()) continue
                listBox.addView(label(if (village) "Builder Base" else "Home Village",
                    com.google.android.material.R.style.TextAppearance_Material3_LabelLarge).apply {
                    setPadding(dp(4), dp(8), 0, dp(4))
                    setTextColor(secondaryColor())
                })
                group.forEach { listBox.addView(row(it, now)) }
            }
        }
        listBox.addView(label("Tekan lama sebuah item atau nama akun untuk menghapusnya.",
            com.google.android.material.R.style.TextAppearance_Material3_BodySmall).apply {
            setPadding(dp(4), dp(20), dp(4), 0)
            setTextColor(secondaryColor())
            gravity = Gravity.CENTER
        })
    }

    private fun row(u: Upgrade, now: Long): View {
        val done = u.finishAt <= now
        val card = MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = dp(6) }
            isLongClickable = true
            setOnLongClickListener { confirmRemoveUpgrade(u); true }
            if (done) alpha = 0.7f
        }
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        line.addView(label(u.kind.emoji, com.google.android.material.R.style.TextAppearance_Material3_TitleLarge).apply {
            setPadding(0, 0, dp(12), 0)
        })
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(u.title(), com.google.android.material.R.style.TextAppearance_Material3_TitleSmall))
        var sub = "${u.kind.label} · ${fmtFinish.format(Date(u.finishAt))}"
        if (u.helped && !done) sub += "\n🧑‍🔧 dibantu helper — bisa selesai lebih cepat, import ulang setelah helper bekerja"
        col.addView(label(sub, com.google.android.material.R.style.TextAppearance_Material3_BodySmall).apply {
            setTextColor(secondaryColor())
        })
        line.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val cd = label(if (done) "✓ Selesai" else countdown(u.finishAt - now),
            com.google.android.material.R.style.TextAppearance_Material3_TitleMedium).apply {
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setPadding(dp(8), 0, 0, 0)
            setTextColor(
                if (done) Color.parseColor("#2E7D32")
                else MaterialColors.getColor(this, com.google.android.material.R.attr.colorPrimary)
            )
        }
        line.addView(cd)
        if (!done) countdowns += cd to u
        card.addView(line)
        return card
    }

    private fun updateCountdowns(now: Long) {
        for ((tv, u) in countdowns) tv.text = countdown(u.finishAt - now)
    }

    private fun confirmRemoveUpgrade(u: Upgrade) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Hapus timer?")
            .setMessage("${u.title()}\n\nGunakan ini bila upgrade sudah dipercepat/dibatalkan di game.")
            .setPositiveButton("Hapus") { _, _ ->
                Store.removeUpgrade(this, u.id)
                AlarmScheduler.schedule(this)
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun confirmRemoveAccount(tag: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Hapus akun $tag?")
            .setMessage("Semua timer dan notifikasi akun ini akan dihapus.")
            .setPositiveButton("Hapus") { _, _ ->
                Store.removeAccount(this, tag)
                AlarmScheduler.schedule(this)
                render()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------------------------------------------------------------- menu

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Pengingat sebelum selesai")
        menu.add(0, 2, 0, "Notifikasi helper").setCheckable(true)
        menu.add(0, 3, 0, "Mode alarm kuat").setCheckable(true)
        menu.add(0, 4, 0, "Tes notifikasi")
        menu.add(0, 5, 0, "Pengaturan baterai")
        menu.add(0, 6, 0, "Pengaturan notifikasi")
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(2)?.isChecked = Store.notifyHelpers(this)
        menu.findItem(3)?.isChecked = Store.strongAlarm(this)
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> chooseEarly()
            2 -> {
                Store.setNotifyHelpers(this, !Store.notifyHelpers(this))
                AlarmScheduler.schedule(this)
            }
            3 -> {
                val v = !Store.strongAlarm(this)
                Store.setStrongAlarm(this, v)
                AlarmScheduler.schedule(this)
                MaterialAlertDialogBuilder(this)
                    .setTitle(if (v) "Mode alarm kuat: AKTIF" else "Mode alarm kuat: MATI")
                    .setMessage(
                        if (v) "Paling tepat waktu, bahkan saat HP tidur. Android menampilkan ikon jam kecil di status bar."
                        else "Tanpa ikon jam. Biasanya tetap tepat, tapi saat HP lama tidur notifikasi yang berdekatan bisa tertunda beberapa menit."
                    )
                    .setPositiveButton("OK", null).show()
            }
            4 -> {
                if (!Notifier.canNotify(this)) Toast.makeText(this, "Izinkan notifikasi dulu", Toast.LENGTH_SHORT).show()
                else Notifier.test(this)
            }
            5 -> requestIgnoreBattery()
            6 -> openAppNotificationSettings()
            else -> return super.onOptionsItemSelected(item)
        }
        invalidateOptionsMenu()
        return true
    }

    private fun chooseEarly() {
        val options = intArrayOf(0, 5, 10, 15, 30, 60)
        val labels = options.map { if (it == 0) "Tidak ada (hanya saat selesai)" else "$it menit sebelumnya" }.toTypedArray()
        val current = options.indexOf(Store.earlyMinutes(this)).coerceAtLeast(0)
        MaterialAlertDialogBuilder(this)
            .setTitle("Pengingat tambahan")
            .setSingleChoiceItems(labels, current) { d, which ->
                val min = options[which]
                Store.setEarlyMinutes(this, min)
                // Yang sudah masuk jendela pengingat tidak perlu diberi pengingat mendadak.
                val now = System.currentTimeMillis()
                val list = Store.upgrades(this)
                list.forEach { u -> u.earlyNotified = u.doneNotified || (min > 0 && u.finishAt - min * 60_000L <= now) }
                Store.saveUpgrades(this, list)
                AlarmScheduler.schedule(this)
                d.dismiss()
            }
            .show()
    }

    // ---------------------------------------------------------------- helpers

    private fun countdown(ms: Long): String {
        val s = (ms.coerceAtLeast(0) + 999) / 1000
        val d = s / 86400
        val h = (s % 86400) / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return when {
            d > 0 -> "${d}h ${h}j ${m}m"
            h > 0 -> "${h}j ${m}m ${sec}d"
            else -> "${m}m ${sec}d"
        }
    }

    private fun label(s: String, style: Int) = TextView(this).apply {
        TextViewCompat.setTextAppearance(this, style)
        text = s
    }

    private fun secondaryColor() =
        MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant, Color.GRAY)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
