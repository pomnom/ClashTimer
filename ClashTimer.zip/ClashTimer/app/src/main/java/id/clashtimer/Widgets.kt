package id.clashtimer

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import id.clashtimer.core.Boosts
import id.clashtimer.core.BoostKind
import id.clashtimer.core.ClockTower
import id.clashtimer.core.DAY
import id.clashtimer.core.Fmt
import id.clashtimer.core.GameData
import id.clashtimer.core.Lane
import id.clashtimer.core.LaneSlot
import id.clashtimer.core.PlanSettings
import id.clashtimer.core.Planner
import id.clashtimer.core.Village
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.Executors

/** Widget layar utama: desa yang pekerjanya paling cepat bebas. */
class WidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        Widgets.render(context, appWidgetIds, goAsync())
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        Widgets.render(context, intArrayOf(appWidgetId), goAsync())
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        for (id in appWidgetIds) Widgets.forget(context, id)
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Widgets.ACTION_TOGGLE) {
            val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            if (id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                Widgets.toggle(context, id)
                Widgets.render(context, intArrayOf(id), goAsync())
            }
            return
        }
        super.onReceive(context, intent)
    }
}

object Widgets {
    const val ACTION_TOGGLE = "id.clashtimer.WIDGET_TOGGLE"
    const val EXTRA_TAG = "widget_tag"
    const val EXTRA_BB = "widget_bb"

    private const val PREFS = "clash_widgets"
    private val exec = Executors.newSingleThreadExecutor()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Sisi yang ditampilkan widget: false = Home Village, true = Builder Base. */
    private fun isBB(ctx: Context, id: Int) = prefs(ctx).getBoolean("bb_$id", false)

    fun toggle(ctx: Context, id: Int) {
        prefs(ctx).edit().putBoolean("bb_$id", !isBB(ctx, id)).commit()
    }

    fun forget(ctx: Context, id: Int) {
        prefs(ctx).edit().remove("bb_$id").apply()
    }

    /** Perbarui semua widget (setelah import, mulai upgrade, alarm, dll). [done] dipanggil setelah selesai. */
    fun updateAll(ctx: Context, done: (() -> Unit)? = null) {
        val app = ctx.applicationContext
        val mgr = AppWidgetManager.getInstance(app)
        val ids = runCatching { mgr.getAppWidgetIds(ComponentName(app, WidgetProvider::class.java)) }.getOrNull()
        if (mgr == null || ids == null || ids.isEmpty()) {
            done?.invoke()
            return
        }
        exec.execute {
            try {
                draw(app, mgr, ids)
            } catch (_: Throwable) {
            } finally {
                done?.invoke()
            }
        }
    }

    fun render(ctx: Context, ids: IntArray, pending: BroadcastReceiver.PendingResult?) {
        val app = ctx.applicationContext
        exec.execute {
            try {
                draw(app, AppWidgetManager.getInstance(app), ids)
            } catch (_: Throwable) {
            } finally {
                pending?.finish()
            }
        }
    }

    // ---------------------------------------------------------------- data

    private class Snap(
        val tag: String,
        val v: Village?,
        val ups: List<Upgrade>,
        val slots: List<LaneSlot>,
        val ps: PlanSettings,
        /** Kapan pekerja pertama (builder, lab, pet, BB, star lab) bebas. */
        val earliest: Long,
    )

    private fun snapshot(ctx: Context, gd: GameData, tag: String, all: List<Upgrade>, now: Long): Snap {
        val ups = all.filter { it.tag == tag }
        val ps = Store.planSettings(ctx, tag)
        val v = runCatching { Repo.village(ctx, tag) }.getOrNull()
        val fin = ups.associate { it.id to it.finishAt }
        val slots = if (v != null) runCatching { Planner.suggest(v, gd, ps, now, fin, upcoming = 3) }.getOrDefault(emptyList()) else emptyList()
        var earliest = Long.MAX_VALUE
        if (v != null) {
            for (s in slots) {
                // Pekerja yang bebas tetapi tidak punya pilihan upgrade tidak dihitung "bebas".
                if (s.freeAt <= now) { if (s.ranked.isNotEmpty()) earliest = minOf(earliest, now) }
                else earliest = minOf(earliest, s.freeAt)
            }
        } else {
            val acc = Store.accounts(ctx).firstOrNull { it.tag == tag }
            val busy = ups.count { it.kind == Kind.BUILDER && it.finishAt > now }
            if (acc != null && busy < acc.builders) earliest = now
            ups.filter { it.kind != Kind.HELPER && it.finishAt > now }.minOfOrNull { it.finishAt }?.let { earliest = minOf(earliest, it) }
        }
        return Snap(tag, v, ups, slots, ps, earliest)
    }

    private fun draw(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val now = System.currentTimeMillis()
        val gd = Repo.gameData(ctx)
        val all = Store.upgrades(ctx)
        val snaps = Store.accounts(ctx).map { snapshot(ctx, gd, it.tag, all, now) }
        val pick = snaps.minWithOrNull(compareBy<Snap>({ it.earliest }, { Store.villageName(ctx, it.tag).lowercase() }))
        for (id in ids) {
            val rv = if (pick == null) empty(ctx) else build(ctx, mgr, gd, id, pick, now)
            mgr.updateAppWidget(id, rv)
        }
    }

    // ---------------------------------------------------------------- tampilan

    private class RowIds(val row: Int, val icon: Int, val label: Int, val chrono: Int, val time: Int, val what: Int, val sub: Int)

    private val ROW1 = RowIds(R.id.w_row1, R.id.w_icon1, R.id.w_label1, R.id.w_chrono1, R.id.w_time1, R.id.w_what1, R.id.w_sub1)
    private val ROW2 = RowIds(R.id.w_row2, R.id.w_icon2, R.id.w_label2, R.id.w_chrono2, R.id.w_time2, R.id.w_what2, R.id.w_sub2)

    private fun color(ctx: Context, res: Int): Int = ctx.getColor(res)

    /** "15:08" (hari ini) atau "Sab 15:08". */
    private fun short(t: Long, now: Long, zone: ZoneId): String {
        val d1 = Instant.ofEpochMilli(t).atZone(zone).toLocalDate()
        val d0 = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        val time = Fmt.time(t, zone)
        return if (d1 == d0) time else DateTimeFormatter.ofPattern("EEE", Fmt.locale).format(d1) + " " + time
    }

    /** Tinggi widget (dp) di HP posisi tegak; 0 bila belum diketahui. */
    private fun heightDp(mgr: AppWidgetManager, id: Int): Int =
        runCatching { mgr.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT) }.getOrDefault(0)

    private fun fillRow(
        ctx: Context, rv: RemoteViews, ids: RowIds, label: String, finishAt: Long?, freeText: String,
        what: String, sub: String?, icon: String?, now: Long, showSub: Boolean,
    ) {
        rv.setViewVisibility(ids.row, View.VISIBLE)
        rv.setTextViewText(ids.label, label)
        if (finishAt == null) {
            rv.setViewVisibility(ids.chrono, View.GONE)
            rv.setViewVisibility(ids.time, View.VISIBLE)
            rv.setTextViewText(ids.time, freeText)
            rv.setTextColor(ids.time, color(ctx, R.color.widget_green))
        } else {
            val rem = finishAt - now
            if (rem in 1..DAY) {
                rv.setViewVisibility(ids.time, View.GONE)
                rv.setViewVisibility(ids.chrono, View.VISIBLE)
                rv.setChronometer(ids.chrono, SystemClock.elapsedRealtime() + rem, null, true)
                rv.setChronometerCountDown(ids.chrono, true)
            } else {
                rv.setViewVisibility(ids.chrono, View.GONE)
                rv.setViewVisibility(ids.time, View.VISIBLE)
                rv.setTextViewText(ids.time, if (rem <= 0) "selesai" else Fmt.dur(rem))
                rv.setTextColor(ids.time, color(ctx, if (rem <= 0) R.color.widget_green else R.color.widget_text))
            }
        }
        rv.setTextViewText(ids.what, what)
        if (showSub && !sub.isNullOrBlank()) {
            rv.setViewVisibility(ids.sub, View.VISIBLE)
            rv.setTextViewText(ids.sub, sub)
        } else rv.setViewVisibility(ids.sub, View.GONE)
        val bmp = Icons.bitmapBlocking(ctx, icon)
        if (bmp != null) {
            rv.setViewVisibility(ids.icon, View.VISIBLE)
            rv.setImageViewBitmap(ids.icon, bmp)
        } else rv.setViewVisibility(ids.icon, View.GONE)
    }

    private fun build(ctx: Context, mgr: AppWidgetManager, gd: GameData, id: Int, s: Snap, now: Long): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_village)
        val zone = ZoneId.systemDefault()
        val acc = Store.accounts(ctx).firstOrNull { it.tag == s.tag }
        val hasBB = (acc?.bh ?: 0) > 0 || s.ups.any { it.kind.builderBase }
        val bb = isBB(ctx, id) && hasBB
        val h = heightDp(mgr, id)
        val showSub = h >= 170
        val showExtra = h == 0 || h >= 128

        // --- judul
        val hall = if (bb) acc?.bh?.takeIf { it > 0 }?.let { " · BH$it" } else acc?.th?.takeIf { it > 0 }?.let { " · TH$it" }
        rv.setTextViewText(R.id.w_title, (if (bb) "🛠 " else "🏰 ") + Store.villageName(ctx, s.tag) + (hall ?: ""))

        val builderLane = if (bb) Lane.BB_BUILDER else Lane.BUILDER
        val builderKind = Kind.of(builderLane)
        val running = s.ups.filter { it.kind == builderKind && it.finishAt > now }.sortedBy { it.finishAt }
        val total = s.v?.let { Planner.laneCount(it, builderLane, s.ps) } ?: if (bb) maxOf(1, running.size) else (acc?.builders ?: 5)
        val free = (total - running.size).coerceAtLeast(0)
        rv.setTextViewText(R.id.w_free, "🔨 $free bebas")
        rv.setTextColor(R.id.w_free, color(ctx, if (free > 0) R.color.widget_green else R.color.widget_text2))

        // --- tombol ganti Home / Builder Base
        if (hasBB) {
            val other = if (bb) Lane.BUILDER else Lane.BB_BUILDER
            val t = s.slots.filter { it.lane == other }.minOfOrNull { it.freeAt }
            val whenTxt = when {
                t == null -> "–"
                t <= now -> "bebas"
                else -> short(t, now, zone)
            }
            rv.setViewVisibility(R.id.w_toggle, View.VISIBLE)
            rv.setTextViewText(R.id.w_toggle, (if (bb) "🏠 " else "🛠 ") + whenTxt)
            val toggle = Intent(ctx, WidgetProvider::class.java)
                .setAction(ACTION_TOGGLE)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
            rv.setOnClickPendingIntent(R.id.w_toggle, PendingIntent.getBroadcast(
                ctx, 5000 + id, toggle, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ))
        } else rv.setViewVisibility(R.id.w_toggle, View.GONE)

        // --- baris 1: builder
        val first = running.firstOrNull()
        val builderSlot = s.slots.firstOrNull { it.lane == builderLane && it.ranked.isNotEmpty() }
        val nextTimes = running.drop(1).take(3).joinToString(", ") { short(it.finishAt, now, zone) }
        val sub1 = "🔨 $free bebas" + if (nextTimes.isNotEmpty()) " · lalu $nextTimes" else ""
        if (first != null) {
            fillRow(ctx, rv, ROW1, if (bb) "Master" else "Builder", first.finishAt, "", first.title(), sub1,
                iconFor(gd, first), now, showSub)
        } else {
            val pick = builderSlot?.ranked?.firstOrNull()
            fillRow(ctx, rv, ROW1, if (bb) "Master" else "Builder", null, "bebas",
                if (free > 1) "$free builder menganggur" else "builder menganggur", null,
                pick?.let { Icons.forItem(it.c.item, it.c.fromLevel) }, now, showSub)
        }

        // --- baris 2: lab (+pet) atau star lab
        val labLane = if (bb) Lane.STAR_LAB else Lane.LAB
        val labKind = Kind.of(labLane)
        val lab = s.ups.filter { it.kind == labKind && it.finishAt > now }.minByOrNull { it.finishAt }
        val labExists = s.v?.let { Planner.laneCount(it, labLane, s.ps) > 0 } ?: (lab != null)
        val pet = if (bb) null else s.ups.filter { it.kind == Kind.PET && it.finishAt > now }.minByOrNull { it.finishAt }
        val petExists = !bb && (s.v?.let { Planner.laneCount(it, Lane.PET, s.ps) > 0 } ?: (pet != null))
        val petShort = when {
            !petExists -> ""
            pet != null -> " · 🐾 ${Fmt.dur(pet.finishAt - now)}"
            else -> " · 🐾 bebas"
        }
        val petSub = when {
            !petExists -> null
            pet != null -> "Pet House: ${pet.title()} · ${short(pet.finishAt, now, zone)}"
            else -> s.slots.firstOrNull { it.lane == Lane.PET && it.freeAt <= now }?.ranked?.firstOrNull()
                ?.let { "Pet House bebas · 💡 ${it.c.title}" } ?: "Pet House bebas"
        }
        val labLabel = if (bb) "Star Lab" else "Lab"
        if (!labExists && lab == null) {
            rv.setViewVisibility(R.id.w_row2, View.GONE)
        } else if (lab != null) {
            fillRow(ctx, rv, ROW2, labLabel, lab.finishAt, "", lab.title() + petShort, petSub, iconFor(gd, lab), now, showSub)
        } else {
            val labPick = s.slots.firstOrNull { it.lane == labLane && it.freeAt <= now }?.ranked?.firstOrNull()
            val what = (labPick?.let { "💡 ${it.c.title}" } ?: "tidak ada riset") + petShort
            fillRow(ctx, rv, ROW2, labLabel, null, "bebas", what, petSub,
                labPick?.let { Icons.forItem(it.c.item, it.c.fromLevel) }, now, showSub)
        }

        // --- saran builder
        val slot = builderSlot
        val pick = slot?.ranked?.firstOrNull()
        val tip = when {
            slot == null || pick == null -> "💡 Tidak ada saran untuk saat ini"
            slot.freeAt <= now -> "${if (pick.tier > 0) "🏗️" else "💡"} ${pick.c.title} · ${Fmt.durSec(pick.duration)}"
            else -> "${if (pick.tier > 0) "🏗️" else "💡"} ${short(slot.start, now, zone)}: ${pick.c.title} · ${Fmt.durSec(pick.duration)}"
        }
        rv.setTextViewText(R.id.w_tip, tip)

        // --- helper (Home) / Clock Tower (Builder Base)
        val extra = if (bb) clockTowerLine(ctx, s, now, zone) else helperLine(s, now, zone)
        if (showExtra && extra != null) {
            rv.setViewVisibility(R.id.w_extra, View.VISIBLE)
            rv.setTextViewText(R.id.w_extra, extra)
        } else rv.setViewVisibility(R.id.w_extra, View.GONE)

        // --- ketuk: buka tab Rencana desa ini
        val open = Intent(ctx, MainActivity::class.java)
            .setAction("id.clashtimer.OPEN_PLAN")
            .putExtra(EXTRA_TAG, s.tag)
            .putExtra(EXTRA_BB, bb)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(
            ctx, 6000 + id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        ))
        return rv
    }

    private fun iconFor(gd: GameData, u: Upgrade): String? {
        val item = Repo.itemIdOf(u.id)?.let { gd.item(it) } ?: return null
        val gear = u.id.contains("|gear|")
        return Icons.forItem(item, if (gear) u.targetLevel else (u.targetLevel - 1).coerceAtLeast(1))
    }

    private fun helperLine(s: Snap, now: Long, zone: ZoneId): String? {
        val parts = ArrayList<String>()
        for ((hid, label) in listOf(GameData.APPRENTICE to "🧑‍🔧 Apprentice", GameData.LAB_ASSISTANT to "🧪 Lab Assistant")) {
            val level = s.v?.helper(hid)?.level
            val timer = s.ups.firstOrNull { it.id == "${s.tag}|helpers|$hid" }
            if (level == null && timer == null) continue
            parts += if (timer != null && timer.finishAt > now) "$label ${short(timer.finishAt, now, zone)}" else "$label siap"
        }
        return parts.joinToString(" · ").ifBlank { null }
    }

    private fun clockTowerLine(ctx: Context, s: Snap, now: Long, zone: ZoneId): String? {
        val v = s.v ?: return null
        val ct = v.insts.firstOrNull { it.item.id == GameData.CLOCK_TOWER } ?: return null
        val upgrade = s.ups.firstOrNull { !it.id.contains("|gear|") && Repo.itemIdOf(it.id) == GameData.CLOCK_TOWER && it.finishAt > now }
        val boosts = Store.boosts(ctx, s.tag)
        val active = Boosts.merged(boosts).firstOrNull { it.kind.group == "clock" && it.start <= now && it.end > now }
        val last = boosts.filter { it.kind == BoostKind.CLOCK_TOWER }.maxByOrNull { it.start }
        val ready = last?.let { it.start + ClockTower.COOLDOWN }?.takeIf { it > now }
        val level = if (ct.upgrading && upgrade == null) ct.level + 1 else ct.level
        return "⏱️ Clock Tower: " + when {
            active != null -> "aktif s/d ${Fmt.time(active.end, zone)}"
            upgrade != null -> "di-upgrade s/d ${short(upgrade.finishAt, now, zone)}"
            ready != null -> "siap ±${short(ready, now, zone)}"
            else -> "boost siap (${ClockTower.boostMinutes(level)} menit)"
        }
    }

    private fun empty(ctx: Context): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_village)
        rv.setTextViewText(R.id.w_title, "🏰 Clash Timer")
        rv.setTextViewText(R.id.w_free, "")
        rv.setViewVisibility(R.id.w_toggle, View.GONE)
        rv.setViewVisibility(R.id.w_row2, View.GONE)
        rv.setViewVisibility(R.id.w_extra, View.GONE)
        rv.setViewVisibility(R.id.w_icon1, View.GONE)
        rv.setViewVisibility(R.id.w_chrono1, View.GONE)
        rv.setTextViewText(R.id.w_label1, "")
        rv.setTextViewText(R.id.w_time1, "")
        rv.setTextViewText(R.id.w_what1, "Belum ada desa")
        rv.setTextViewText(R.id.w_tip, "Buka aplikasi lalu import Export village data")
        val open = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(
            ctx, 5999, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        ))
        return rv
    }
}
