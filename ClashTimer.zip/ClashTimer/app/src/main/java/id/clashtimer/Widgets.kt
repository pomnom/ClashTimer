package id.clashtimer

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import id.clashtimer.core.DAY
import id.clashtimer.core.Fmt
import id.clashtimer.core.GameData
import id.clashtimer.core.Lane
import id.clashtimer.core.LaneSlot
import id.clashtimer.core.PlanSettings
import id.clashtimer.core.Planner
import id.clashtimer.core.Village
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.Executors

/**
 * Widget layar utama "Semua desa": satu baris per desa dengan kolom Builder, Lab, Builder Base,
 * Star Lab. Di tablet (sw600dp) memakai layout besar: huruf lebih besar, baris mengisi tinggi
 * widget, dan nama upgrade tampil di bawah tiap waktu.
 */
class AllVillagesWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        Widgets.renderAll(context, appWidgetIds, goAsync())
    }

    override fun onAppWidgetOptionsChanged(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        Widgets.renderAll(context, intArrayOf(appWidgetId), goAsync())
    }
}

object Widgets {
    const val EXTRA_TAG = "widget_tag"
    const val EXTRA_BB = "widget_bb"
    /** "HOME" atau "PLAN" (widget membuka Rencana, notifikasi membuka Beranda). */
    const val EXTRA_TAB = "widget_tab"

    private val exec = Executors.newSingleThreadExecutor()

    /** Perbarui semua widget (setelah import, mulai upgrade, alarm, dll). [done] dipanggil setelah selesai. */
    fun updateAll(ctx: Context, done: (() -> Unit)? = null) {
        val app = ctx.applicationContext
        val mgr: AppWidgetManager? = AppWidgetManager.getInstance(app)
        val ids = if (mgr != null) idsOf(app, mgr) else IntArray(0)
        if (mgr == null || ids.isEmpty()) {
            done?.invoke()
            return
        }
        exec.execute {
            try {
                draw(app, mgr, ids)
            } catch (_: Throwable) {
            } finally {
                done?.invoke()
            }
        }
    }

    private fun idsOf(ctx: Context, mgr: AppWidgetManager): IntArray =
        runCatching { mgr.getAppWidgetIds(ComponentName(ctx, AllVillagesWidget::class.java)) }.getOrNull() ?: IntArray(0)

    fun renderAll(ctx: Context, ids: IntArray, pending: BroadcastReceiver.PendingResult?) {
        val app = ctx.applicationContext
        exec.execute {
            try {
                draw(app, AppWidgetManager.getInstance(app), ids)
            } catch (_: Throwable) {
            } finally {
                pending?.finish()
            }
        }
    }

    // ---------------------------------------------------------------- data

    private class Snap(
        val tag: String,
        val v: Village?,
        val ups: List<Upgrade>,
        /** Pekerja yang bebas sekarang beserta pilihan upgradenya. */
        val slots: List<LaneSlot>,
        val ps: PlanSettings,
    )

    private fun snapshot(ctx: Context, gd: GameData, tag: String, all: List<Upgrade>, now: Long): Snap {
        val ups = all.filter { it.tag == tag }
        val ps = Store.planSettings(ctx, tag)
        val v = runCatching { Repo.village(ctx, tag) }.getOrNull()
        val fin = ups.associate { it.id to it.finishAt }
        val slots = if (v != null) runCatching { Planner.suggest(v, gd, ps, now, fin, upcoming = 0) }.getOrDefault(emptyList()) else emptyList()
        return Snap(tag, v, ups, slots, ps)
    }

    private fun draw(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        if (ids.isEmpty()) return
        val now = System.currentTimeMillis()
        val gd = Repo.gameData(ctx)
        val all = Store.upgrades(ctx)
        val snaps = Store.accounts(ctx).map { snapshot(ctx, gd, it.tag, all, now) }
        for (id in ids) {
            val rv = runCatching { build(ctx, mgr, id, snaps, now) }.getOrElse { message(ctx, "Buka aplikasi untuk memperbarui") }
            mgr.updateAppWidget(id, rv)
        }
    }

    // ---------------------------------------------------------------- kolom

    private val LANES = listOf(Lane.BUILDER, Lane.LAB, Lane.BB_BUILDER, Lane.STAR_LAB)

    /** Chronometer, teks waktu, dan baris nama upgrade (hanya ada di layout tablet) tiap kolom. */
    private class CellIds(val chrono: Int, val text: Int, val sub: Int)

    private val CELL_IDS = listOf(
        CellIds(R.id.ar_c1, R.id.ar_t1, R.id.ar_s1), CellIds(R.id.ar_c2, R.id.ar_t2, R.id.ar_s2),
        CellIds(R.id.ar_c3, R.id.ar_t3, R.id.ar_s3), CellIds(R.id.ar_c4, R.id.ar_t4, R.id.ar_s4),
    )

    /** Perkiraan tinggi (dp): satu baris desa, bagian tetap (padding, judul, judul kolom, catatan bawah), catatan bawah. */
    private class Metrics(val rowDp: Int, val chromeDp: Int, val footerDp: Int)

    private val PHONE = Metrics(45, 82, 24)
    private val TABLET = Metrics(72, 128, 30)

    /** Status satu jenis pekerja di satu desa. */
    private class Cell(
        val lane: Lane,
        /** Jumlah pekerja (0 = belum ada, mis. Star Lab belum dibangun). */
        val total: Int,
        /** Pekerja bebas yang punya pilihan upgrade. */
        val free: Int,
        /** Upgrade berjalan yang paling cepat selesai. */
        val next: Upgrade?,
        /** Saran untuk pekerja yang bebas. */
        val tip: String?,
    ) {
        fun soonest(now: Long): Long = when {
            free > 0 -> now
            next != null -> next.finishAt
            else -> Long.MAX_VALUE
        }
    }

    private fun cellOf(s: Snap, acc: Account?, lane: Lane, now: Long): Cell {
        val kind = Kind.of(lane)
        val running = s.ups.filter { it.kind == kind && it.finishAt > now }
        val next = running.minByOrNull { it.finishAt }
        val v = s.v
        if (v == null) {
            val total = maxOf(if (lane == Lane.BUILDER) acc?.builders ?: 0 else 0, running.size)
            return Cell(lane, total, (total - running.size).coerceAtLeast(0), next, null)
        }
        val total = maxOf(Planner.laneCount(v, lane, s.ps), running.size)
        // Pekerja bebas tanpa pilihan upgrade (sudah max) tidak dihitung "bebas".
        val slot = s.slots.firstOrNull { it.lane == lane && it.freeAt <= now }
        val pick = slot?.ranked?.firstOrNull()
        val free = if (pick != null) slot?.count ?: 0 else 0
        return Cell(lane, total, free, next, pick?.c?.title)
    }

    private fun laneName(lane: Lane): String = when (lane) {
        Lane.BUILDER -> "Builder"
        Lane.LAB -> "Lab"
        Lane.PET -> "Pet House"
        Lane.BB_BUILDER -> "Builder BB"
        Lane.STAR_LAB -> "Star Lab"
    }

    /** "Hidden Tesla → 8", "Cannon · Gear-up" (untuk baris kecil di tablet). */
    private fun shortTitle(u: Upgrade): String = when {
        u.customTitle.isNotBlank() -> u.customTitle
        u.targetLevel > 0 -> keep("${u.name} → ${u.targetLevel}")
        else -> u.name
    }

    /** Spasi tak terputus agar "→ 8" / "Lv 2" tidak terpisah ke baris berikutnya. */
    private fun keep(text: String): String = text.replace(" → ", "\u00A0→\u00A0").replace("Lv ", "Lv\u00A0")

    private fun showText(ctx: Context, rv: RemoteViews, ids: CellIds, value: String, colorRes: Int) {
        rv.setViewVisibility(ids.chrono, View.GONE)
        rv.setViewVisibility(ids.text, View.VISIBLE)
        rv.setTextViewText(ids.text, value)
        rv.setTextColor(ids.text, color(ctx, colorRes))
    }

    private fun fillCell(ctx: Context, rv: RemoteViews, ids: CellIds, c: Cell, now: Long, large: Boolean) {
        val next = c.next
        var sub = ""
        var subColor = R.color.widget_text2
        when {
            c.free > 0 -> {
                showText(ctx, rv, ids, if (c.free > 1) "${c.free} bebas" else "bebas", R.color.widget_green)
                c.tip?.let {
                    sub = "💡 " + keep(it)
                    subColor = R.color.widget_accent
                }
            }
            next != null -> {
                val rem = next.finishAt - now
                if (rem in 1..DAY) {
                    rv.setViewVisibility(ids.text, View.GONE)
                    rv.setViewVisibility(ids.chrono, View.VISIBLE)
                    rv.setChronometer(ids.chrono, SystemClock.elapsedRealtime() + rem, null, true)
                    rv.setChronometerCountDown(ids.chrono, true)
                } else showText(ctx, rv, ids, Fmt.dur(rem), R.color.widget_text)
                sub = shortTitle(next)
            }
            c.total > 0 -> showText(ctx, rv, ids, "max", R.color.widget_text2)
            else -> {
                showText(ctx, rv, ids, "–", R.color.widget_text2)
                sub = "belum ada"
            }
        }
        if (large) {
            rv.setTextViewText(ids.sub, sub)
            rv.setTextColor(ids.sub, color(ctx, subColor))
        }
    }

    // ---------------------------------------------------------------- tampilan

    private fun build(ctx: Context, mgr: AppWidgetManager, id: Int, snaps: List<Snap>, now: Long): RemoteViews {
        if (snaps.isEmpty()) return message(ctx, "Belum ada desa · buka aplikasi lalu import Export village data")
        val large = runCatching { ctx.resources.getBoolean(R.bool.widget_large) }.getOrDefault(false)
        val m = if (large) TABLET else PHONE
        val rv = base(ctx)
        val zone = ZoneId.systemDefault()
        val accs = Store.accounts(ctx).associateBy { it.tag }
        val names = snaps.associate { it.tag to Store.villageName(ctx, it.tag) }
        val rows = snaps.map { s -> s to LANES.map { cellOf(s, accs[s.tag], it, now) } }
            .sortedWith(compareBy<Pair<Snap, List<Cell>>>({ r -> r.second.minOf { it.soonest(now) } }, { r -> names[r.first.tag].orEmpty().lowercase() }))

        // Jumlah baris mengikuti tinggi widget; catatan bawah disembunyikan bila sempit.
        val h = heightDp(mgr, id)
        var showFooter = true
        var fit = if (h > 0) (h - m.chromeDp) / m.rowDp else 3
        if (fit < 1) {
            showFooter = false
            fit = ((h - m.chromeDp + m.footerDp) / m.rowDp).coerceAtLeast(1)
        }
        val shown = rows.take(fit.coerceAtMost(8))
        val hidden = rows.size - shown.size

        val freeTotal = rows.sumOf { r -> r.second.sumOf { it.free } }
        val count = if (hidden > 0) "${shown.size}/${rows.size} desa" else "${rows.size} desa"
        rv.setTextViewText(R.id.a_summary, "$count · $freeTotal bebas")
        rv.setTextColor(R.id.a_summary, color(ctx, if (freeTotal > 0) R.color.widget_green else R.color.widget_text2))

        rv.removeAllViews(R.id.a_rows)
        shown.forEachIndexed { i, (s, cells) ->
            val row = RemoteViews(ctx.packageName, R.layout.widget_all_row)
            val acc = accs[s.tag]
            row.setTextViewText(R.id.ar_name, names[s.tag].orEmpty())
            row.setTextViewText(R.id.ar_hall, listOfNotNull(
                acc?.th?.takeIf { it > 0 }?.let { "TH$it" },
                acc?.bh?.takeIf { it > 0 }?.let { "BH$it" },
            ).joinToString(" · "))
            cells.forEachIndexed { k, c -> fillCell(ctx, row, CELL_IDS[k], c, now, large) }
            // Ketuk baris: buka tab Rencana desa itu.
            val open = Intent(ctx, MainActivity::class.java)
                .setAction("id.clashtimer.OPEN_PLAN")
                .setData(Uri.parse("clashtimer://desa/" + Uri.encode(s.tag)))
                .putExtra(EXTRA_TAG, s.tag)
                .putExtra(EXTRA_BB, false)
                .putExtra(EXTRA_TAB, "PLAN")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            row.setOnClickPendingIntent(R.id.ar_row, PendingIntent.getActivity(
                ctx, 9_100_000 + i, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ))
            rv.addView(R.id.a_rows, row)
        }

        if (!showFooter) {
            rv.setViewVisibility(R.id.a_footer_line, View.GONE)
            rv.setViewVisibility(R.id.a_footer, View.GONE)
            return rv
        }
        val free = rows.firstNotNullOfOrNull { (s, cells) -> cells.firstOrNull { it.free > 0 }?.let { s to it } }
        if (free != null) {
            val (s, c) = free
            val what = c.tip?.let { ": $it" } ?: " bebas"
            rv.setTextViewText(R.id.a_footer, "💡 ${names[s.tag]} · ${laneName(c.lane)}$what")
            rv.setTextColor(R.id.a_footer, color(ctx, R.color.widget_accent))
        } else {
            val next = rows.flatMap { (s, cells) -> cells.mapNotNull { c -> c.next?.let { s to it } } }
                .minByOrNull { it.second.finishAt }
            rv.setTextViewText(R.id.a_footer, next?.let { (s, u) ->
                "⏱️ Berikutnya: ${names[s.tag]} · ${u.title()}, ${short(u.finishAt, now, zone)}"
            } ?: "Tidak ada upgrade berjalan")
            rv.setTextColor(R.id.a_footer, color(ctx, R.color.widget_text2))
        }
        return rv
    }

    /** Kerangka widget; ketuk di luar baris membuka aplikasi. */
    private fun base(ctx: Context): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_all)
        val open = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        rv.setOnClickPendingIntent(R.id.a_root, PendingIntent.getActivity(
            ctx, 5998, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        ))
        return rv
    }

    private fun message(ctx: Context, text: String): RemoteViews {
        val rv = base(ctx)
        rv.setTextViewText(R.id.a_summary, "")
        rv.setViewVisibility(R.id.a_cols, View.GONE)
        rv.removeAllViews(R.id.a_rows)
        rv.setViewVisibility(R.id.a_footer_line, View.GONE)
        rv.setTextViewText(R.id.a_footer, text)
        rv.setTextColor(R.id.a_footer, color(ctx, R.color.widget_text2))
        return rv
    }

    private fun color(ctx: Context, res: Int): Int = ctx.getColor(res)

    /** "15:08" (hari ini) atau "Sab 15:08". */
    private fun short(t: Long, now: Long, zone: ZoneId): String {
        val d1 = Instant.ofEpochMilli(t).atZone(zone).toLocalDate()
        val d0 = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
        val time = Fmt.time(t, zone)
        return if (d1 == d0) time else DateTimeFormatter.ofPattern("EEE", Fmt.locale).format(d1) + " " + time
    }

    /** Tinggi widget (dp) di posisi tegak; 0 bila belum diketahui. */
    private fun heightDp(mgr: AppWidgetManager, id: Int): Int =
        runCatching { mgr.getAppWidgetOptions(id).getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT) }.getOrDefault(0)
}
