package id.clashtimer

import android.content.Context
import id.clashtimer.core.Boosts
import id.clashtimer.core.Fmt
import id.clashtimer.core.GameData
import id.clashtimer.core.ExportReader
import id.clashtimer.core.ItemAdvisor
import id.clashtimer.core.ItemTip
import id.clashtimer.core.Lane
import id.clashtimer.core.LaneSlot
import id.clashtimer.core.PlanSettings
import id.clashtimer.core.Planner
import id.clashtimer.core.ProgressCalc
import id.clashtimer.core.Projector
import id.clashtimer.core.SimResult
import id.clashtimer.core.Village
import id.clashtimer.core.VillageProgress
import java.time.ZoneId

class ImportSummary(val tag: String, val running: Int, val next: Upgrade?, val exportAt: Long, val unknown: Int, val helped: Int)

class PlanBundle(
    val tag: String,
    val village: Village,
    val ps: PlanSettings,
    val slots: List<LaneSlot>,
    val tips: List<ItemTip>,
    val home: VillageProgress,
    val bb: VillageProgress?,
    val simHome: SimResult,
    val simBB: SimResult?,
    val computedAt: Long,
    val version: Int,
)

/** Penghubung antara penyimpanan Android dan logika inti. */
object Repo {
    @Volatile private var gd: GameData? = null

    fun gameData(ctx: Context): GameData {
        gd?.let { return it }
        synchronized(this) {
            gd?.let { return it }
            val text = ctx.assets.open("gamedata.json").bufferedReader().use { it.readText() }
            return GameData.parse(text).also { gd = it }
        }
    }

    /** Desa tersimpan + koreksi sejak export (book, hammer, dibatalkan). */
    fun village(ctx: Context, tag: String): Village? {
        val text = Store.exportText(ctx, tag) ?: return null
        val v = runCatching { ExportReader.read(text, gameData(ctx), System.currentTimeMillis()) }.getOrNull() ?: return null
        v.applyOverrides(Store.done(ctx, tag).keys, Store.bumps(ctx, tag).map { it.first to it.second })
        val cancelled = Store.cancelled(ctx, tag).keys
        for (i in v.insts) if (i.uid in cancelled) { i.upgrading = false; i.remaining = 0 }
        return v
    }

    private fun helperName(lane: Lane): String = when (lane) {
        Lane.BUILDER -> "Builder's Apprentice"
        Lane.LAB -> "Lab Assistant"
        else -> "helper"
    }

    /** Susun daftar timer (dengan proyeksi helper & potion) dari data export. */
    fun buildTimers(ctx: Context, v: Village): List<Upgrade> {
        val tag = v.tag
        val zone = ZoneId.systemDefault()
        val boosts = Store.boosts(ctx, tag)
        val done = Store.done(ctx, tag)
        val cancelled = Store.cancelled(ctx, tag)
        val list = ArrayList<Upgrade>()
        val finishes = HashMap<String, Long>()

        for (t in v.timers) {
            if (t.uid in cancelled) continue
            val helper = Projector.helperFor(v, t.lane, t.helped)
            val p = Projector.project(v.exportAt, t.remaining, t.lane, boosts, helper)
            val doneAt = done[t.uid]
            val finish = doneAt ?: p.finishAt
            finishes[t.uid] = finish
            val noBoost = Projector.project(v.exportAt, t.remaining, t.lane, emptyList(), helper).finishAt
            val notes = ArrayList<String>()
            if (doneAt != null) notes += "Ditandai selesai lebih awal"
            else {
                if (p.helperSessions.isNotEmpty()) {
                    notes += "🧑‍🔧 dibantu ${helperName(t.lane)} ${p.helperSessions.size}× (perkiraan) · tanpa helper ${Fmt.at(p.baseFinishAt, zone)}"
                }
                if (noBoost - p.finishAt > 60_000) notes += "⚡ dipercepat item ${Fmt.dur(noBoost - p.finishAt)}"
            }
            list += Upgrade(
                id = t.uid, tag = tag, kind = Kind.of(t.lane), name = t.name,
                targetLevel = t.fromLevel + 1, finishAt = finish, helped = t.helped,
                baseFinishAt = p.baseFinishAt, note = notes.joinToString("\n"),
            )
        }

        // Cooldown helper
        for (h in v.helpers) {
            if (h.cooldown <= 0 || "$tag|helpers|${h.id}" in cancelled) continue
            val at = v.exportAt + h.cooldown * 1000
            val lane = when (h.id) {
                GameData.APPRENTICE -> Lane.BUILDER
                GameData.LAB_ASSISTANT -> Lane.LAB
                else -> null
            }
            val target = if (lane == null) null else v.timers.firstOrNull { it.helped && it.lane == lane && it.uid !in cancelled }
            val targetFinish = target?.let { finishes[it.uid] }
            val name = gameData(ctx).name(h.id)
            val (title, note) = if (target != null && targetFinish != null && targetFinish > at) {
                "$name bantu ${target.name} lagi" to "Otomatis membantu ${target.name} (+${h.level} jam kerja)"
            } else "$name siap dipakai" to "Helper sudah bisa ditugaskan lagi"
            list += Upgrade(
                id = "$tag|helpers|${h.id}", tag = tag, kind = Kind.HELPER, name = name,
                targetLevel = 0, finishAt = at, helped = false, note = note, customTitle = title,
            )
        }
        return list.sortedBy { it.finishAt }
    }

    fun importText(ctx: Context, text: String): ImportSummary {
        val now = System.currentTimeMillis()
        val v = ExportReader.read(text, gameData(ctx), now)
        val tag = v.tag
        Store.saveExport(ctx, tag, text)
        Store.setDone(ctx, tag, emptyMap())
        Store.setCancelled(ctx, tag, emptyMap())
        Store.setBumps(ctx, tag, emptyList())
        Store.setBoosts(ctx, tag, Boosts.afterImport(Store.boosts(ctx, tag), v.exportAt))
        val ups = buildTimers(ctx, v)
        Store.replaceAccount(ctx, Account(tag, v.homeBuilders, v.exportAt, v.th, v.bh), ups, Store.earlyMinutes(ctx))
        if (Store.selectedTag(ctx) == null) Store.setSelectedTag(ctx, tag)
        AlarmReceiver.processDue(ctx)
        val running = ups.filter { it.kind != Kind.HELPER && it.finishAt > now }
        return ImportSummary(tag, running.size, running.minByOrNull { it.finishAt }, v.exportAt, v.unknown, ups.count { it.helped })
    }

    /** Hitung ulang timer satu akun setelah item dipakai / upgrade ditandai. */
    fun reproject(ctx: Context, tag: String) {
        val text = Store.exportText(ctx, tag) ?: return
        val v = runCatching { ExportReader.read(text, gameData(ctx), System.currentTimeMillis()) }.getOrNull() ?: return
        val fresh = buildTimers(ctx, v)
        Store.mergeProjections(ctx, tag, fresh, Store.done(ctx, tag).keys)
        AlarmReceiver.processDue(ctx)
    }

    fun finishes(ctx: Context, tag: String): Map<String, Long> =
        Store.upgrades(ctx).filter { it.tag == tag }.associate { it.id to it.finishAt }

    /** Hitung saran, progres dan simulasi (berat — jalankan di background). */
    fun computePlan(ctx: Context, tag: String): PlanBundle? {
        val v = village(ctx, tag) ?: return null
        val gd = gameData(ctx)
        val ps = Store.planSettings(ctx)
        val now = System.currentTimeMillis()
        val fin = finishes(ctx, tag)
        val slots = Planner.suggest(v, gd, ps, now, fin)
        val tips = ItemAdvisor.tips(v, gd, ps, now, fin, Store.items(ctx, tag))
        val home = ProgressCalc.compute(v, gd, false, ps.gold, now, fin)
        val bb = if (v.hasBB && v.bh > 0) ProgressCalc.compute(v, gd, true, ps.gold, now, fin) else null
        val simHome = Planner.simulate(v, gd, ps, now, fin, setOf(Lane.BUILDER, Lane.LAB, Lane.PET))
        val simBB = if (bb != null) Planner.simulate(v, gd, ps, now, fin, setOf(Lane.BB_BUILDER, Lane.STAR_LAB)) else null
        return PlanBundle(tag, v, ps, slots, tips, home, bb, simHome, simBB, now, Store.planVersion(ctx))
    }
}
