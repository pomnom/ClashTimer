package id.clashtimer

import android.content.Context
import id.clashtimer.core.BBStrategy
import id.clashtimer.core.Boosts
import id.clashtimer.core.Events
import id.clashtimer.core.Scored
import id.clashtimer.core.Started
import id.clashtimer.core.Fmt
import id.clashtimer.core.GameData
import id.clashtimer.core.ExportReader
import id.clashtimer.core.ItemAdvisor
import id.clashtimer.core.ItemTip
import id.clashtimer.core.Lane
import id.clashtimer.core.LaneSlot
import id.clashtimer.core.PlanSettings
import id.clashtimer.core.Planner
import id.clashtimer.core.ProgressCalc
import id.clashtimer.core.Projector
import id.clashtimer.core.SimResult
import id.clashtimer.core.Village
import id.clashtimer.core.VillageProgress
import java.time.ZoneId

class ImportSummary(val tag: String, val running: Int, val next: Upgrade?, val exportAt: Long, val unknown: Int, val helped: Int)

class PlanBundle(
    val tag: String,
    val village: Village,
    val ps: PlanSettings,
    val slots: List<LaneSlot>,
    val tips: List<ItemTip>,
    val home: VillageProgress,
    val bb: VillageProgress?,
    val simHome: SimResult,
    val simBB: SimResult?,
    val computedAt: Long,
    val version: Int,
    /** Simulasi Builder Base strategi Max (untuk progres bila strategi = builder ke-6). */
    val simBBMax: SimResult? = simBB,
)

/** Penghubung antara penyimpanan Android dan logika inti. */
object Repo {
    @Volatile private var gd: GameData? = null

    fun gameData(ctx: Context): GameData {
        gd?.let { return it }
        synchronized(this) {
            gd?.let { return it }
            val text = ctx.assets.open("gamedata.json").bufferedReader().use { it.readText() }
            return GameData.parse(text).also { gd = it }
        }
    }

    /** Desa tersimpan + koreksi sejak export (book, hammer, dibatalkan). */
    fun village(ctx: Context, tag: String): Village? {
        val text = Store.exportText(ctx, tag) ?: return null
        val v = runCatching { ExportReader.read(text, gameData(ctx), System.currentTimeMillis()) }.getOrNull() ?: return null
        v.applyStarted(gameData(ctx), Store.started(ctx, tag))
        v.applyOverrides(Store.done(ctx, tag).keys, Store.bumps(ctx, tag).map { it.first to it.second })
        val cancelled = Store.cancelled(ctx, tag).keys
        for (i in v.insts) if (i.uid in cancelled) { i.upgrading = false; i.gearing = false; i.remaining = 0 }
        // Bangunan baru yang dibatalkan: hapus lagi.
        v.insts.removeAll { it.uid in cancelled && it.level == 0 }
        return v
    }

    private fun helperName(lane: Lane): String = when (lane) {
        Lane.BUILDER -> "Builder's Apprentice"
        Lane.LAB -> "Lab Assistant"
        else -> "helper"
    }

    /** Susun daftar timer (dengan proyeksi helper & potion) dari data export. */
    fun buildTimers(ctx: Context, v: Village): List<Upgrade> {
        val tag = v.tag
        val zone = ZoneId.systemDefault()
        val boosts = Store.boosts(ctx, tag)
        val events = Store.events(ctx)
        val done = Store.done(ctx, tag)
        val cancelled = Store.cancelled(ctx, tag)
        val list = ArrayList<Upgrade>()
        val finishes = HashMap<String, Long>()

        for (t in v.timers) {
            if (t.uid in cancelled) continue
            if (t.gear) {
                // Gear-up: Master Builder bekerja di Home Village; tidak ikut potion / Clock Tower.
                val base = v.exportAt + t.remaining * 1000
                val doneAt = done[t.uid]
                val finish = doneAt ?: base
                finishes[t.uid] = finish
                list += Upgrade(
                    id = t.uid, tag = tag, kind = Kind.BB_BUILDER, name = t.name,
                    targetLevel = t.fromLevel, finishAt = finish, helped = false, baseFinishAt = base,
                    note = if (doneAt != null) "Ditandai selesai lebih awal" else "Gear-up · Home Village",
                    customTitle = "${t.name} · Gear-up",
                )
                continue
            }
            val helper = Projector.helperFor(v, t.lane, t.helped)
            val cuts = Events.cutsFor(events, t.lane, v.exportAt)
            val p = Projector.project(v.exportAt, t.remaining, t.lane, boosts, helper, cuts)
            val doneAt = done[t.uid]
            val finish = doneAt ?: p.finishAt
            finishes[t.uid] = finish
            val noBoost = Projector.project(v.exportAt, t.remaining, t.lane, emptyList(), helper, cuts).finishAt
            val noCut = if (cuts.isEmpty()) p.finishAt else Projector.project(v.exportAt, t.remaining, t.lane, boosts, helper).finishAt
            val notes = ArrayList<String>()
            if (doneAt != null) notes += "Ditandai selesai lebih awal"
            else {
                if (p.helperSessions.isNotEmpty()) {
                    notes += "🧑‍🔧 dibantu ${helperName(t.lane)} ${p.helperSessions.size}× (perkiraan) · tanpa helper ${Fmt.at(p.baseFinishAt, zone)}"
                }
                if (noBoost - p.finishAt > 60_000) notes += "⚡ dipercepat item ${Fmt.dur(noBoost - p.finishAt)}"
                if (noCut - p.finishAt > 60_000) notes += "🎉 dipotong event ${Fmt.dur(noCut - p.finishAt)}"
            }
            list += Upgrade(
                id = t.uid, tag = tag, kind = Kind.of(t.lane), name = t.name,
                targetLevel = t.fromLevel + 1, finishAt = finish, helped = t.helped,
                baseFinishAt = p.baseFinishAt, note = notes.joinToString("\n"),
            )
        }

        // Upgrade yang dimulai lewat aplikasi (tanpa import ulang)
        for (st in Store.started(ctx, tag)) {
            if (st.uid in cancelled) continue
            val doneAt = done[st.uid]
            if (st.gear) {
                val finish = doneAt ?: st.finish
                finishes[st.uid] = finish
                list += Upgrade(
                    id = st.uid, tag = tag, kind = Kind.BB_BUILDER, name = st.name,
                    targetLevel = st.fromLevel, finishAt = finish, helped = false, baseFinishAt = st.finish,
                    note = if (doneAt != null) "Ditandai selesai lebih awal" else "Gear-up · Home Village · dimulai di aplikasi",
                    customTitle = "${st.name} · Gear-up",
                )
                continue
            }
            val p = Projector.project(st.start, st.durationSec, st.lane, boosts, null, Events.cutsFor(events, st.lane, st.start))
            val finish = doneAt ?: p.finishAt
            finishes[st.uid] = finish
            val note = when {
                doneAt != null -> "Ditandai selesai lebih awal"
                st.finish - p.finishAt > 60_000 -> "Dimulai di aplikasi · ⚡ dipercepat ${Fmt.dur(st.finish - p.finishAt)}"
                else -> "Dimulai di aplikasi"
            }
            list += Upgrade(
                id = st.uid, tag = tag, kind = Kind.of(st.lane), name = st.name,
                targetLevel = st.fromLevel + 1, finishAt = finish, helped = false,
                baseFinishAt = st.finish, note = note,
            )
        }

        // Cooldown helper
        for (h in v.helpers) {
            if (h.cooldown <= 0 || "$tag|helpers|${h.id}" in cancelled) continue
            val at = v.exportAt + h.cooldown * 1000
            val lane = when (h.id) {
                GameData.APPRENTICE -> Lane.BUILDER
                GameData.LAB_ASSISTANT -> Lane.LAB
                else -> null
            }
            val target = if (lane == null) null else v.timers.firstOrNull { it.helped && it.lane == lane && it.uid !in cancelled }
            val targetFinish = target?.let { finishes[it.uid] }
            val name = gameData(ctx).name(h.id)
            val (title, note) = if (target != null && targetFinish != null && targetFinish > at) {
                "$name bantu ${target.name} lagi" to "Otomatis membantu ${target.name} (+${h.level} jam kerja)"
            } else "$name siap dipakai" to "Helper sudah bisa ditugaskan lagi"
            list += Upgrade(
                id = "$tag|helpers|${h.id}", tag = tag, kind = Kind.HELPER, name = name,
                targetLevel = 0, finishAt = at, helped = false, note = note, customTitle = title,
            )
        }
        return list.sortedBy { it.finishAt }
    }

    fun importText(ctx: Context, text: String): ImportSummary {
        val now = System.currentTimeMillis()
        val v = ExportReader.read(text, gameData(ctx), now)
        val tag = v.tag
        Store.saveExport(ctx, tag, text)
        Store.setDone(ctx, tag, emptyMap())
        Store.setCancelled(ctx, tag, emptyMap())
        Store.setBumps(ctx, tag, emptyList())
        Store.setBoosts(ctx, tag, Boosts.afterImport(Store.boosts(ctx, tag), v.exportAt))
        // Upgrade yang ditandai dimulai sebelum export sudah tercakup di export.
        Store.setStarted(ctx, tag, Store.started(ctx, tag).filter { it.start > v.exportAt })
        val ups = buildTimers(ctx, v)
        Store.replaceAccount(ctx, Account(tag, v.homeBuilders, v.exportAt, v.th, v.bh), ups, Store.earlyMinutes(ctx))
        if (Store.selectedTag(ctx) == null) Store.setSelectedTag(ctx, tag)
        AlarmReceiver.processDue(ctx)
        val running = ups.filter { it.kind != Kind.HELPER && it.finishAt > now }
        return ImportSummary(tag, running.size, running.minByOrNull { it.finishAt }, v.exportAt, v.unknown, ups.count { it.helped })
    }

    /** Hitung ulang timer satu akun setelah item dipakai / upgrade ditandai. */
    fun reproject(ctx: Context, tag: String) {
        val text = Store.exportText(ctx, tag) ?: return
        val v = runCatching { ExportReader.read(text, gameData(ctx), System.currentTimeMillis()) }.getOrNull() ?: return
        val fresh = buildTimers(ctx, v)
        Store.mergeProjections(ctx, tag, fresh, Store.done(ctx, tag).keys)
        AlarmReceiver.processDue(ctx)
    }

    /**
     * Tandai saran sebagai "sudah dimulai di game": timer & notifikasi langsung dipasang.
     * Durasi diambil dari saran (sudah termasuk Gold Pass & event bila dimulai sekarang).
     */
    fun startUpgrade(ctx: Context, tag: String, pick: Scored): Upgrade? {
        val now = System.currentTimeMillis()
        val c = pick.c
        val ps = Store.planSettings(ctx, tag)
        val duration = ps.durationAt(c, now)
        val uid = if (c.gear) "$tag|gear|${c.item.id}|m$now" else "$tag|manual|${c.item.id}|${c.fromLevel}|$now"
        val st = Started(uid, c.item.id, c.fromLevel, c.lane, c.item.name, now, duration, gear = c.gear)
        Store.setStarted(ctx, tag, Store.started(ctx, tag) + st)
        reproject(ctx, tag)
        return Store.upgrades(ctx).firstOrNull { it.id == st.uid }
    }

    /** Id item game dari id timer ("tag|bagian|id|…"). */
    fun itemIdOf(timerId: String): Int? = timerId.split('|').getOrNull(2)?.toIntOrNull()

    fun finishes(ctx: Context, tag: String): Map<String, Long> =
        Store.upgrades(ctx).filter { it.tag == tag }.associate { it.id to it.finishAt }

    /** Hitung saran, progres dan simulasi (berat — jalankan di background). */
    fun computePlan(ctx: Context, tag: String): PlanBundle? {
        val v = village(ctx, tag) ?: return null
        val gd = gameData(ctx)
        val ps = Store.planSettings(ctx, tag)
        val now = System.currentTimeMillis()
        val fin = finishes(ctx, tag)
        val slots = Planner.suggest(v, gd, ps, now, fin)
        val tips = ItemAdvisor.tips(v, gd, ps, now, fin, Store.items(ctx, tag))
        val home = ProgressCalc.compute(v, gd, false, ps.gold, now, fin, ps.skipIds)
        val bb = if (v.hasBB && v.bh > 0) ProgressCalc.compute(v, gd, true, ps.gold, now, fin, ps.skipIds) else null
        val simHome = Planner.simulate(v, gd, ps, now, fin, setOf(Lane.BUILDER, Lane.LAB, Lane.PET), keepSteps = 120)
        val bbLanes = setOf(Lane.BB_BUILDER, Lane.STAR_LAB)
        val simBB = if (bb != null) Planner.simulate(v, gd, ps, now, fin, bbLanes, keepSteps = 160) else null
        val simBBMax = if (simBB?.sixth != null) Planner.simulate(v, gd, ps.withBB(BBStrategy.MAX), now, fin, bbLanes, keepSteps = 10) else simBB
        Store.setLastPct(ctx, tag, home.pct.toFloat())
        return PlanBundle(tag, v, ps, slots, tips, home, bb, simHome, simBB, now, Store.planVersion(ctx), simBBMax)
    }
}
