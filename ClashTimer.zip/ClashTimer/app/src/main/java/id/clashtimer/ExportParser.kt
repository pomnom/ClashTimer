package id.clashtimer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ImportResult(
    val account: Account,
    val upgrades: List<Upgrade>,
    val unknownCount: Int,
)

class ExportException(msg: String) : Exception(msg)

/**
 * Membaca teks dari Settings → More Settings → "Export village data".
 *
 * Setiap entri yang sedang di-upgrade punya "timer" = sisa detik pada saat
 * export, dan "timestamp" di akar JSON = waktu export (detik Unix).
 */
object ExportParser {

    private const val HUT_ID = "1000015"     // Builder's Hut
    private const val BOB_ID = "1000064"     // B.O.B's Hut (builder ke-6)

    // Bagian export → jenis antrean
    private val sections = linkedMapOf(
        "buildings" to Kind.BUILDER,
        "traps" to Kind.BUILDER,
        "heroes" to Kind.BUILDER,
        "units" to Kind.LAB,
        "spells" to Kind.LAB,
        "siege_machines" to Kind.LAB,
        "pets" to Kind.PET,
        "buildings2" to Kind.BB_BUILDER,
        "traps2" to Kind.BB_BUILDER,
        "heroes2" to Kind.BB_BUILDER,
        "units2" to Kind.STAR_LAB,
    )

    @Volatile private var names: Map<String, String>? = null

    private fun names(ctx: Context): Map<String, String> {
        names?.let { return it }
        val text = ctx.assets.open("names.json").bufferedReader().use { it.readText() }
        val o = JSONObject(text)
        val m = HashMap<String, String>()
        o.keys().forEach { k -> m[k] = o.getString(k) }
        names = m
        return m
    }

    fun parse(ctx: Context, rawText: String): ImportResult {
        val text = rawText.trim()
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start < 0 || end <= start) {
            throw ExportException("Teks ini bukan export desa. Di game: Settings → More Settings → Export village data → Copy.")
        }
        val root = try {
            JSONObject(text.substring(start, end + 1))
        } catch (e: Exception) {
            throw ExportException("JSON export tidak lengkap atau rusak. Coba Copy ulang dari game.")
        }
        if (!root.has("buildings") && !root.has("buildings2")) {
            throw ExportException("Tidak ditemukan data bangunan. Pastikan yang di-copy adalah \"Export village data\".")
        }

        val tag = root.optString("tag").ifBlank { "#DESA" }
        val nowMs = System.currentTimeMillis()
        val tsSec = root.optLong("timestamp", 0L)
        // Pakai waktu export dari game; kalau tidak ada / aneh, pakai waktu sekarang.
        val baseMs = if (tsSec > 1_500_000_000L && tsSec * 1000 <= nowMs + 5 * 60_000L) tsSec * 1000 else nowMs

        val nameMap = names(ctx)
        val list = mutableListOf<Upgrade>()
        var unknown = 0
        var huts = 0
        var bob = false

        for ((section, kind) in sections) {
            val arr = root.optJSONArray(section) ?: continue
            val counter = HashMap<String, Int>()
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                val dataId = e.opt("data")?.toString() ?: continue
                val lvl = e.optInt("lvl", -1)

                if (section == "buildings") {
                    if (dataId == HUT_ID) huts += e.optInt("cnt", 1)
                    if (dataId == BOB_ID && lvl >= 1) bob = true
                }

                val timer = e.optLong("timer", 0L)
                if (timer <= 0 || lvl < 0) continue

                val name = nameMap[dataId] ?: run { unknown++; "Upgrade #$dataId" }
                val n = (counter[dataId] ?: 0) + 1
                counter[dataId] = n
                list += Upgrade(
                    id = "$tag|$section|$dataId|$n",
                    tag = tag,
                    kind = kind,
                    name = name,
                    targetLevel = lvl + 1,
                    finishAt = baseMs + timer * 1000,
                    helped = e.optBoolean("helper_recurrent", false),
                )
            }
        }

        // Cooldown helper (Builder's Apprentice, Lab Assistant, Alchemist)
        root.optJSONArray("helpers")?.let { arr: JSONArray ->
            for (i in 0 until arr.length()) {
                val e = arr.optJSONObject(i) ?: continue
                val cd = e.optLong("helper_cooldown", 0L)
                if (cd <= 0) continue
                val dataId = e.opt("data")?.toString() ?: continue
                list += Upgrade(
                    id = "$tag|helpers|$dataId",
                    tag = tag,
                    kind = Kind.HELPER,
                    name = nameMap[dataId] ?: "Helper",
                    targetLevel = 0,
                    finishAt = baseMs + cd * 1000,
                    helped = false,
                )
            }
        }

        val builders = (if (huts > 0) huts else 5) + if (bob) 1 else 0
        return ImportResult(Account(tag, builders, baseMs), list.sortedBy { it.finishAt }, unknown)
    }
}
