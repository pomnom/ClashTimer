# Clash Timer

Aplikasi Android untuk memantau dan merencanakan upgrade Clash of Clans dari
**Export village data**, dengan notifikasi tepat waktu (alarm sistem Android).

## Fitur
**🧭 Tampilan**
- Navigasi bawah (rel di kiri pada tablet): **Dashboard · Tukang · Lab · Pet · Progres** (Pet hanya
  tampil bila desa sudah bisa punya Pet House). Semua halaman
  hanya untuk **desa yang dipilih**. Header: nama desa ▾ (ketuk = lembar **Desa anda**), TH/BH & persen
  menuju max, ikon update dari export & opsi desa, lalu **Home Village | Builder Base** (di Tukang, Lab & Pet:
  **Agenda/Antrian | Timeline**; Tukang & Lab juga **Home | BB**)
- **Desa anda** (lembar pemilih desa, menggantikan tab Desa): login berikutnya semua desa, lalu kartu tiap
  desa dengan kotak Tukang, Lab, Builder Base & Star Lab (hitung mundur / bebas). Ketuk desa = buka,
  ketuk kotak = langsung ke halaman Tukang / Lab-nya, tahan = ganti nama / opsi / hapus
- Tema **ikut sistem / gelap / terang** (Pengaturan → Umum), satu sistem warna: hijau = bebas / tindakan, kuning = builder,
  ungu = lab, oranye = menganggur / peringatan. Angka & hitung mundur memakai huruf lebar tetap
- Satu tombol utama per kartu; detail & aksi lain di **lembar bawah**. Penjelasan & tutorial di tombol **?**
- Changelog: kartu update menampilkan catatan rilis GitHub (bila ada), dan "Yang baru" tampil sekali
  setelah update (juga di Pengaturan → Update aplikasi)

**🌐 Bahasa** — Bahasa Indonesia (bawaan) atau **English** di Pengaturan → Umum → Bahasa. Halaman utama,
  rencana, notifikasi, widget, bantuan (?), event, potion & item, Ore, riwayat dan pesan API sudah diterjemahkan.

**⚙️ Pengaturan** — dirombak per kategori: Umum (bahasa, tema, ikon), Jam istirahat, Notifikasi, Event,
  Data & API, Widget & latar, Tentang & update. Strategi, Gold Pass & CWL tetap per desa (Opsi desa).

**🔕 Senyap saat jam istirahat** (Pengaturan → Jam istirahat)
- Upgrade yang selesai di jam tidur masuk ke panel **tanpa suara, getar, maupun alarm**; pengingat
  "sebentar lagi" dilewati. Alarm keras yang masih berbunyi dihentikan begitu jam tidur mulai
- Bisa juga untuk jam kerja / sekolah. Saat jam istirahat selesai: satu ringkasan bersuara (bisa dimatikan,
  dan tidak dikirim bila aplikasi sudah dibuka). Tes nada tetap berbunyi

**🏠 Dashboard**
- **Ringkasan strategi**: strategi & target ("Seimbang · Max TH11 ±7 Feb 2027"), tukang vs lab mana yang
  **penentu**, lalu pil Gold Pass (+ kenaikan berikutnya), event, CWL dan boost yang aktif. Ketuk = opsi desa
- **Siap dipakai** (paling atas, seperti "Data desa ketinggalan"): Builder's Apprentice, Lab Assistant, Alchemist dan
  boost gratis Clock Tower begitu bisa dipakai — dengan saran upgrade yang dibantu (terlama). Ketuk setelah memakainya
  di game: cooldown 23 jam & pengingatnya dihitung dari situ. Helper yang otomatis membantu upgrade yang sama tidak muncul
- **War / CWL**: sumber data dipilih otomatis.
  - *Tanpa API key* (ClashKing): war atau CWL yang sedang diikuti dan kapan hari perangnya berakhir — hanya info,
    rencana tidak menahan hero. Selama CWL nama akun, clan & liga terisi otomatis.
  - *Dengan API key sendiri* (Pengaturan → Data & akun; API resmi lewat proxy RoyaleAPI, key dibuat di
    developer.clashofclans.com untuk IP 45.79.218.79): serangan sudah dipakai atau belum, hero yang sempat selesai
    sebelum serangan berikutnya, hero ditahan selama CWL, pengingat serangan 3 jam sebelum berakhir (War, CWL, Raid
    Weekend), upgrade yang selesai lebih cepat ditandai otomatis, statistik akun. Bila API gagal → ClashKing.
  - Key hanya disimpan di HP itu; tidak ada di repo/APK dan tidak ikut pindah data / cadangan. Ketuk kartu = perbarui
- **Hitung mundur** tukang & lab yang paling cepat selesai (jam:menit:detik), dengan pekerja yang bebas
- **Tukang** dan **Lab** yang sedang bekerja + **satu saran**: kartu saran untuk pekerja yang bebas
  (**Sudah dimulai** / **Opsi lain**, dengan **Batalkan** di pesan bawah), atau "saran berikutnya" saat
  pekerja tercepat bebas, dengan lonceng pengingat. "Lihat semua" membuka halaman Tukang / Lab
- **Baru selesai** dengan tombol ✓, **Helper**, **Potion & item** yang layak dipakai (BB: kartu Clock Tower)
- Ketuk upgrade berjalan → lembar detail (progres, sisa, waktu di game, tandai selesai, potion, **ubah sisa
  waktu** seperti di game — berlaku sampai import berikutnya, prioritaskan, batalkan)
- Upgrade yang dibantu helper berulang: waktu utama sudah memperhitungkan sesi helper berikutnya (otomatis
  tiap hari), jadi lebih cepat dari timer di game; "Di game" di lembar detail = sisa waktu seperti di game

**🔨 Tukang** (builder / Master Builder)
- **Bebas sekarang**: satu kartu per builder yang bebas — saran teratas (urutan tercepat ke target), lama &
  biaya, dan akibatnya: hijau "selesai 06:25 · pas bangun", oranye "menganggur 3j saat tidur"
- **Agenda** (bawaan): sesi login sampai bangun berikutnya — jam, "sblm tidur" / "bangun", isi tiap sesi dan
  lonceng pengingat (**satu pengingat per sesi login**); pita jam tidur menunjukkan builder yang menganggur.
  Lonceng aktif: notifikasi "selesai" per upgrade di sesi itu masuk tanpa suara
- **Timeline**: satu baris per builder untuk 24 jam atau 3 hari; ketuk batang → kartu detail (mulai, lama,
  selesai, alasannya, "Sudah dimulai" atau "Ingatkan pukul …")
- **Sedang dikerjakan**: kartu per builder (tercepat di atas) dengan hitung mundur, bar, dan apa yang terjadi
  setelahnya ("lalu Air Sweeper → 6" atau "menganggur ±4 jam")
- **Antrian** besok dan seterusnya, per hari; peringatan builder menganggur 7 hari ke depan
- **Builder Base**: Master Builder termasuk **gear-up di Home Village**; kapasitas gudang BB

**🧪 Lab** (Laboratory / Star Lab)
- Kartu riset yang berjalan (termasuk Goblin Researcher), **Antrian Lab** (10 riset berikutnya) dengan lonceng
  pengingat, atau **Timeline** lab, lalu **Sisa riset** per kategori (ketuk → Progres)

**🐾 Pet** (Pet House) — halaman sendiri, seperti Tukang & Lab
- Pet House yang bebas beserta sarannya, upgrade pet yang berjalan, **Antrian Pet** (10 upgrade berikutnya)
  dengan lonceng pengingat atau **Timeline**, lalu **Sisa upgrade pet**
- Halaman ini **tersembunyi** selama desa belum punya pilihan pet (Town Hall belum bisa membangun Pet House)
  dan di sisi Builder Base. Bila Pet House baru direncanakan / sedang dibangun, ada keterangan kapan pet
  bisa mulai

**🎯 Rencana**
- **Bangunan esensial dulu** (semua strategi Home): bangunan bertipe Army dikerjakan sebelum pertahanan & trap
  dengan urutan tetap — Lab, Pet House, Hero Hall, Blacksmith, Clan Castle, Army Camp, lalu Spell Factory,
  Barracks, Workshop. **Seimbang**: esensial → hero → sisanya. **Rush TH**: Town Hall → bangunan baru →
  esensial → hero → sisanya. **Hero dulu**: Hero Hall → hero → esensial → sisanya. Trap baru yang pemasangannya
  instan langsung dipasang di semua strategi. Target tiap strategi tidak mundur
- **Pet ikut direncanakan sejak Pet House belum ada**: begitu Pet House selesai dibangun di rencana, riset pet
  langsung masuk jadwal (begitu juga Laboratory & Star Laboratory yang baru dibangun)
- **Urutan tercepat ke target**: tiap strategi punya target — Seimbang = semua upgrade di TH sekarang
  (builder, lab & pet) selesai; Rush TH = Town Hall berikutnya naik (bangunan baru dipasang dulu, TH ikut
  direncanakan); Hero dulu = semua level hero selesai; Builder ke-6 = B.O.B terbuka; Max BB = Builder Base
  selesai. Setiap kali data atau pengaturan berubah (dan tiap 6 jam) aplikasi menyimulasikan beberapa cara
  mengurutkan — **rantai upgrade terpanjang dulu**, **upgrade terlama dulu**, rantai murni, dan cara lama
  (nilai ÷ √(lama × biaya)) — untuk tiap jenis pekerja, menguji gabungan terbaiknya, lalu memakai yang paling
  cepat mencapai target. Jam tidur/kerja, Gold Pass, event, CWL, helper & kapasitas gudang ikut dihitung;
  Laboratory / Pet House / Hero Hall / Star Lab didahulukan karena membuka level berikutnya
- **Urutan prioritas**: (1) tercepat ke target; bila sama cepat, (2) jeda menganggur terpanjang paling pendek,
  lalu (3) total menganggur paling sedikit — untuk semua builder, lab, pet, Master Builder & Star Lab.
  Menganggur karena semua sudah max atau menunggu syarat tidak dihitung. Ada cara baru **"pas jam tidur"**:
  memilih upgrade yang selesainya pas saat bangun, dan **"akhir event"**: slot terakhir tiap pekerja sebelum Hammer Jam
  (atau event pemotong waktu lain) berakhir diisi upgrade terpanjang, karena potongannya berlaku untuk seluruh durasi
- **Hemat hitung**: hasil hitung rencana dipakai terus sampai data / pengaturan berubah atau ada pekerja yang
  bebas (langkah berikutnya tiba waktunya) — paling cepat 5 menit, paling lama 30 menit. Simulasi Builder Base
  "Max" untuk Progres baru dihitung saat layar Progres Builder Base dibuka, daftar timer hanya diurai ulang bila
  isinya berubah, dan widget / daftar desa memakai desa + saran yang sama dengan hasil hitung rencana
- **Lab & Star Lab tidak menunggu builder**: gudang atau upgrade Laboratory/Star Lab yang membuka riset
  berikutnya didahulukan, dan Star Lab mengisi riset lain bila riset fokus belum bisa
- **Semua hero jalan bersamaan** (di Seimbang & Rush TH setelah bangunan esensial dimulai); saat builder kehabisan pekerjaan tetapi lab/pet masih jalan, strategi
  Seimbang/Max memulai **Town Hall berikutnya lebih awal**
- Builder ke-6 memakai **jalur kritis** (syarat dengan sisa waktu terpanjang dulu). Star Laboratory dimulai **tepat
  waktu**: Master Builder menghitung kapan troop fokus butuh level Star Lab berikutnya (termasuk menaikkan gudang
  dan kapan builder berikutnya bebas), supaya riset troop tidak tertahan. Max BB di BH9: buka
  B.O.B dulu, lalu lanjut dengan 4 Master Builder
- Saran di Dashboard, Tukang, Lab, widget & notifikasi memakai urutan yang sama
- Cara lama tetap ikut dicoba: hero yang menganggur didahulukan dan biaya Dark Elixir disetarakan
  (1 DE ≈ 100 Gold/Elixir)
- Troop, spell & siege yang terbuka saat Barracks, Dark Barracks, Spell Factory, Workshop atau Builder Barracks
  selesai di-upgrade langsung masuk antrean riset rencana (tidak menunggu export berikutnya)
- **Kapasitas gudang**: upgrade atau riset yang biayanya melebihi gudang ditunda dan storage-nya dinaikkan
  dulu — Home: Town Hall + Gold/Elixir/Dark Elixir Storage; Builder Base: Builder Hall + Gold/Elixir Storage
  (juga untuk troop Star Lab). Upgrade yang tetap tidak muat walau semua storage max di TH itu dikeluarkan dari
  rencana TH tersebut. Kapasitas gudang tampil di halaman Tukang (Home & BB)
- **Builder ke-6 (B.O.B)**: checklist 6 syarat (BH9 + B.O.B Control, 3 gear-up, troop Lv18,
  pertahanan Lv9, BM + BC = 45) dengan perkiraan tanggal tiap syarat dan tanggal B.O.B terbuka. Bangunan
  **dan jebakan** baru (mis. Mine, Mega Mine) dipasang dulu supaya Builder Hall bisa naik ke BH9
- Jam tidur/kerja, sesi helper, potongan event. Hero yang bentrok CWL **tidak dimasukkan ke saran & antrean**
  selama CWL — cukup disebut di ringkasan (Dashboard) & Tukang, lalu dilanjutkan setelah CWL selesai

**📊 Progres**
- Persentase menuju max TH/BH (saat TH/BH sedang di-upgrade: menuju max level berikutnya), perkiraan bulan selesai builder & lab, **hari kerja** builder & lab (helper ikut
  dihitung; Clock Tower di masa depan tidak diasumsikan), progres troop Star Lab sampai level max BH; syarat
  **Builder ke-6 (B.O.B)** di Builder Base
- Per kategori: persen, sisa biaya, daftar item (ketuk untuk membuka)

**🎉 Event** (Pengaturan → Event)
- Hammer Jam (−50% waktu & biaya, perkiraan 1 Nov 08:00 – 16 Nov 08:00 UTC), Builder Base Bonanza, atau event lain
- Tidak ada jadwal event resmi yang bisa dibaca aplikasi, jadi event diaktifkan & dicocokkan
  tanggalnya sendiri ("isi dari sisa waktu di game"). Potongan berlaku untuk upgrade yang
  dimulai selama event dan dikalikan dengan Gold Pass; opsi untuk ikut memotong upgrade berjalan

**🏰 Multi desa** · **🎵 Nada notifikasi** (termasuk Alarm keras) — seperti versi sebelumnya

**📱 Widget layar utama** (tahan lama layar HP → Widget → Clash Timer · semua desa)
- Ukuran 4×2 (bisa diperbesar): satu baris per desa dengan kotak Builder, Lab, Builder Base &
  Star Lab — hitung mundur (< 24 jam) atau sisa hari/jam, **bebas** (kotak hijau), "max" bila tidak ada
  lagi yang bisa di-upgrade, "–" bila belum dibangun. Warna sama dengan aplikasi: emas = builder,
  ungu = lab
- Kotak **Lab juga mewakili Pet House**: menampilkan yang bebas, atau yang paling cepat selesai di antara
  Laboratory & Pet House — bertanda **P** bila itu pet (di lembar Desa anda labelnya berubah jadi "Pet").
  Desa tanpa Pet House tidak berubah
- Isinya sama dengan lembar **Desa anda**: Goblin Builder/Researcher tidak dihitung sebagai pekerja tetap
  (tampil sebagai 👺 di bawah nama desa), dan saran memakai urutan tercepat yang sama dengan Tukang
- Desa yang paling cepat bebas di atas; perbesar widget untuk menampilkan lebih banyak desa.
  Baris bawah: saran untuk pekerja yang bebas, atau upgrade berikutnya yang selesai
- Tablet: huruf lebih besar, baris mengisi tinggi widget, dan nama upgrade (+ jumlah sibuk, mis. 4/5)
  tampil di bawah tiap waktu;
  saat mendatar jumlah baris menyesuaikan tinggi widget (ukuran ditentukan dari layar penuh, jadi tetap benar
  walau Clash Timer sedang dibuka di layar terbagi)
- Hitung mundur < 24 jam memakai format Android sesuai bahasa HP: "17.03" = 17 menit 3 detik,
  "16.27.11" = 16 jam 27 menit 11 detik
- Ketuk baris → Dashboard desa itu; ketuk kotak Builder Base / Star Lab → Dashboard di Builder Base; ketuk judul
  "Semua desa" → lembar Desa anda. Diperbarui saat data berubah (import, Sudah dimulai, API), saat
  upgrade selesai, saat keluar dari aplikasi, dan paling lambat tiap 30 menit; mengikuti tema terang/gelap
- **↻ jam** di pojok kanan atas = terakhir diperbarui; ketuk untuk memperbarui sekarang
- Setiap pembaruan menggambar widget dari awal, jadi tampilan baru langsung terpakai setelah update aplikasi
  (sebelum pembaruan pertama widget hanya menampilkan "Memuat…", bukan data contoh)
- **Xiaomi / HyperOS**: Info aplikasi → aktifkan **Mulai otomatis** dan **Penghemat baterai → Tidak ada
  batasan**, supaya widget & notifikasi tetap diperbarui walau aplikasi ditutup (kartu petunjuk di Dashboard,
  juga Pengaturan → Widget & berjalan di latar)
- Data tiap perangkat terpisah: update desa di HP tidak mengubah widget di tablet (pakai **Pindah data**)
- Widget lama "Clash Timer · desa" sudah dihapus; bila masih ada di layar, hapus lalu pasang widget ini

**🔔 Notifikasi interaktif**
- "Upgrade selesai" menampilkan saran berikutnya untuk pekerja itu + tombol **Sudah dimulai**
  (timer langsung dipasang tanpa membuka aplikasi)
- Pengingat **Clock Tower siap lagi** (22 jam setelah boost gratis selesai), **event dimulai** &
  **berakhir besok**, dan **Gold Pass berakhir besok** (bila API diisi)

**📋 Update cepat**
- Setelah Copy export di game lalu membuka aplikasi: kartu "Export baru untuk … — Update"
- Tekan lama ikon aplikasi → **Update desa**, atau tile Quick Settings **Update desa**

**💰 Kebutuhan sumber daya**
- Tab Progres → **Siapkan resource**: total Gold/Elixir/DE (dan Gold/Elixir BB) untuk upgrade yang dimulai
  dalam 24 jam / 3 hari / 7 hari (bar per sumber daya) + upgrade termahal

**🔎 Terdeteksi otomatis (tanpa pengaturan)**
- Dari export: jumlah builder (termasuk B.O.B), builder Builder Base, helper & cooldown-nya, level
  Clock Tower, gear-up, Pet House / Star Lab, semua timer berjalan. **Boost yang sedang aktif** dibaca
  langsung dari export dan menggantikan catatan manual: Builder Potion (builder_boost), Research Potion
  (lab_boost), Pet Potion (pet_boost), Clock Tower (sisa boost & kapan siap lagi). Export hanya memberi
  sisa detik — bila Anda mencatat Builder Bite / Study Soup, jenis itu yang dipakai. Boost berikutnya tidak
  diasumsikan dipakai. **Goblin Builder / Goblin Researcher**
  (event, dibayar gem; "extra" di export) ditampilkan terpisah: tidak dihitung sebagai builder/lab tetap,
  upgrade-nya tetap jalan sampai selesai walau event berakhir, dan di rencana tidak diberi upgrade baru.
  B.O.B sudah terbuka → strategi Builder Base otomatis Max.
- **Gold Pass** dari lama timer: export & API tidak memuat status Gold Pass, jadi saat import aplikasi
  membandingkan upgrade yang ditandai **Sudah dimulai** atau yang baru dimulai sejak import sebelumnya
  dengan durasi aslinya (0 / 10 / 15 / 20 %, termasuk potongan event). Builder Boost & Research Boost
  terisi sendiri; bila baru satu yang terbukti, yang lain diperkirakan sama sampai ada buktinya.
  Upgrade Builder Base (Clock Tower), gear-up, upgrade yang dibantu helper & upgrade < 8 jam tidak dipakai.
- Dari API (setiap desa ditambah / di-update dan saat aplikasi dibuka): nama akun & clan, **ikut CWL atau
  tidak** (roster CWL clan, war preference, tidak di clan) beserta jadwal aslinya, awal & akhir musim
  Gold Pass, dan upgrade hero / lab / pet / Star Lab / TH / BH yang di game sudah naik level (book, gem,
  potion) langsung ditandai selesai.
- Tidak tersedia di export maupun ClashKing: jadwal event (Hammer Jam), book/hammer, dan potion yang dipakai
  setelah export — dicatat manual atau cukup export ulang.

**⚔️ Status War & CWL** — Pengaturan → Data & akun
- Diambil dari API publik ClashKing (api.clashk.ing), tanpa API key: tag pemain dikirim untuk membaca war/CWL yang
  sedang diikuti (paling sering tiap 30 menit saat aplikasi dibuka). Grup CWL (nama, clan, liga) paling sering sekali sehari.

**⚙️ Opsi per desa** (ikon opsi di header, atau ketuk ringkasan strategi di Dashboard)
- Lembar **Opsi desa** (Home | Builder Base): kartu strategi menampilkan **tanggal target masing-masing**
  ("Semua upgrade TH11 selesai ±7 Feb", "Semua hero max ±7 Des"); Gold Pass bertanda **OTOMATIS**
  bila terdeteksi; sakelar collector; prioritas & disembunyikan. Semua disimpan **per desa**.
- Lembar ini juga berisi Update dari export, Ganti nama, Hapus desa, Potion & item, dan Pengaturan.
- **Gold Pass naik bertahap**: boost 10% terbuka di awal track, 15% dan 20% setelah poin tertentu (musim
  November 2026: Research 580/1.000, Builder 640/1.060 — bisa diubah di "Ambang"). Isi poin track sekarang
  di Opsi desa → Gold Pass: aplikasi memperkirakan tanggal tiap ambang tercapai (poin per hari dari riwayat
  poin, bawaan ±90, atau isi sendiri) dan rencana memakai persen yang naik mulai tanggal itu
- Jam tidur/kerja, event, ikon, nada & notifikasi (⚙️ Pengaturan) berlaku untuk semua desa.

**📌 Prioritaskan / sembunyikan** — tahan lama upgrade di Dashboard, Tukang, Lab, atau Progres
- Prioritaskan: didahulukan di saran, rencana, widget & notifikasi. Sembunyikan: hilang dari saran &
  rencana tetapi tetap dihitung di progres. Kelola di lembar **Opsi desa**.

**📈 Riwayat & statistik** (tab Progres)
- Grafik % menuju max per minggu, jam builder menganggur per minggu (Home / Builder Base) dan upgrade
  selesai per bulan — dikumpulkan dari setiap import.
- Statistik akun dari API: trophy & liga, war stars, donasi, Clan Capital, achievements, info clan,
  super troop aktif (juga di Dashboard).

**🔮 Simulasi** (tab Progres → Hitung simulasi)
- Tanggal bangunan, hero & lab selesai (dan Builder Base max) untuk: dengan/tanpa Gold Pass, Hammer Jam,
  tiga strategi saran, dan builder ke-6.

**⚒️ Kalkulator ore** (tab Progres) — level equipment dari export/API, batas Blacksmith & TH, ore yang
  dimiliki + pemasukan per minggu → kebutuhan Shiny/Glowy/Starry Ore & perkiraan minggu.

**🧱 Tembok** — progres terpisah (Home & Builder Base), biaya naik satu level per level tembok, dan total ke max.

**📦 Pindah data & cadangan** (Pengaturan) — Salin semua data / Tempel data (HP ↔ tablet) atau simpan /
  buka file cadangan .json: desa, timer, opsi & riwayat.

**🔄 Update dari dalam aplikasi** (Pengaturan → Update aplikasi)
- Saat aplikasi dibuka (paling sering tiap 3 jam) Clash Timer mengecek rilis terbaru di GitHub
  (`build-N` = nomor versi aplikasi). Ada yang baru → kartu **Update** di layar utama
- Ketuk Update → APK diunduh lewat pengunduh Android (progres di aplikasi & notifikasi, checksum diperiksa)
  → ketuk notifikasi "Unduhan selesai" (atau Pasang → daftar Unduhan) → Update
- Clash Timer sengaja **tidak** punya izin memasang aplikasi: aplikasi yang bisa mengunduh sekaligus
  memasang APK ditandai Play Protect sebagai tidak aman. Pemasangan dilakukan aplikasi Unduhan/File HP
- File APK dihapus otomatis begitu build baru dibuka (atau setelah 3 hari bila tidak dipasang) — tidak
  memenuhi penyimpanan HP

**🖥️ Layar lebar** — di tablet atau HP landscape, Dashboard dan Tukang tampil berdampingan, navigasi di rel kiri.

**Data game tambahan**
- Jebakan Builder Base (Push Trap, Mine, Mega Mine, Spring Trap) ikut saran & progres BB.
- Senjata Town Hall: sejak update Oktober 2025 level senjata TH12–15 dihapus Supercell; yang masih punya
  level (TH17 Inferno Artillery) ikut saran & progres.
- Crafting Station: level modul tiap pertahanan rakitan musim ini (tab Progres).

**Lainnya**
- Opsi **jangan upgrade collector** (Gold Mine, Elixir Collector, Dark Elixir Drill)
- Town Hall / Builder Hall baru disarankan setelah semua bangunan baru dipasang
- Jam tidur & kerja, lewati hero saat CWL (otomatis dengan API), mode alarm kuat

## Cara update dari HP (repo yang memakai ClashTimer.zip)
1. Buka repository di browser → **Add file → Upload files**.
2. Upload `ClashTimer.zip` yang baru → **Commit changes**.
3. GitHub Actions otomatis mengekstrak zip ke repo (README, kode & resource ikut terbarui; file yang
   sudah tidak ada di zip ikut terhapus), menghapus zip-nya, lalu membuat APK.
4. Tunggu tab **Actions** selesai. Buka Clash Timer → kartu **⬆️ build baru tersedia → Update**
   (atau Pengaturan → Update aplikasi → Cek update sekarang): APK diunduh di dalam aplikasi, lalu ketuk
   notifikasi "Unduhan selesai" → Update. File-nya dihapus otomatis setelah build baru dibuka. Data tetap
   aman karena kunci tanda tangan sama. Mengunduh APK manual dari **Releases** tetap bisa.
- Folder `.github/workflows` tidak ikut diperbarui dari zip (token Actions tidak boleh mengubah file
  workflow) — bila workflow berubah, salin manual dari `.github/workflows/build.yml`.
- **Catatan rilis**: isi `app/src/main/assets/changelog.txt` (`# judul`, lalu `- butir` per perubahan) setiap
  build. Workflow menjadikannya isi rilis di GitHub (tampil di kartu update aplikasi), dan aplikasi
  menampilkannya sekali sebagai "Yang baru" setelah update. Bila file itu tidak berubah, isi rilis
  cukup "Perbaikan kecil".
- Mengedit file langsung di GitHub (tanpa zip) juga langsung dibuatkan APK dari kode di repo.

## Memperbarui data game
Saat Supercell merilis update, `app/src/main/assets/gamedata.json` disusun ulang dengan skrip (Python 3, tanpa
library tambahan):
```
python3 tools/build_gamedata.py          # unduh data ClashKingAssets terbaru, susun & periksa
python3 tools/build_gamedata.py --check  # hanya periksa apakah data sudah terbaru
python3 tools/build_gamedata.py --validate  # periksa gamedata.json yang ada (tanpa unduh)
```
- Data yang tidak ada di ClashKingAssets (kapasitas gudang, kamp Builder Base) diubah di `tools/overrides.json`.
- Sebelum menulis, skrip memeriksa: upgrade termahal di tiap Town Hall harus muat di gudang maksimal, tabel
  kapasitas mencakup level tertinggi, tidak ada id ganda atau level yang bolong. Bila ada yang gagal, file tidak
  ditulis dan masalahnya ditampilkan.

## Pemeriksaan otomatis sebelum rilis
Saat build di GitHub Actions (`CI=true`), `app/build.gradle.kts` menjalankan dua pemeriksaan sebelum APK rilis
dibuat — `build.yml` tidak perlu diubah. Bila salah satu gagal, build berhenti (tidak ada rilis baru) dan
penyebabnya tampil di log run Actions:
- `tools/build_gamedata.py --validate` — data game (lihat di atas).
- `./gradlew testReleaseUnitTest` — tes inti perencana di `app/src/test` dengan empat contoh desa (tag
  disamarkan): arti baris data (mis. Headhunter Lv3 = 90 rb DE), kapasitas gudang, setiap langkah rencana
  muat di gudang, riset Star Lab menunggu level Star Lab, hanya satu gear-up sekaligus, bangunan esensial
  sebelum hero / pertahanan sesuai strategi, pet direncanakan begitu Pet House dibangun, dan target tercapai.
- **Rencana acuan** (`GoldenPlanTest`): urutan langkah tiap strategi untuk keempat contoh desa disimpan di
  `app/src/test/resources/golden/`. Bila kode mengubah urutan itu, build gagal dan log menunjukkan baris
  pertama yang berbeda — supaya perubahan prioritas yang tidak disengaja ketahuan sebelum rilis.
  - Perubahan yang disengaja: buat ulang acuan dengan `UPDATE_GOLDEN=1 ./gradlew testReleaseUnitTest`, periksa
    selisihnya, lalu ikutkan berkasnya.
  - Bila `gamedata.json` diperbarui, rencana memang ikut berubah: tes acuan **dilewati** (bukan gagal) sampai
    acuan dibuat ulang untuk data yang baru (baris pertama tiap berkas mencatat sidik data game).

## Cara pakai
1. Di game: Settings → More Settings → paling bawah **Export village data** → Copy.
2. Buka Clash Timer → **📋 Update desa** (atau Import dari Clipboard).
3. Pilih strategi saran & collector di lembar **Opsi desa** (ikon opsi di header); Gold Pass terisi
   sendiri. Jam tidur/kerja, event & nada ada di ⚙️ **Pengaturan**.
4. Setelah memulai upgrade di game, tekan **Sudah dimulai** pada saran — atau import ulang
   (sekaligus membuat Gold Pass terdeteksi).

## Catatan
- Timer = sisa waktu *saat export*. Potion/book/Clock Tower yang dipakai setelah export bisa
  dicatat; import ulang selalu menjadi sumber kebenaran.
- Perhitungan helper berulang adalah perkiraan (1 jam kerja, cooldown 23 jam, +level jam kerja).
- Clock Tower: 10× selama 12 + 2×level menit, cooldown 22 jam sejak boost selesai (data Supercell); tidak
  mempercepat gear-up.
- Data game (durasi, biaya, syarat, ikon) dari ClashKingAssets, disusun dengan `tools/build_gamedata.py`
  (data 31 Oktober 2026).
- Untuk troop, spell, siege machine, hero & pet, baris data level N berisi lama/biaya upgrade **dari** N ke N+1,
  sedangkan syarat hall/lab di baris itu untuk **memiliki** level N — aplikasi menggesernya saat membaca data.
- Kapasitas gudang (Town Hall, storage Home & BB) dari kolom kapasitas file data game; TH18 dari Clash of Clans Wiki
  (`tools/overrides.json`).
- Ikon diunduh saat dipakai dari **ClashKing Assets** (https://assets.clashk.ing) — terima kasih!
  Bisa dimatikan di Pengaturan → Ikon. Izin INTERNET hanya dipakai untuk ini.

Fan content tidak resmi, tidak berafiliasi dengan dan tidak didukung oleh Supercell.
Gambar & nama Clash of Clans © Supercell.

## Kunci tanda tangan APK (GitHub Secrets)
APK ditandatangani dengan kunci tetap (supaya update bisa dipasang di atas versi lama). Kunci & sandinya tidak ada di
repo; Actions membacanya dari **Settings → Secrets and variables → Actions**:
- `CT_KEYSTORE_B64` — isi file keystore dalam base64
- `CT_STORE_PASSWORD` dan `CT_KEY_PASSWORD` — sandi keystore & kunci (alias `clashtimer`)

Langkah "Kunci tanda tangan dari Secrets" di `.github/workflows/build.yml` menulis keystore ke folder sementara
runner. Tanpa Secrets, build gagal di langkah itu (APK tidak pernah dibuat tanpa tanda tangan).
