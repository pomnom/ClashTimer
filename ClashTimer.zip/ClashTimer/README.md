# Clash Timer

Aplikasi Android untuk memantau dan merencanakan upgrade Clash of Clans dari
**Export village data**, dengan notifikasi tepat waktu (alarm sistem Android).

## Fitur
**🏠 Beranda**
- Hitung mundur besar "builder berikutnya bebas" + satu saran upgrade
- Builder, Laboratory, Pet House (dan Builder Base) dengan cincin progres, waktu selesai,
  label helper/potion
- **Sudah dimulai**: setelah memulai upgrade di game, ketuk tombol ini → timer & notifikasi
  langsung dipasang tanpa import ulang. **Lihat opsi** untuk memilih upgrade lain
- Ketuk sebuah upgrade → tandai selesai (gem/book) atau batal
- Helper (Apprentice/Lab Assistant), banner CWL, desa lain yang punya builder bebas

**📅 Rencana**
- Jadwal per hari: jam, builder (B1–B6 / Lab / Pet), upgrade apa, selesai kapan
- Jam tidur/kerja, sesi helper, dan hero yang ditunda karena CWL tampil di jadwal
- Strategi Seimbang / Rush TH / Hero dulu

**📊 Progres**
- Persentase menuju max TH/BH, perkiraan bulan selesai builder & lab, hari kerja tersisa
- Per kategori: persen, sisa biaya, daftar item (ketuk untuk membuka)

**🏰 Multi desa**
- Import export dari akun lain → desa baru otomatis ditambahkan
- Tombol desa di kiri atas: pilih desa, ganti nama, update, hapus
- Notifikasi semua desa tetap berjalan dan menyebut nama desanya

**🎵 Nada notifikasi** (Pengaturan → Nada notifikasi)
- Nada bawaan, pilih nada sendiri, **Alarm keras** (berulang dengan volume alarm sampai
  dibuka/diusap/ditekan Matikan), getar saja, atau senyap — terpisah untuk "upgrade selesai"
  dan "pengingat sebelum selesai", dengan tombol tes

**Lainnya**
- Helper berulang ikut dihitung ke waktu selesai; potion/book/hammer bisa dicatat
- Gold Pass Builder/Research Boost, jam tidur & kerja, opsi lewati hero saat CWL
- Mode alarm kuat: notifikasi tepat waktu walau HP tidur (ikon ⏰ di status bar)

## Cara update dari HP (repo yang memakai ClashTimer.zip)
1. Buka repository di browser → **Add file → Upload files**.
2. Upload `ClashTimer.zip` yang baru (nama sama, menimpa yang lama) → **Commit changes**.
3. Tunggu tab **Actions** selesai, lalu unduh APK dari **Releases** dan install di atas
   versi lama (data tetap aman karena kunci tanda tangan sama).

## Cara pakai
1. Di game: Settings → More Settings → paling bawah **Export village data** → Copy.
2. Buka Clash Timer → **📋 Update desa** (atau Import dari Clipboard).
3. Atur jam tidur/kerja, Gold Pass, dan nada di ⚙️ **Pengaturan**.
4. Setelah memulai upgrade di game, tekan **Sudah dimulai** pada saran — atau import ulang.

## Catatan
- Timer = sisa waktu *saat export*. Potion/book yang dipakai setelah export bisa dicatat di
  aplikasi; import ulang selalu menjadi sumber kebenaran.
- Perhitungan helper berulang adalah perkiraan (1 jam kerja, cooldown 23 jam, +level jam kerja).
- Data game (durasi, biaya, syarat) dari ClashKingAssets via coc-rush-helper, Oktober 2026.

Fan content tidak resmi, tidak berafiliasi dengan Supercell.
