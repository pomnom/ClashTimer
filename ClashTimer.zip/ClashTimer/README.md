# Clash Timer

Aplikasi Android untuk memantau dan merencanakan upgrade Clash of Clans dari
**Export village data**, dengan notifikasi tepat waktu (alarm sistem Android).

## Fitur
**⏱ Timer**
- Import dari clipboard (atau "Bagikan" teks ke aplikasi) — Home Village & Builder Base
- Builder, Laboratory, Pet House, Star Lab, Builder Base, dan cooldown helper
- Helper berulang (Builder's Apprentice / Lab Assistant) ikut dihitung ke waktu selesai
- Notifikasi tepat waktu walau layar mati; pengingat tambahan 5–60 menit sebelumnya
- Tekan lama timer → tandai selesai (dipercepat) atau dibatalkan

**💡 Saran**
- Untuk tiap builder / lab / pet / Builder Base yang bebas: upgrade terbaik untuk dimulai
- Memperhitungkan jam tidur & jam kerja: sebelum tidur, upgrade panjang yang selesai saat
  Anda bangun diutamakan; tanda 💤 bila builder akan menganggur
- Strategi: Seimbang (max TH), Rush TH, atau Hero dulu
- Opsi lewati upgrade hero yang bentrok Clan War League (default: tanggal 1, 11 hari)
- Saran item: nilai Builder/Research Potion saat ini, target terbaik Book & Hammer
- Rencana builder beberapa langkah ke depan

**⚡ Item**
- Catat Builder/Research/Pet Potion, Builder Bite, Study Soup → timer & notifikasi langsung maju
- Book (selesaikan upgrade berjalan) dan Hammer (naik 1 level) → saran ikut diperbarui
- Simpan jumlah item yang dimiliki; catatan bisa dibatalkan bila salah

**📈 Progres**
- Persentase menuju max TH / BH per kategori, sisa waktu kerja & biaya
- Perkiraan tanggal semua upgrade builder & lab selesai (dengan jam istirahat, helper,
  Gold Pass dan CWL)
- Gold Pass Builder/Research Boost (10/15/20%) dihitung dengan pembulatan seperti di game

## Cara update dari HP (repo yang memakai ClashTimer.zip)
1. Buka repository di browser → **Add file → Upload files**.
2. Upload `ClashTimer.zip` yang baru (nama sama, menimpa yang lama) → **Commit changes**.
3. Tunggu tab **Actions** selesai, lalu unduh APK dari **Releases** dan install di atas
   versi lama (data tetap aman karena kunci tanda tangan sama).

## Cara pakai
1. Di game: Settings → More Settings → paling bawah **Export village data** → Copy.
2. Buka Clash Timer → **Import dari Clipboard**.
3. Atur jam tidur/kerja & Gold Pass di menu ⋮ → **Pengaturan**.
4. Import ulang setiap kali memulai upgrade baru supaya saran mengikuti kondisi terbaru.

## Catatan
- Timer = sisa waktu *saat export*. Potion/book yang dipakai setelah export bisa dicatat di
  aplikasi; import ulang selalu menjadi sumber kebenaran.
- Perhitungan helper berulang adalah perkiraan (1 jam kerja, cooldown 23 jam, +level jam kerja).
- Data game (durasi, biaya, syarat) dari ClashKingAssets via coc-rush-helper, Oktober 2026.

Fan content tidak resmi, tidak berafiliasi dengan Supercell.
